export const DAILY_QUESTIONS = [
  {
    id: 1,
    category: 'general' as const,
    en: "Are you feeling well today?",
    ta: "இன்று நீங்கள் நலமாக இருக்கிறீர்களா?",
  },
  {
    id: 2,
    category: 'medication' as const,
    en: "Did you take your medicine?",
    ta: "இன்று உங்கள் மருந்தை எடுத்துக்கொண்டீர்களா?",
  },
  {
    id: 3,
    category: 'pain' as const,
    en: "Are you experiencing any pain?",
    ta: "உங்களுக்கு ஏதேனும் வலி இருக்கிறதா?",
  },
  {
    id: 4,
    category: 'safety' as const,
    en: "Did you fall or feel dizzy?",
    ta: "நீங்கள் கீழே விழுந்தீர்களா அல்லது தலைச்சுற்றல் ஏற்பட்டதா?",
  },
  {
    id: 5,
    category: 'sleep' as const,
    en: "How was your sleep?",
    ta: "நேற்று இரவு உங்கள் தூக்கம் எப்படி இருந்தது?",
  },
  {
    id: 6,
    category: 'mood' as const,
    en: "How are you feeling emotionally today?",
    ta: "இன்று உங்கள் மனநிலை எப்படி இருக்கிறது?",
  }
];

export const translations = {
  en: {
    brand: {
      name: "ANBUVOICE AI",
      subname: "AI-Powered Elderly Wellbeing & Family Care",
      tagline: "Every voice matters. Every senior deserves care.",
      meaning: "‘Anbu’ is the Tamil word for love and affectionate care; ‘Voice’ embodies our gentle, daily conversational companion.",
      trustStatement: "Designed to support families, not replace healthcare professionals.",
      disclaimer: "AnbuVoice AI provides supportive monitoring and early insights. It does not provide medical diagnosis or replace professional medical care. For acute symptoms or emergencies, contact healthcare services immediately."
    },
    nav: {
      home: "Home",
      howItWorks: "How It Works",
      features: "Features",
      familyCare: "Family Care",
      safety: "Safety & Ethics",
      about: "About Us",
      dashboard: "Dashboard",
      login: "Login",
      register: "Get Started",
      logout: "Logout",
      demoMode: "DEMO MODE",
      switchLang: "தமிழ்"
    },
    hero: {
      headline: "Care That Listens.",
      subheading: "AI-powered voice check-ins that help families stay connected with their loved ones every day.",
      description: "AnbuVoice AI automatically checks in with seniors through friendly voice conversations and keeps families informed about important wellbeing concerns.",
      ctaPrimary: "Get Started Free",
      ctaSecondary: "See How It Works",
      ctaDemoCall: "Try Voice Call Demo",
      pipelineTitle: "Daily Automated Care Loop",
      steps: [
        { label: "Senior Citizen", desc: "Living at home" },
        { label: "AI Voice Call", desc: "Automated friendly dial" },
        { label: "Senior Responds", desc: "Natural voice answer" },
        { label: "Speech-to-Text", desc: "Accurate transcription" },
        { label: "AI Analysis", desc: "Wellbeing assessment" },
        { label: "Attention Level", desc: "LOW / MEDIUM / HIGH" },
        { label: "Family Notification", desc: "SMS, WhatsApp & Email" }
      ]
    },
    features: {
      title: "Comprehensive Wellbeing Architecture",
      subtitle: "Thoughtfully crafted tools to ensure no senior feels isolated, and no family is left in uncertainty.",
      items: [
        {
          id: 1,
          title: "Daily Voice Check-ins",
          desc: "Automated, warm scheduled telephone check-ins that feel like a friendly neighbor calling to say hello."
        },
        {
          id: 2,
          title: "Medication Check",
          desc: "Gentle reminders and verbal confirmation to help seniors maintain their daily medication routines."
        },
        {
          id: 3,
          title: "Mood & Wellbeing",
          desc: "Detects subtle shifts in emotional tone, loneliness, and energy levels across longitudinal conversations."
        },
        {
          id: 4,
          title: "Safety Questions",
          desc: "Daily proactive screening for recent slips, balance instability, disorientation, or dizziness."
        },
        {
          id: 5,
          title: "AI Conversation Analysis",
          desc: "Intelligent linguistic processing that highlights reported concerns without making clinical diagnostic claims."
        },
        {
          id: 6,
          title: "Family Notifications",
          desc: "Instant multi-channel updates via SMS, WhatsApp, and Email with clear attention levels."
        },
        {
          id: 7,
          title: "Tamil & English Support",
          desc: "Natural bilingual conversational flow allowing elders to express comfort in their mother tongue."
        },
        {
          id: 8,
          title: "Call Retry System",
          desc: "Intelligent re-dial logic when a call goes unanswered, escalating to family if multiple attempts fail."
        }
      ]
    },
    howItWorks: {
      badge: "Simple 6-Step Workflow",
      title: "How AnbuVoice AI Works",
      subtitle: "From setup to daily reassurance in six seamless steps.",
      steps: [
        {
          number: "01",
          title: "Family Creates Senior Profile",
          desc: "Add your loved one's details, preferred language (English or Tamil), medications, and emergency contacts."
        },
        {
          number: "02",
          title: "Set Daily Call Time",
          desc: "Choose convenient check-in windows (e.g. 9:00 AM after breakfast) that fit their daily routine."
        },
        {
          number: "03",
          title: "AI Calls Senior",
          desc: "The system dials their phone automatically. No smartphone or apps required on the senior's end."
        },
        {
          number: "04",
          title: "Senior Answers Questions",
          desc: "Senior speaks naturally, answering questions about overall feeling, medication, pain, and sleep."
        },
        {
          number: "05",
          title: "AI Analyzes Response",
          desc: "Speech is transcribed and analyzed to identify reported wellbeing concerns and assign an attention tier."
        },
        {
          number: "06",
          title: "Family Receives Update",
          desc: "A neat summary card lands on your family dashboard with SMS and WhatsApp alerts for priority concerns."
        }
      ]
    },
    dashboard: {
      title: "Family Care Dashboard",
      welcomeBack: "Welcome back",
      stats: {
        totalSeniors: "Total Seniors",
        todaysCalls: "Today's Calls",
        completedCalls: "Completed Calls",
        missedCalls: "Missed Calls",
        activeAlerts: "Active Alerts"
      },
      riskSummary: "Risk Summary",
      riskLow: "LOW",
      riskMedium: "MEDIUM",
      riskHigh: "HIGH",
      charts: {
        riskTrend: "Risk Trend (7-Day Attention Levels)",
        callCompletion: "Call Completion Status",
        moodTrend: "Mood & Energy Trend",
        medicationConfirm: "Medication Adherence Confirmation",
        weeklyActivity: "Weekly Check-in Activity"
      },
      quickActions: "Quick Actions",
      startDemoCall: "Start Voice Check-in",
      addSenior: "Add Senior Profile",
      viewAlerts: "View Alerts"
    },
    senior: {
      title: "Senior Profiles",
      subtitle: "Manage monitored seniors, schedule preferences, and clinical contacts.",
      addBtn: "Add Senior Profile",
      name: "Senior Name",
      age: "Age",
      gender: "Gender",
      phone: "Phone Number",
      relationship: "Relationship",
      language: "Preferred Language",
      medicalInfo: "Medical Information",
      medications: "Current Medications",
      callTime: "Daily Call Time",
      status: "Status",
      riskLevel: "Attention Level",
      lastCheckin: "Last Check-in",
      nextCall: "Next Call",
      emergencyContact: "Emergency Contact",
      emergencyName: "Contact Name",
      emergencyPhone: "Contact Phone",
      emergencyRelation: "Relationship",
      actions: "Actions",
      callNow: "Call Now",
      edit: "Edit",
      delete: "Delete",
      view: "View Profile",
      addedSuccess: "Senior profile added successfully.",
      updatedSuccess: "Senior profile updated successfully.",
      deletedSuccess: "Senior profile removed."
    },
    voiceSimulator: {
      title: "Voice Call Demo Simulator",
      subtitle: "Simulate a live AI voice check-in call with real-time speech synthesis, transcription, and instant AI assessment.",
      selectSenior: "Select Senior",
      scenario: "Select Simulation Scenario",
      scenarios: {
        healthy: "1. Normal Check-in (Feels Well, Meds Taken) -> LOW",
        mildConcern: "2. Mild Discomfort & Poor Sleep -> MEDIUM",
        highConcern: "3. Dizziness & Severe Knee Pain -> HIGH",
        interactive: "4. Custom Voice (Speak via Mic or Type)"
      },
      status: {
        idle: "Ready to Call",
        calling: "Calling Senior...",
        connected: "Call Connected",
        asking: "AI Asking Question...",
        listening: "Listening for Senior Response...",
        processing: "Processing Speech-to-Text...",
        analyzing: "AI Analyzing Wellbeing...",
        notifying: "Dispatching Family Notifications...",
        completed: "Check-in Call Completed"
      },
      startCall: "Start Demo Voice Call",
      endCall: "End Call",
      seniorSpeaking: "Senior Response",
      aiSpeaking: "AI Assistant",
      listenPrompt: "Listening to voice waveform...",
      enterManualResponse: "Type response or press send",
      nextQuestion: "Next Question",
      simulateAllQuestions: "Simulate Full 6-Question Call",
      completedNotice: "Call saved! Transcript, AI analysis, attention tier, and family alerts have been updated across your dashboard.",
      viewFullAnalysis: "Inspect AI Analysis"
    },
    analysis: {
      title: "AI Wellbeing Analysis",
      subtitle: "Evidence-based linguistic inspection of senior responses without medical diagnostic claims.",
      attentionTier: "Assigned Attention Level",
      reportedConcerns: "Reported Concerns",
      observations: "AI Observations",
      recommendations: "Recommended Next Steps",
      transcriptHeading: "Conversation Transcript",
      disclaimerNotice: "Reported concern — AnbuVoice AI observes patterns in conversation and never claims to diagnose clinical conditions or diseases.",
      lowDesc: "Senior feels well, confirmed medications, no reported pain or balance instability. Routine family update dispatched.",
      mediumDesc: "Mild discomfort, sleep disturbance, or missed medication reported. Caregiver review recommended.",
      highDesc: "Potentially serious concern reported (e.g. dizziness, pain, or slip). Urgent family check recommended."
    },
    communication: {
      title: "Family Communication & Retry Engine",
      subtitle: "Real-time dispatch overview, multi-channel family notifications, and unattended call retry handling.",
      todaysCalls: "Today's Check-ins",
      noAnswerEngine: "No-Answer Retry Engine",
      noAnswerSteps: [
        { label: "Scheduled Call", desc: "First scheduled attempt" },
        { label: "Attempt 1: No Answer", desc: "Phone rang 45s without pickup" },
        { label: "Automatic Retry", desc: "System pauses 10 mins before redial" },
        { label: "Attempt 2: No Answer", desc: "Second dial attempt unanswered" },
        { label: "Family Notification", desc: "Urgent check-in request dispatched" }
      ],
      channelsTitle: "Multi-Channel Notification Previews",
      smsTab: "SMS Alert",
      whatsappTab: "WhatsApp Alert",
      emailTab: "Email Alert",
      simulateNoAnswer: "Simulate No-Answer Retry Flow"
    },
    notifications: {
      title: "Notification Center",
      markAllRead: "Mark All as Read",
      all: "All",
      unread: "Unread",
      empty: "No notifications at this time."
    },
    safety: {
      title: "Clinical Safety & Ethical Boundaries",
      headline: "Built with Strict Patient Safety Guardrails",
      disclaimerFull: "AnbuVoice AI provides supportive monitoring and early insights. It does not provide medical diagnosis or replace professional medical care.",
      rules: [
        {
          rule: "No Clinical Diagnosis",
          desc: "The system uses language like 'Reported concern' or 'Senior noted pain' and never diagnoses clinical diseases or conditions."
        },
        {
          rule: "No Medication Prescriptions",
          desc: "AnbuVoice AI only verifies adherence to prescribed routines configured by the family, and never recommends dosage changes."
        },
        {
          rule: "Immediate Escalation Advice",
          desc: "For any HIGH attention level, the system explicitly advises families: 'Please check on the senior directly and seek appropriate professional or emergency help when necessary.'"
        },
        {
          rule: "Privacy & Dignity",
          desc: "Voice interactions are gentle, respectful, unhurried, and designed with accessible pacing for senior comfort."
        }
      ]
    },
    admin: {
      title: "System Administration",
      totalFamilies: "Registered Families",
      totalSeniors: "Monitored Seniors",
      todaysVolume: "Today's Call Volume",
      systemHealth: "Engine Uptime (100%)",
      questionEditor: "Question Templates",
      telemetry: "Twilio / Webhook Status: Active (Demo Mode)"
    }
  },
  ta: {
    brand: {
      name: "அன்பு வாய்ஸ் AI",
      subname: "முதியோர் நலன் மற்றும் குடும்ப பராமரிப்பு",
      tagline: "ஒவ்வொரு குரலும் முக்கியம். ஒவ்வொரு முதியவரும் பராமரிப்பிற்கு தகுதியானவர்.",
      meaning: "‘அன்பு’ என்பது குடும்பத்தின் பாசத்தையும், ‘வாய்ஸ்’ என்பது தினசரி உரையாடும் AI குரல் துணையையும் குறிக்கிறது.",
      trustStatement: "குடும்பங்களுக்கு உதவ வடிவமைக்கப்பட்டது, மருத்துவர்களுக்கு மாற்று அல்ல.",
      disclaimer: "அன்பு வாய்ஸ் AI ஆதரவான கண்காணிப்பு மற்றும் ஆரம்ப நுண்ணறிவுகளை மட்டுமே வழங்குகிறது. இது மருத்துவ நோயறிதலை வழங்காது அல்லது தொழில்முறை மருத்துவ சிகிச்சையை மாற்றாது."
    },
    nav: {
      home: "முகப்பு",
      howItWorks: "செயல்படும் முறை",
      features: "சிறப்பம்சங்கள்",
      familyCare: "குடும்ப பராமரிப்பு",
      safety: "பாதுகாப்பு & விதிகள்",
      about: "எங்களைப் பற்றி",
      dashboard: "டாஷ்போர்டு",
      login: "உள்நுழைக",
      register: "தொடங்குக",
      logout: "வெளியேறு",
      demoMode: "டெமோ முறை",
      switchLang: "English"
    },
    hero: {
      headline: "செவிசாய்க்கும் அன்பு.",
      subheading: "முதியவர்களுடன் குடும்பங்கள் தினமும் தொடர்பில் இருக்க உதவும் AI குரல் அழைப்பு சேவை.",
      description: "அன்பு வாய்ஸ் AI தனியாக வாழும் முதியவர்களை தினசரி அன்போடு அழைத்து நலம் விசாரித்து, அவர்களின் ஆரோக்கிய விவரங்களை குடும்பத்தினருக்கு உடனுக்குடன் தெரிவிக்கிறது.",
      ctaPrimary: "இலவசமாக தொடங்கவும்",
      ctaSecondary: "செயல்படும் விதம்",
      ctaDemoCall: "குரல் அழைப்பு டெமோவை முயற்சிக்கவும்",
      pipelineTitle: "தினசரி பராமரிப்பு சுழற்சி",
      steps: [
        { label: "முதியவர்", desc: "வீட்டில் வசிப்பவர்" },
        { label: "AI குரல் அழைப்பு", desc: "திட்டமிடப்பட்ட அழைப்பு" },
        { label: "முதியவர் பதில்", desc: "இயல்பான பேச்சு" },
        { label: "பேச்சு முதல் உரை", desc: "துல்லியமான உரை மாற்றி" },
        { label: "AI பகுப்பாய்வு", desc: "நலன் ஆய்வு" },
        { label: "கவன நிலை", desc: "குறைவு / நடுத்தரம் / அதிகம்" },
        { label: "குடும்ப தகவல்", desc: "SMS, WhatsApp & மின்னஞ்சல்" }
      ]
    },
    features: {
      title: "முழுமையான முதியோர் பராமரிப்பு",
      subtitle: "எந்த முதியவரும் தனிமையில் வாடாமல் இருக்கவும், குடும்பத்தினர் நிம்மதியாக இருக்கவும் உருவாக்கப்பட்ட சிறப்பம்சங்கள்.",
      items: [
        {
          id: 1,
          title: "தினசரி குரல் நலம் விசாரிப்பு",
          desc: "ஒரு அன்பான அண்டை வீட்டாரைப் போல தினமும் திட்டமிட்ட நேரத்தில் அழைத்து முதியோருடன் உரையாடுகிறது."
        },
        {
          id: 2,
          title: "மருந்து எடுத்துக்கொண்ட உறுதிப்படுத்தல்",
          desc: "தினசரி மருந்துகளை சரியான நேரத்தில் உட்கொண்டார்களா என்பதை நினைவூட்டி உறுதி செய்கிறது."
        },
        {
          id: 3,
          title: "மனநிலை மற்றும் ஆரோக்கியம்",
          desc: "அவர்களின் பேச்சின் மூலம் உற்சாகம், தனிமை அல்லது மனச்சோர்வை கனிவோடு கவனிக்கிறது."
        },
        {
          id: 4,
          title: "பாதுகாப்பு கேள்விகள்",
          desc: "தலைச்சுற்றல், கீழே விழுதல் அல்லது உடல் தளர்ச்சி போன்ற முக்கிய பாதுகாப்பு விஷயங்களை விசாரிக்கிறது."
        },
        {
          id: 5,
          title: "AI உரையாடல் பகுப்பாய்வு",
          desc: "மருத்துவ நோயறிதல் கூறாமல், அவர்கள் தெரிவித்த அசௌகரியங்களை குடும்பத்தினருக்கு தெளிவாக தொகுக்கிறது."
        },
        {
          id: 6,
          title: "குடும்ப அறிவிப்புகள்",
          desc: "SMS, WhatsApp மற்றும் மின்னஞ்சல் வாயிலாக உடனடியாக குடும்பத்தினருக்கு நிலை பற்றிய தகவல் அனுப்பப்படுகிறது."
        },
        {
          id: 7,
          title: "தமிழ் & ஆங்கில ஆதரவு",
          desc: "முதியவர்கள் தங்கள் தாய்மொழியான தமிழில் இயல்பாக, தங்குதடையின்றி பேசும் முழு ஆதரவு."
        },
        {
          id: 8,
          title: "மறுஅழைப்பு முறை (Retry)",
          desc: "முதியவர் போன் எடுக்கவில்லை என்றால் தானாகவே சிறிது நேரம் கழித்து மீண்டும் அழைத்து சோதிக்கிறது."
        }
      ]
    },
    howItWorks: {
      badge: "எளிய 6-படி செயல்முறை",
      title: "அன்பு வாய்ஸ் AI எவ்வாறு செயல்படுகிறது",
      subtitle: "முதியோர் பதிவு முதல் குடும்ப தகவல் வரை ஆறு எளிய படிகள்.",
      steps: [
        {
          number: "01",
          title: "குடும்ப உறுப்பினர் சுயவிவரம் உருவாக்குதல்",
          desc: "முதியவரின் பெயர், மொழி (தமிழ்/ஆங்கிலம்), மருந்துகள் மற்றும் அவசர தொடர்பு எண்களைப் பதிவு செய்யவும்."
        },
        {
          number: "02",
          title: "தினசரி அழைப்பு நேரத்தை அமைத்தல்",
          desc: "காலை அல்லது மாலையில் அவர்களுக்கு வசதியான அழைப்பு நேரத்தைத் தேர்ந்தெடுக்கவும்."
        },
        {
          number: "03",
          title: "AI முதியவரை அழைக்கிறது",
          desc: "குறிப்பிட்ட நேரத்தில் கணினி தானாகவே முதியவரின் சாதாரண தொலைபேசிக்கு அழைப்பு விடுக்கிறது."
        },
        {
          number: "04",
          title: "முதியவர் பதிலளிக்கிறார்",
          desc: "முதியவர் இயல்பாக நலம், மருந்து, வலி மற்றும் தூக்கம் குறித்த கேள்விகளுக்குப் பதிலளிக்கிறார்."
        },
        {
          number: "05",
          title: "AI பதிலைப் பகுப்பாய்வு செய்கிறது",
          desc: "அவர்களின் பேச்சு உரையாக மாற்றப்பட்டு, கவன நிலை (குறைவு, நடுத்தரம், அதிகம்) கணக்கிடப்படுகிறது."
        },
        {
          number: "06",
          title: "குடும்பத்திற்கு தகவல் சேர்கிறது",
          desc: "அழைப்பு முடிந்தவுடன் குடும்ப டாஷ்போர்டு மற்றும் WhatsApp/SMS-ல் உடனடி அறிக்கை பெறப்படுகிறது."
        }
      ]
    },
    dashboard: {
      title: "குடும்ப பராமரிப்பு டாஷ்போர்டு",
      welcomeBack: "வணக்கம்",
      stats: {
        totalSeniors: "மொத்த முதியவர்கள்",
        todaysCalls: "இன்றைய அழைப்புகள்",
        completedCalls: "முடிந்த அழைப்புகள்",
        missedCalls: "தவறிய அழைப்புகள்",
        activeAlerts: "செயலில் உள்ள எச்சரிக்கைகள்"
      },
      riskSummary: "கவன நிலை சுருக்கம்",
      riskLow: "குறைவு (LOW)",
      riskMedium: "நடுத்தரம் (MEDIUM)",
      riskHigh: "அதிகம் (HIGH)",
      charts: {
        riskTrend: "7-நாள் கவன நிலை போக்கு",
        callCompletion: "அழைப்பு முடிவு நிலை",
        moodTrend: "மனநிலை மற்றும் ஆற்றல் போக்கு",
        medicationConfirm: "மருந்து எடுத்துக்கொண்ட விகிதம்",
        weeklyActivity: "வாராந்திர அழைப்பு விவரங்கள்"
      },
      quickActions: "விரைவு நடவடிக்கைகள்",
      startDemoCall: "குரல் அழைப்பைத் தொடங்கு",
      addSenior: "முதியவரை சேர்க்க",
      viewAlerts: "எச்சரிக்கைகளைக் காண்க"
    },
    senior: {
      title: "முதியோர் சுயவிவரங்கள்",
      subtitle: "கண்காணிக்கப்படும் முதியவர்கள் மற்றும் அவர்களின் மருந்து அட்டவணையை நிர்வகிக்கவும்.",
      addBtn: "புதிய முதியவரை சேர்க்க",
      name: "முதியவர் பெயர்",
      age: "வயது",
      gender: "பாலினம்",
      phone: "தொலைபேசி எண்",
      relationship: "உறவுமுறை",
      language: "விருப்ப மொழி",
      medicalInfo: "மருத்துவ குறிப்புகள்",
      medications: "தற்போதைய மருந்துகள்",
      callTime: "தினசரி அழைப்பு நேரம்",
      status: "நிலை",
      riskLevel: "கவன நிலை",
      lastCheckin: "கடைசி அழைப்பு",
      nextCall: "அடுத்த அழைப்பு",
      emergencyContact: "அவசர தொடர்பு",
      emergencyName: "தொடர்பு நபர்",
      emergencyPhone: "தொடர்பு எண்",
      emergencyRelation: "உறவு",
      actions: "செயல்கள்",
      callNow: "இப்போதே அழைக்க",
      edit: "திருத்து",
      delete: "நீக்கு",
      view: "சுயவிவரம் காண்க",
      addedSuccess: "முதியவர் சுயவிவரம் வெற்றிகரமாக சேர்க்கப்பட்டது.",
      updatedSuccess: "முதியவர் சுயவிவரம் புதுப்பிக்கப்பட்டது.",
      deletedSuccess: "முதியவர் சுயவிவரம் நீக்கப்பட்டது."
    },
    voiceSimulator: {
      title: "குரல் அழைப்பு டெமோ சிமுலேட்டர்",
      subtitle: "நேரடி AI குரல் நலம் விசாரிப்பை உடனடியாக இயக்கிப் பாருங்கள். பேச்சு அறிதல் மற்றும் AI மதிப்பீடு உடனுக்குடன் கிடைக்கும்.",
      selectSenior: "முதியவரைத் தேர்ந்தெடுக்கவும்",
      scenario: "மாதிரி சூழலைத் தேர்ந்தெடுக்கவும்",
      scenarios: {
        healthy: "1. இயல்பான நலம் (மருந்து எடுத்தார், வலி இல்லை) -> LOW",
        mildConcern: "2. லேசான வலி & தூக்கமின்மை -> MEDIUM",
        highConcern: "3. தலைச்சுற்றல் & கடுமையான வலி -> HIGH",
        interactive: "4. தனிப்பயன் குரல் (மைக் அல்லது தட்டச்சு)"
      },
      status: {
        idle: "அழைக்க தயார்",
        calling: "முதியவரை அழைக்கிறது...",
        connected: "அழைப்பு இணைக்கப்பட்டது",
        asking: "AI கேள்வி கேட்கிறது...",
        listening: "முதியவரின் பதிலைக் கேட்கிறது...",
        processing: "பேச்சை உரையாக மாற்றுகிறது...",
        analyzing: "AI நலம் பகுப்பாய்வு செய்கிறது...",
        notifying: "குடும்பத்தினருக்கு தகவல் அனுப்புகிறது...",
        completed: "அழைப்பு நிறைவடைந்தது"
      },
      startCall: "டெமோ குரல் அழைப்பைத் தொடங்கு",
      endCall: "அழைப்பை முடி",
      seniorSpeaking: "முதியவர் பதில்",
      aiSpeaking: "AI உதவியாளர்",
      listenPrompt: "குரல் அலைவரிசை கேட்கப்படுகிறது...",
      enterManualResponse: "பதிலை தட்டச்சு செய்து அனுப்பவும்",
      nextQuestion: "அடுத்த கேள்வி",
      simulateAllQuestions: "முழு 6 கேள்விகளையும் இயக்கவும்",
      completedNotice: "அழைப்பு சேமிக்கப்பட்டது! உரை, AI பகுப்பாய்வு, கவன நிலை மற்றும் குடும்ப எச்சரிக்கைகள் டாஷ்போர்டில் புதுப்பிக்கப்பட்டுள்ளன.",
      viewFullAnalysis: "AI பகுப்பாய்வை விரிவாகக் காண்க"
    },
    analysis: {
      title: "AI நலன் பகுப்பாய்வு",
      subtitle: "முதியவரின் பதில்களில் உள்ள விவரங்களை மருத்துவ நோயறிதல் இல்லாமல் பொறுப்புடன் ஆராய்கிறது.",
      attentionTier: "ஒதுக்கப்பட்ட கவன நிலை",
      reportedConcerns: "தெரிவிக்கப்பட்ட அசௌகரியங்கள்",
      observations: "AI அவதானிப்புகள்",
      recommendations: "பரிந்துரைக்கப்படும் நடவடிக்கைகள்",
      transcriptHeading: "உரையாடல் பிரதி",
      disclaimerNotice: "தெரிவிக்கப்பட்ட விவரம் — அன்பு வாய்ஸ் AI உரையாடலை மட்டுமே கவனிக்கிறது, எந்த நோயையும் கண்டறியாது.",
      lowDesc: "முதியவர் நலமாக உள்ளார், மருந்துகளை உறுதி செய்தார், வலி அல்லது தலைச்சுற்றல் இல்லை. வழக்கமான குடும்ப தகவல் அனுப்பப்பட்டது.",
      mediumDesc: "லேசான அசௌகரியம், தூக்கமின்மை அல்லது தவறவிட்ட மருந்து குறித்து தெரிவித்துள்ளார். குடும்பத்தினர் கவனிப்பது நல்லது.",
      highDesc: "தலைச்சுற்றல், கடுமையான வலி போன்ற தீவிரமான விஷயங்கள் தெரிவிக்கப்பட்டுள்ளன. உடனடியாக முதியவரை நேரில் தொடர்பு கொள்ளவும்."
    },
    communication: {
      title: "குடும்ப தொடர்பு & மறுஅழைப்பு அமைப்பு",
      subtitle: "அழைப்பு நிலைகள், பல வழிகளில் தகவல் அனுப்புதல் மற்றும் பதில் தராத அழைப்புகளை தானாக மறுஅழைக்கும் முறை.",
      todaysCalls: "இன்றைய அழைப்புகள்",
      noAnswerEngine: "பதில் தராத அழைப்பு மறுமுயற்சி இயந்திரம்",
      noAnswerSteps: [
        { label: "திட்டமிட்ட அழைப்பு", desc: "முதல் முயற்சி" },
        { label: "முயற்சி 1: பதில் இல்லை", desc: "45 வினாடிகள் அழைப்பு சென்றும் எடுக்கவில்லை" },
        { label: "தானியங்கி மறுமுயற்சி", desc: "10 நிமிடங்களுக்குப் பிறகு மீண்டும் அழைக்கும்" },
        { label: "முயற்சி 2: பதில் இல்லை", desc: "இரண்டாம் முறையும் எடுக்கப்படவில்லை" },
        { label: "குடும்பத்திற்கு உடனடி எச்சரிக்கை", desc: "குடும்பத்தினருக்கு அவசர தகவல் அனுப்பப்பட்டது" }
      ],
      channelsTitle: "தகவல் முன்னோட்டம் (Preview)",
      smsTab: "SMS எச்சரிக்கை",
      whatsappTab: "WhatsApp எச்சரிக்கை",
      emailTab: "மின்னஞ்சல் எச்சரிக்கை",
      simulateNoAnswer: "பதில் தராத சூழலை சோதித்துப் பார்க்கவும்"
    },
    notifications: {
      title: "அறிவிப்பு மையம்",
      markAllRead: "அனைத்தையும் படித்ததாகக் குறிக்க",
      all: "அனைத்தும்",
      unread: "படிக்காதவை",
      empty: "தற்போது எந்த அறிவிப்பும் இல்லை."
    },
    safety: {
      title: "மருத்துவ பாதுகாப்பு மற்றும் அறநெறி வழிகாட்டுதல்கள்",
      headline: "முதியோர் நலனுக்காக உருவாக்கப்பட்ட கண்டிப்பான பாதுகாப்பு விதிகள்",
      disclaimerFull: "அன்பு வாய்ஸ் AI ஆதரவான கண்காணிப்பு மற்றும் ஆரம்ப நுண்ணறிவுகளை மட்டுமே வழங்குகிறது. இது மருத்துவ நோயறிதலை வழங்காது அல்லது தொழில்முறை மருத்துவ சிகிச்சையை மாற்றாது.",
      rules: [
        {
          rule: "மருத்துவ நோயறிதல் கிடையாது",
          desc: "கணினி 'தெரிவிக்கப்பட்ட அசௌகரியம்' போன்ற சொற்களையே பயன்படுத்தும். எந்த நோயையும் தானாக தீர்மானிக்காது."
        },
        {
          rule: "மருந்து பரிந்துரை கிடையாது",
          desc: "குடும்பத்தினர் குறிப்பிட்ட மருந்துகளை எடுத்தார்களா என்பதை மட்டுமே சரிபார்க்கும், மருந்துகளின் அளவை மாற்றாது."
        },
        {
          rule: "உடனடி குடும்ப எச்சரிக்கை",
          desc: "அதிக கவன நிலை (HIGH) ஏற்பட்டால்: 'தயவுசெய்து முதியவரை உடனடியாக நேரில் சரிபார்த்து, தேவைப்பட்டால் மருத்துவ உதவியை அணுகவும்' என்று எச்சரிக்கிறது."
        },
        {
          rule: "மரியாதை மற்றும் கனிவு",
          desc: "முதியவர்களிடம் மெதுவாகவும், பொறுமையாகவும், அன்பான வார்த்தைகளுடனும் பேசும் வகையில் வடிவமைக்கப்பட்டுள்ளது."
        }
      ]
    },
    admin: {
      title: "கணினி நிர்வாகம் (Admin)",
      totalFamilies: "பதிவுசெய்த குடும்பங்கள்",
      totalSeniors: "கண்காணிக்கப்படும் முதியவர்கள்",
      todaysVolume: "இன்றைய மொத்த அழைப்புகள்",
      systemHealth: "சேவை இயக்கம் (100%)",
      questionEditor: "கேள்வி வார்ப்புருக்கள்",
      telemetry: "டெமோ முறை முழுமையாக இயங்குகிறது"
    }
  }
};
