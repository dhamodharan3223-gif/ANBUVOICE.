export type Language = 'en' | 'ta';

export type AttentionLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export type CallStatus = 'Scheduled' | 'Calling' | 'Connected' | 'Completed' | 'Missed' | 'Retrying' | 'Failed';

export interface EmergencyContact {
  name: string;
  relationship: string;
  phone: string;
}

export interface SeniorProfile {
  id: string;
  name: string;
  age: number;
  gender: 'Female' | 'Male' | 'Other';
  phone: string;
  relationship: string;
  language: Language;
  medicalInformation: string;
  medications: string[];
  emergencyContact: EmergencyContact;
  dailyCallTime: string; // e.g. "09:30 AM"
  timeZone: string;
  callFrequency: 'Daily' | 'Twice Daily' | 'Weekdays Only';
  isCallEnabled: boolean;
  status: 'Active' | 'Inactive';
  lastCheckIn?: string;
  lastAttentionLevel?: AttentionLevel;
  nextCall?: string;
  avatarUrl?: string;
}

export interface QuestionResponse {
  questionId: number;
  questionEn: string;
  questionTa: string;
  category: 'general' | 'medication' | 'pain' | 'safety' | 'sleep' | 'mood';
  answerText: string;
  flaggedConcern?: boolean;
}

export interface AIAnalysisResult {
  attentionLevel: AttentionLevel;
  summary: string;
  observations: string[];
  recommendedAction: string;
  metrics: {
    moodScore: 'Good' | 'Fair' | 'Low';
    medicationConfirmed: boolean;
    painReported: boolean;
    painDetails?: string;
    fallOrDizzinessReported: boolean;
    sleepQuality: 'Good' | 'Restless' | 'Poor';
  };
  disclaimer: string;
}

export interface CallRecord {
  id: string;
  seniorId: string;
  seniorName: string;
  callDate: string;
  callTime: string;
  durationSeconds: number;
  status: CallStatus;
  retryAttempt?: number;
  language: Language;
  transcript: QuestionResponse[];
  attentionLevel: AttentionLevel;
  aiSummary: string;
  aiAnalysis?: AIAnalysisResult;
  familyNotificationSent: boolean;
  notificationChannels: ('SMS' | 'WhatsApp' | 'Email')[];
}

export interface NotificationItem {
  id: string;
  seniorId: string;
  seniorName: string;
  type: 'completed' | 'medium_attention' | 'high_attention' | 'missed' | 'medication_confirmed';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  attentionLevel?: AttentionLevel;
  callRecordId?: string;
}

export interface AlertItem {
  id: string;
  seniorId: string;
  seniorName: string;
  attentionLevel: AttentionLevel;
  concern: string;
  timestamp: string;
  status: 'Active' | 'Acknowledged' | 'Resolved';
  actionTaken?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'family' | 'admin';
}

export interface DashboardStats {
  totalSeniors: number;
  todaysCalls: number;
  completedCalls: number;
  missedCalls: number;
  activeAlerts: number;
  riskSummary: {
    low: number;
    medium: number;
    high: number;
  };
}
