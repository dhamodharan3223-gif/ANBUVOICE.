import { SeniorProfile, CallRecord, AlertItem, NotificationItem, DashboardStats, AIAnalysisResult, User } from '../types';

const STORAGE_KEYS = {
  SENIORS: 'anbuvoice_seniors',
  CALLS: 'anbuvoice_calls',
  ALERTS: 'anbuvoice_alerts',
  NOTIFS: 'anbuvoice_notifs',
  USER: 'anbuvoice_user',
  TOKEN: 'anbuvoice_token',
  LANG: 'anbuvoice_lang'
};

const DEFAULT_SENIORS: SeniorProfile[] = [
  {
    id: 'sen-1',
    name: 'Lakshmi Devi',
    age: 74,
    gender: 'Female',
    phone: '+91 98401 23456',
    relationship: 'Mother',
    language: 'ta',
    medicalInformation: 'Mild hypertension, early osteoarthritis in knees.',
    medications: ['Amlodipine 5mg (Morning)', 'Calcium D3 supplement'],
    emergencyContact: {
      name: 'Karthik Sundaram',
      relationship: 'Son',
      phone: '+91 98401 55667'
    },
    dailyCallTime: '09:00 AM',
    timeZone: 'Asia/Kolkata (IST)',
    callFrequency: 'Daily',
    isCallEnabled: true,
    status: 'Active',
    lastCheckIn: 'Today, 09:02 AM',
    lastAttentionLevel: 'LOW',
    nextCall: 'Tomorrow, 09:00 AM',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=256&q=80'
  },
  {
    id: 'sen-2',
    name: 'Ramanathan Iyer',
    age: 81,
    gender: 'Male',
    phone: '+91 94440 87654',
    relationship: 'Father',
    language: 'ta',
    medicalInformation: 'Type 2 Diabetes, history of mild postural vertigo.',
    medications: ['Metformin 500mg (Post-breakfast)', 'Atorvastatin 10mg'],
    emergencyContact: {
      name: 'Karthik Sundaram',
      relationship: 'Son',
      phone: '+91 98401 55667'
    },
    dailyCallTime: '09:30 AM',
    timeZone: 'Asia/Kolkata (IST)',
    callFrequency: 'Daily',
    isCallEnabled: true,
    status: 'Active',
    lastCheckIn: 'Today, 09:32 AM',
    lastAttentionLevel: 'HIGH',
    nextCall: 'Tomorrow, 09:30 AM',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80'
  },
  {
    id: 'sen-3',
    name: 'Mary Joseph',
    age: 76,
    gender: 'Female',
    phone: '+91 98840 54321',
    relationship: 'Aunt',
    language: 'en',
    medicalInformation: 'Mild asthma, mild insomnia.',
    medications: ['Salbutamol Inhaler (PRN)', 'Melatonin 3mg'],
    emergencyContact: {
      name: 'Karthik Sundaram',
      relationship: 'Nephew',
      phone: '+91 98401 55667'
    },
    dailyCallTime: '10:00 AM',
    timeZone: 'Asia/Kolkata (IST)',
    callFrequency: 'Daily',
    isCallEnabled: true,
    status: 'Active',
    lastCheckIn: 'Yesterday, 10:01 AM',
    lastAttentionLevel: 'MEDIUM',
    nextCall: 'Today, 10:00 AM',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=256&q=80'
  }
];

const DEFAULT_CALLS: CallRecord[] = [
  {
    id: 'call-101',
    seniorId: 'sen-1',
    seniorName: 'Lakshmi Devi',
    callDate: new Date().toISOString().split('T')[0],
    callTime: '09:02 AM',
    durationSeconds: 142,
    status: 'Completed',
    language: 'ta',
    transcript: [
      { questionId: 1, questionEn: "Are you feeling well today?", questionTa: "இன்று நீங்கள் நலமாக இருக்கிறீர்களா?", category: "general", answerText: "ஆம், நான் இன்று மிகவும் நன்றாக இருக்கிறேன். காலையில் வாக்கிங் சென்றேன்." },
      { questionId: 2, questionEn: "Did you take your medicine?", questionTa: "இன்று உங்கள் மருந்தை எடுத்துக்கொண்டீர்களா?", category: "medication", answerText: "ஆமாம், காலை உணவுக்குப் பிறகு இரத்த அழுத்த மாத்திரை எடுத்துக்கொண்டேன்." },
      { questionId: 3, questionEn: "Are you experiencing any pain?", questionTa: "உங்களுக்கு ஏதேனும் வலி இருக்கிறதா?", category: "pain", answerText: "இல்லை, பெரிய வலி எதுவும் இல்லை." },
      { questionId: 4, questionEn: "Did you fall or feel dizzy?", questionTa: "நீங்கள் கீழே விழுந்தீர்களா அல்லது தலைச்சுற்றல் ஏற்பட்டதா?", category: "safety", answerText: "இல்லை, எந்த மயக்கமும் வரவில்லை." },
      { questionId: 5, questionEn: "How was your sleep?", questionTa: "நேற்று இரவு உங்கள் தூக்கம் எப்படி இருந்தது?", category: "sleep", answerText: "நேற்று இரவு அமைதியாக 7 மணி நேரம் தூங்கினேன்." },
      { questionId: 6, questionEn: "How are you feeling emotionally today?", questionTa: "இன்று உங்கள் மனநிலை எப்படி இருக்கிறது?", category: "mood", answerText: "மனசுக்கு நிம்மதியாகவும் மகிழ்ச்சியாகவும் இருக்கிறது." }
    ],
    attentionLevel: 'LOW',
    aiSummary: "Senior reported feeling well and confirmed morning hypertension medication. No pain, dizziness, or sleep issues reported.",
    familyNotificationSent: true,
    notificationChannels: ['SMS', 'WhatsApp']
  },
  {
    id: 'call-102',
    seniorId: 'sen-2',
    seniorName: 'Ramanathan Iyer',
    callDate: new Date().toISOString().split('T')[0],
    callTime: '09:32 AM',
    durationSeconds: 165,
    status: 'Completed',
    language: 'ta',
    transcript: [
      { questionId: 1, questionEn: "Are you feeling well today?", questionTa: "இன்று நீங்கள் நலமாக இருக்கிறீர்களா?", category: "general", answerText: "இன்று உடல் கொஞ்சம் சோர்வாக இருக்கிறது." },
      { questionId: 2, questionEn: "Did you take your medicine?", questionTa: "இன்று உங்கள் மருந்தை எடுத்துக்கொண்டீர்களா?", category: "medication", answerText: "இன்னும் எடுக்கவில்லை, பசி எடுக்கவில்லை என்று தள்ளிப் போட்டேன்." },
      { questionId: 3, questionEn: "Are you experiencing any pain?", questionTa: "உங்களுக்கு ஏதேனும் வலி இருக்கிறதா?", category: "pain", answerText: "முதுகிலும் வலது காலிலும் கடுமையான வலி இருக்கிறது.", flaggedConcern: true },
      { questionId: 4, questionEn: "Did you fall or feel dizzy?", questionTa: "நீங்கள் கீழே விழுந்தீர்களா அல்லது தலைச்சுற்றல் ஏற்பட்டதா?", category: "safety", answerText: "காலையில் எழுந்திருக்கும்போது லேசாக தலை சுற்றியது, சுவரைப் பிடித்துக் கொண்டேன்.", flaggedConcern: true },
      { questionId: 5, questionEn: "How was your sleep?", questionTa: "நேற்று இரவு உங்கள் தூக்கம் எப்படி இருந்தது?", category: "sleep", answerText: "வலி காரணமாக சரியாக தூங்க முடியவில்லை." },
      { questionId: 6, questionEn: "How are you feeling emotionally today?", questionTa: "இன்று உங்கள் மனநிலை எப்படி இருக்கிறது?", category: "mood", answerText: "கொஞ்சம் பயமாகவும் தனிமையாகவும் இருக்கிறது." }
    ],
    attentionLevel: 'HIGH',
    aiSummary: "Reported concern: Senior described morning dizziness with postural unsteadiness and severe leg/back discomfort. Medication delayed and sleep disturbed. Urgent family check recommended.",
    familyNotificationSent: true,
    notificationChannels: ['SMS', 'WhatsApp', 'Email']
  },
  {
    id: 'call-103',
    seniorId: 'sen-3',
    seniorName: 'Mary Joseph',
    callDate: new Date(Date.now() - 86400000).toISOString().split('T')[0],
    callTime: '10:01 AM',
    durationSeconds: 130,
    status: 'Completed',
    language: 'en',
    transcript: [
      { questionId: 1, questionEn: "Are you feeling well today?", questionTa: "இன்று நீங்கள் நலமாக இருக்கிறீர்களா?", category: "general", answerText: "I am feeling okay, just a little tired today." },
      { questionId: 2, questionEn: "Did you take your medicine?", questionTa: "இன்று உங்கள் மருந்தை எடுத்துக்கொண்டீர்களா?", category: "medication", answerText: "I took my vitamin, but forgot the morning syrup." },
      { questionId: 3, questionEn: "Are you experiencing any pain?", questionTa: "உங்களுக்கு ஏதேனும் வலி இருக்கிறதா?", category: "pain", answerText: "Mild stiffness in my shoulders from the cold weather." },
      { questionId: 4, questionEn: "Did you fall or feel dizzy?", questionTa: "நீங்கள் கீழே விழுந்தீர்களா அல்லது தலைச்சுற்றல் ஏற்பட்டதா?", category: "safety", answerText: "No falls, balance is fine." },
      { questionId: 5, questionEn: "How was your sleep?", questionTa: "நேற்று இரவு உங்கள் தூக்கம் எப்படி இருந்தது?", category: "sleep", answerText: "Woke up twice during the night, feeling somewhat restless." },
      { questionId: 6, questionEn: "How are you feeling emotionally today?", questionTa: "இன்று உங்கள் மனநிலை எப்படி இருக்கிறது?", category: "mood", answerText: "Doing alright, spoke with my sister yesterday." }
    ],
    attentionLevel: 'MEDIUM',
    aiSummary: "Reported concern: Mild joint stiffness and restless sleep reported; one morning medication was delayed. Caregiver follow-up advised.",
    familyNotificationSent: true,
    notificationChannels: ['SMS', 'WhatsApp']
  }
];

const DEFAULT_ALERTS: AlertItem[] = [
  {
    id: 'alt-1',
    seniorId: 'sen-2',
    seniorName: 'Ramanathan Iyer',
    attentionLevel: 'HIGH',
    concern: 'Reported morning dizziness upon standing and delayed medication. Advised urgent check on senior.',
    timestamp: 'Today, 09:34 AM',
    status: 'Active'
  },
  {
    id: 'alt-2',
    seniorId: 'sen-3',
    seniorName: 'Mary Joseph',
    attentionLevel: 'MEDIUM',
    concern: 'Missed morning medication and reported interrupted sleep.',
    timestamp: 'Yesterday, 10:04 AM',
    status: 'Acknowledged',
    actionTaken: 'Caregiver called to confirm medication taken.'
  }
];

const DEFAULT_NOTIFS: NotificationItem[] = [
  {
    id: 'notif-1',
    seniorId: 'sen-2',
    seniorName: 'Ramanathan Iyer',
    type: 'high_attention',
    title: '🚨 Urgent: High Attention Alert',
    message: 'Ramanathan reported dizziness and missed medication today. Please check on senior directly.',
    timestamp: 'Today, 09:34 AM',
    read: false,
    attentionLevel: 'HIGH'
  },
  {
    id: 'notif-2',
    seniorId: 'sen-1',
    seniorName: 'Lakshmi Devi',
    type: 'completed',
    title: '✓ Check-in Completed: All Normal',
    message: 'Lakshmi Devi completed her daily voice check-in. All responses normal, medications confirmed.',
    timestamp: 'Today, 09:03 AM',
    read: true,
    attentionLevel: 'LOW'
  },
  {
    id: 'notif-3',
    seniorId: 'sen-3',
    seniorName: 'Mary Joseph',
    type: 'medium_attention',
    title: '⚠ Medium Attention: Caregiver Review',
    message: 'Mary reported mild stiffness and missed morning syrup.',
    timestamp: 'Yesterday, 10:05 AM',
    read: true,
    attentionLevel: 'MEDIUM'
  }
];

class ApiClient {
  private getLocal<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  private setLocal<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  }

  async login(email: string, _password?: string): Promise<{ success: boolean; user: User; token: string }> {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: _password })
      });
      if (res.ok) {
        const data = await res.json();
        this.setLocal(STORAGE_KEYS.USER, data.user);
        this.setLocal(STORAGE_KEYS.TOKEN, data.token);
        return data;
      }
    } catch {
      // Fallback
    }

    const fallbackUser: User = {
      id: 'u-1',
      name: email === 'family@example.com' ? 'Karthik Sundaram' : (email.split('@')[0] || 'Caregiver'),
      email,
      phone: '+91 98401 55667',
      role: 'family'
    };
    this.setLocal(STORAGE_KEYS.USER, fallbackUser);
    this.setLocal(STORAGE_KEYS.TOKEN, 'jwt-demo-token-anbuvoice');
    return { success: true, user: fallbackUser, token: 'jwt-demo-token-anbuvoice' };
  }

  async register(name: string, email: string, phone: string, _password?: string): Promise<{ success: boolean; user: User }> {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone })
      });
      if (res.ok) {
        const data = await res.json();
        this.setLocal(STORAGE_KEYS.USER, data.user);
        return data;
      }
    } catch {
      // Fallback
    }

    const user: User = {
      id: `u-${Date.now()}`,
      name,
      email,
      phone,
      role: 'family'
    };
    this.setLocal(STORAGE_KEYS.USER, user);
    return { success: true, user };
  }

  getCurrentUser(): User | null {
    return this.getLocal<User | null>(STORAGE_KEYS.USER, {
      id: 'u-1',
      name: 'Karthik Sundaram',
      email: 'family@example.com',
      phone: '+91 98401 55667',
      role: 'family'
    });
  }

  logout(): void {
    localStorage.removeItem(STORAGE_KEYS.USER);
    localStorage.removeItem(STORAGE_KEYS.TOKEN);
  }

  async getSeniors(): Promise<SeniorProfile[]> {
    try {
      const res = await fetch('/api/seniors');
      if (res.ok) {
        const data = await res.json();
        if (data.seniors && data.seniors.length > 0) {
          this.setLocal(STORAGE_KEYS.SENIORS, data.seniors);
          return data.seniors;
        }
      }
    } catch {
      // Fallback
    }
    return this.getLocal<SeniorProfile[]>(STORAGE_KEYS.SENIORS, DEFAULT_SENIORS);
  }

  async addSenior(seniorData: Partial<SeniorProfile>): Promise<SeniorProfile> {
    try {
      const res = await fetch('/api/seniors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(seniorData)
      });
      if (res.ok) {
        const data = await res.json();
        const current = this.getLocal<SeniorProfile[]>(STORAGE_KEYS.SENIORS, DEFAULT_SENIORS);
        this.setLocal(STORAGE_KEYS.SENIORS, [data.senior, ...current]);
        return data.senior;
      }
    } catch {
      // Fallback
    }

    const newSenior: SeniorProfile = {
      id: `sen-${Date.now()}`,
      name: seniorData.name || 'Senior',
      age: seniorData.age || 70,
      gender: seniorData.gender || 'Female',
      phone: seniorData.phone || '+91 98400 00000',
      relationship: seniorData.relationship || 'Relative',
      language: seniorData.language || 'en',
      medicalInformation: seniorData.medicalInformation || 'None noted',
      medications: seniorData.medications || [],
      emergencyContact: seniorData.emergencyContact || {
        name: 'Family Contact',
        relationship: 'Son',
        phone: '+91 98400 00000'
      },
      dailyCallTime: seniorData.dailyCallTime || '09:00 AM',
      timeZone: seniorData.timeZone || 'Asia/Kolkata (IST)',
      callFrequency: seniorData.callFrequency || 'Daily',
      isCallEnabled: true,
      status: 'Active',
      lastCheckIn: 'Not called yet',
      lastAttentionLevel: 'LOW',
      nextCall: `Tomorrow, ${seniorData.dailyCallTime || '09:00 AM'}`
    };

    const current = this.getLocal<SeniorProfile[]>(STORAGE_KEYS.SENIORS, DEFAULT_SENIORS);
    const updated = [newSenior, ...current];
    this.setLocal(STORAGE_KEYS.SENIORS, updated);
    return newSenior;
  }

  async updateSenior(id: string, updates: Partial<SeniorProfile>): Promise<SeniorProfile | null> {
    try {
      const res = await fetch(`/api/seniors/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        const data = await res.json();
        return data.senior;
      }
    } catch {
      // Fallback
    }

    const current = this.getLocal<SeniorProfile[]>(STORAGE_KEYS.SENIORS, DEFAULT_SENIORS);
    const index = current.findIndex(s => s.id === id);
    if (index !== -1) {
      current[index] = { ...current[index], ...updates };
      this.setLocal(STORAGE_KEYS.SENIORS, current);
      return current[index];
    }
    return null;
  }

  async deleteSenior(id: string): Promise<boolean> {
    try {
      await fetch(`/api/seniors/${id}`, { method: 'DELETE' });
    } catch {
      // Fallback
    }

    const current = this.getLocal<SeniorProfile[]>(STORAGE_KEYS.SENIORS, DEFAULT_SENIORS);
    const updated = current.filter(s => s.id !== id);
    this.setLocal(STORAGE_KEYS.SENIORS, updated);
    return true;
  }

  async getCalls(): Promise<CallRecord[]> {
    try {
      const res = await fetch('/api/calls');
      if (res.ok) {
        const data = await res.json();
        if (data.calls && data.calls.length > 0) {
          this.setLocal(STORAGE_KEYS.CALLS, data.calls);
          return data.calls;
        }
      }
    } catch {
      // Fallback
    }
    return this.getLocal<CallRecord[]>(STORAGE_KEYS.CALLS, DEFAULT_CALLS);
  }

  async saveCallRecord(callData: Partial<CallRecord>): Promise<CallRecord> {
    try {
      const res = await fetch('/api/calls/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(callData)
      });
      if (res.ok) {
        const data = await res.json();
        const currentCalls = this.getLocal<CallRecord[]>(STORAGE_KEYS.CALLS, DEFAULT_CALLS);
        this.setLocal(STORAGE_KEYS.CALLS, [data.call, ...currentCalls]);
        return data.call;
      }
    } catch {
      // Fallback
    }

    const newCall: CallRecord = {
      id: `call-${Date.now()}`,
      seniorId: callData.seniorId || 'sen-1',
      seniorName: callData.seniorName || 'Senior',
      callDate: callData.callDate || new Date().toISOString().split('T')[0],
      callTime: callData.callTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      durationSeconds: callData.durationSeconds || 120,
      status: callData.status || 'Completed',
      retryAttempt: callData.retryAttempt || 1,
      language: callData.language || 'en',
      transcript: callData.transcript || [],
      attentionLevel: callData.attentionLevel || 'LOW',
      aiSummary: callData.aiSummary || 'Voice check-in completed.',
      aiAnalysis: callData.aiAnalysis,
      familyNotificationSent: true,
      notificationChannels: callData.notificationChannels || ['SMS', 'WhatsApp']
    };

    const currentCalls = this.getLocal<CallRecord[]>(STORAGE_KEYS.CALLS, DEFAULT_CALLS);
    this.setLocal(STORAGE_KEYS.CALLS, [newCall, ...currentCalls]);

    // Update senior last checkin
    const seniors = this.getLocal<SeniorProfile[]>(STORAGE_KEYS.SENIORS, DEFAULT_SENIORS);
    const sIndex = seniors.findIndex(s => s.id === newCall.seniorId);
    if (sIndex !== -1) {
      seniors[sIndex].lastCheckIn = `Today, ${newCall.callTime}`;
      seniors[sIndex].lastAttentionLevel = newCall.attentionLevel;
      this.setLocal(STORAGE_KEYS.SENIORS, seniors);
    }

    // Add alert if medium or high
    if (newCall.attentionLevel !== 'LOW') {
      const alerts = this.getLocal<AlertItem[]>(STORAGE_KEYS.ALERTS, DEFAULT_ALERTS);
      alerts.unshift({
        id: `alt-${Date.now()}`,
        seniorId: newCall.seniorId,
        seniorName: newCall.seniorName,
        attentionLevel: newCall.attentionLevel,
        concern: newCall.aiSummary,
        timestamp: `Today, ${newCall.callTime}`,
        status: 'Active'
      });
      this.setLocal(STORAGE_KEYS.ALERTS, alerts);
    }

    // Add notification
    const notifs = this.getLocal<NotificationItem[]>(STORAGE_KEYS.NOTIFS, DEFAULT_NOTIFS);
    const notifTitle = newCall.attentionLevel === 'HIGH' ? '🚨 Urgent: High Attention Alert' :
                      (newCall.attentionLevel === 'MEDIUM' ? '⚠ Attention: Wellbeing Concern' : '✓ Check-in Completed');
    notifs.unshift({
      id: `notif-${Date.now()}`,
      seniorId: newCall.seniorId,
      seniorName: newCall.seniorName,
      type: newCall.attentionLevel === 'HIGH' ? 'high_attention' : (newCall.attentionLevel === 'MEDIUM' ? 'medium_attention' : 'completed'),
      title: notifTitle,
      message: newCall.aiSummary,
      timestamp: `Today, ${newCall.callTime}`,
      read: false,
      attentionLevel: newCall.attentionLevel
    });
    this.setLocal(STORAGE_KEYS.NOTIFS, notifs);

    return newCall;
  }

  async analyzeTranscript(
    transcript: Array<{ category: string; answerText: string }>,
    seniorName: string,
    language: 'en' | 'ta'
  ): Promise<AIAnalysisResult> {
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transcript, seniorName, language })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.analysis) {
          return data.analysis;
        }
      }
    } catch {
      // Fallback
    }

    // Client-side heuristic analyzer
    let hasFallOrDizzy = false;
    let hasSeverePain = false;
    let hasMissedMeds = false;
    let hasPoorSleep = false;
    let lowMood = false;
    const observations: string[] = [];

    for (const item of transcript) {
      const text = (item.answerText || '').toLowerCase();
      if (item.category === 'safety' && (text.includes('dizzy') || text.includes('fall') || text.includes('மயக்கம்') || text.includes('தலைச்சுற்றல்') || text.includes('விழுந்தேன்'))) {
        hasFallOrDizzy = true;
        observations.push("Reported concern: Senior described dizziness or balance unsteadiness.");
      }
      if (item.category === 'pain') {
        if (text.includes('severe') || text.includes('chest') || text.includes('கடுமையான') || text.includes('தாங்க முடியாத')) {
          hasSeverePain = true;
          observations.push("Reported concern: Severe discomfort or acute pain noted.");
        } else if (text.includes('pain') || text.includes('stiff') || text.includes('வலி')) {
          observations.push("Reported concern: Mild body stiffness or joint pain noted.");
        }
      }
      if (item.category === 'medication') {
        if (text.includes('no') || text.includes('forgot') || text.includes('later') || text.includes('இல்லை') || text.includes('மறந்து') || text.includes('எடுக்கவில்லை')) {
          hasMissedMeds = true;
          observations.push("Reported concern: Scheduled medication not confirmed.");
        } else {
          observations.push("Medication adherence: Routine medication verbally confirmed.");
        }
      }
      if (item.category === 'sleep' && (text.includes('poor') || text.includes('restless') || text.includes('சரியாக தூங்கவில்லை'))) {
        hasPoorSleep = true;
        observations.push("Sleep assessment: Senior reported sleep difficulties.");
      }
      if (item.category === 'mood' && (text.includes('lonely') || text.includes('sad') || text.includes('பயம்') || text.includes('தனிமை'))) {
        lowMood = true;
        observations.push("Emotional wellbeing: Feelings of loneliness or anxiety expressed.");
      }
    }

    let attentionLevel: 'LOW' | 'MEDIUM' | 'HIGH' = 'LOW';
    let summary = "Senior reported feeling well and confirmed medication. No immediate concerns identified.";
    let recommendedAction = "Routine family dashboard update dispatched. Continue regular monitoring.";

    if (hasFallOrDizzy || hasSeverePain) {
      attentionLevel = 'HIGH';
      summary = "Reported concern: Senior reported safety-related concerns (dizziness or acute pain). Urgent family check recommended.";
      recommendedAction = "Please check on the senior directly and seek appropriate professional or emergency help when necessary.";
    } else if (hasMissedMeds || hasPoorSleep || lowMood || observations.some(o => o.includes('stiffness'))) {
      attentionLevel = 'MEDIUM';
      summary = "Reported concern: Mild discomfort, disturbed sleep, or delayed medication was noted.";
      recommendedAction = "Family notification sent. Caregiver check-in recommended within a few hours.";
    }

    if (observations.length === 0) {
      observations.push("Senior spoke comfortably during check-in.");
      observations.push("No acute wellbeing concerns were raised.");
    }

    return {
      attentionLevel,
      summary,
      observations,
      recommendedAction,
      metrics: {
        moodScore: lowMood ? 'Low' : (hasPoorSleep ? 'Fair' : 'Good'),
        medicationConfirmed: !hasMissedMeds,
        painReported: hasSeverePain || observations.some(o => o.includes('stiffness')),
        fallOrDizzinessReported: hasFallOrDizzy,
        sleepQuality: hasPoorSleep ? 'Restless' : 'Good'
      },
      disclaimer: "AnbuVoice AI provides supportive monitoring and early insights. It does not provide medical diagnosis or replace professional medical care."
    };
  }

  async getDashboardStats(): Promise<DashboardStats> {
    try {
      const res = await fetch('/api/dashboard');
      if (res.ok) {
        const data = await res.json();
        if (data.stats) return data.stats;
      }
    } catch {
      // Fallback
    }

    const seniors = this.getLocal<SeniorProfile[]>(STORAGE_KEYS.SENIORS, DEFAULT_SENIORS);
    const calls = this.getLocal<CallRecord[]>(STORAGE_KEYS.CALLS, DEFAULT_CALLS);
    const alerts = this.getLocal<AlertItem[]>(STORAGE_KEYS.ALERTS, DEFAULT_ALERTS);

    return {
      totalSeniors: seniors.length,
      todaysCalls: calls.length,
      completedCalls: calls.filter(c => c.status === 'Completed').length,
      missedCalls: calls.filter(c => c.status === 'Missed').length,
      activeAlerts: alerts.filter(a => a.status === 'Active').length,
      riskSummary: {
        low: calls.filter(c => c.attentionLevel === 'LOW').length,
        medium: calls.filter(c => c.attentionLevel === 'MEDIUM').length,
        high: calls.filter(c => c.attentionLevel === 'HIGH').length
      }
    };
  }

  async getAlerts(): Promise<AlertItem[]> {
    try {
      const res = await fetch('/api/alerts');
      if (res.ok) {
        const data = await res.json();
        if (data.alerts) {
          this.setLocal(STORAGE_KEYS.ALERTS, data.alerts);
          return data.alerts;
        }
      }
    } catch {
      // Fallback
    }
    return this.getLocal<AlertItem[]>(STORAGE_KEYS.ALERTS, DEFAULT_ALERTS);
  }

  async acknowledgeAlert(id: string, actionTaken: string): Promise<boolean> {
    try {
      await fetch(`/api/alerts/${id}/acknowledge`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ actionTaken })
      });
    } catch {
      // Fallback
    }

    const alerts = this.getLocal<AlertItem[]>(STORAGE_KEYS.ALERTS, DEFAULT_ALERTS);
    const alert = alerts.find(a => a.id === id);
    if (alert) {
      alert.status = 'Acknowledged';
      alert.actionTaken = actionTaken;
      this.setLocal(STORAGE_KEYS.ALERTS, alerts);
      return true;
    }
    return false;
  }

  async getNotifications(): Promise<NotificationItem[]> {
    try {
      const res = await fetch('/api/notifications');
      if (res.ok) {
        const data = await res.json();
        if (data.notifications) {
          this.setLocal(STORAGE_KEYS.NOTIFS, data.notifications);
          return data.notifications;
        }
      }
    } catch {
      // Fallback
    }
    return this.getLocal<NotificationItem[]>(STORAGE_KEYS.NOTIFS, DEFAULT_NOTIFS);
  }

  async markNotificationRead(id: string): Promise<boolean> {
    try {
      await fetch(`/api/notifications/${id}/read`, { method: 'PUT' });
    } catch {
      // Fallback
    }
    const notifs = this.getLocal<NotificationItem[]>(STORAGE_KEYS.NOTIFS, DEFAULT_NOTIFS);
    const n = notifs.find(item => item.id === id);
    if (n) {
      n.read = true;
      this.setLocal(STORAGE_KEYS.NOTIFS, notifs);
      return true;
    }
    return false;
  }

  async markAllNotificationsRead(): Promise<boolean> {
    try {
      await fetch('/api/notifications/read-all', { method: 'PUT' });
    } catch {
      // Fallback
    }
    const notifs = this.getLocal<NotificationItem[]>(STORAGE_KEYS.NOTIFS, DEFAULT_NOTIFS);
    notifs.forEach(item => { item.read = true; });
    this.setLocal(STORAGE_KEYS.NOTIFS, notifs);
    return true;
  }
}

export const api = new ApiClient();
