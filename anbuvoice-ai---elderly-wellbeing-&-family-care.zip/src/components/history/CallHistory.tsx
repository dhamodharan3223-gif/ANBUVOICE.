import React, { useState } from 'react';
import {
  PhoneCall,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Clock,
  Send,
  Eye
} from 'lucide-react';
import { Language, CallRecord, SeniorProfile } from '../../types';
import { translations } from '../../i18n/translations';

interface CallHistoryProps {
  language: Language;
  calls: CallRecord[];
  seniors: SeniorProfile[];
  onOpenDemoCall: (seniorId?: string) => void;
}

export const CallHistory: React.FC<CallHistoryProps> = ({
  language,
  calls,
  seniors,
  onOpenDemoCall
}) => {
  const t = translations[language];

  const [search, setSearch] = useState('');
  const [filterSenior, setFilterSenior] = useState('ALL');
  const [filterAttention, setFilterAttention] = useState('ALL');

  const filtered = calls.filter((c) => {
    const matchesSearch =
      c.seniorName.toLowerCase().includes(search.toLowerCase()) ||
      c.aiSummary.toLowerCase().includes(search.toLowerCase());
    const matchesSenior = filterSenior === 'ALL' || c.seniorId === filterSenior;
    const matchesAttention = filterAttention === 'ALL' || c.attentionLevel === filterAttention;
    return matchesSearch && matchesSenior && matchesAttention;
  });

  return (
    <div className="space-y-6 animate-in fade-in">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900">Call History &amp; Logs</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Complete historical audit trail of automated telephone rounds, responses, and notification statuses.
          </p>
        </div>

        <button
          onClick={() => onOpenDemoCall()}
          className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-sm transition active:scale-95 cursor-pointer"
        >
          <PhoneCall className="w-4 h-4" />
          <span>Conduct Call Now</span>
        </button>
      </div>

      {/* Filters Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap gap-3 items-center justify-between">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by senior name or summary..."
            className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span>Senior:</span>
            <select
              value={filterSenior}
              onChange={(e) => setFilterSenior(e.target.value)}
              className="text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5"
            >
              <option value="ALL">All Seniors</option>
              {seniors.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span>Attention:</span>
            <select
              value={filterAttention}
              onChange={(e) => setFilterAttention(e.target.value)}
              className="text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5"
            >
              <option value="ALL">All Levels</option>
              <option value="LOW">LOW</option>
              <option value="MEDIUM">MEDIUM</option>
              <option value="HIGH">HIGH</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Date &amp; Time</th>
                <th className="py-3.5 px-4">Senior</th>
                <th className="py-3.5 px-4">Duration</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Attention Level</th>
                <th className="py-3.5 px-4">AI Summary</th>
                <th className="py-3.5 px-4">Family Notification</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filtered.map((call) => (
                <tr key={call.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3.5 px-4 font-medium whitespace-nowrap">
                    <div className="font-bold text-slate-900">{call.callDate}</div>
                    <div className="text-[11px] text-slate-400">{call.callTime}</div>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <div className="font-bold text-slate-900">{call.seniorName}</div>
                    <div className="text-[10px] text-teal-700 font-bold uppercase">{call.language === 'ta' ? 'தமிழ்' : 'English'}</div>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    {call.durationSeconds}s
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded border border-emerald-200 text-[11px]">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      {call.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span
                      className={`font-black px-2.5 py-1 rounded text-[11px] inline-flex items-center gap-1 ${
                        call.attentionLevel === 'HIGH'
                          ? 'bg-rose-100 text-rose-700 border border-rose-200'
                          : call.attentionLevel === 'MEDIUM'
                          ? 'bg-amber-100 text-amber-700 border border-amber-200'
                          : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                      }`}
                    >
                      {call.attentionLevel}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 max-w-xs text-slate-600 line-clamp-2">
                    {call.aiSummary}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-semibold">
                      <Send className="w-3 h-3 text-emerald-600" />
                      <span>{call.notificationChannels?.join(', ') || 'SMS, WhatsApp'}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <button
                      onClick={() => onOpenDemoCall(call.seniorId)}
                      className="px-2.5 py-1 bg-teal-50 hover:bg-teal-100 text-teal-700 font-semibold rounded border border-teal-200 transition cursor-pointer"
                    >
                      Re-call
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
