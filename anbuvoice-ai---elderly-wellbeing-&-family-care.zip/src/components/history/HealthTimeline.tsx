import React, { useState } from 'react';
import {
  Activity,
  Smile,
  Pill,
  ShieldAlert,
  Moon,
  Heart,
  Filter,
  Search,
  Calendar,
  Clock,
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';
import { Language, CallRecord, SeniorProfile } from '../../types';
import { translations } from '../../i18n/translations';

interface HealthTimelineProps {
  language: Language;
  calls: CallRecord[];
  seniors: SeniorProfile[];
}

export const HealthTimeline: React.FC<HealthTimelineProps> = ({
  language,
  calls,
  seniors
}) => {
  const t = translations[language];

  const [selectedSeniorId, setSelectedSeniorId] = useState('ALL');
  const [selectedRisk, setSelectedRisk] = useState('ALL');

  const filtered = calls.filter((c) => {
    const matchesSenior = selectedSeniorId === 'ALL' || c.seniorId === selectedSeniorId;
    const matchesRisk = selectedRisk === 'ALL' || c.attentionLevel === selectedRisk;
    return matchesSenior && matchesRisk;
  });

  return (
    <div className="space-y-6 animate-in fade-in">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900">Longitudinal Health Timeline</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Historical day-by-day wellbeing tracking across mood, medication adherence, pain indicators, sleep patterns, and safety questions.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span>Senior:</span>
            <select
              value={selectedSeniorId}
              onChange={(e) => setSelectedSeniorId(e.target.value)}
              className="text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5"
            >
              <option value="ALL">All Seniors</option>
              {seniors.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span>Risk Tier:</span>
            <select
              value={selectedRisk}
              onChange={(e) => setSelectedRisk(e.target.value)}
              className="text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5"
            >
              <option value="ALL">All Levels</option>
              <option value="LOW">LOW</option>
              <option value="MEDIUM">MEDIUM</option>
              <option value="HIGH">HIGH</option>
            </select>
          </div>
        </div>
      </div>

      {/* Timeline items */}
      <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-3 before:top-3 before:bottom-3 before:w-0.5 before:bg-gradient-to-b before:from-teal-500 before:via-slate-300 before:to-slate-200">
        {filtered.map((item) => {
          const isHigh = item.attentionLevel === 'HIGH';
          const isMed = item.attentionLevel === 'MEDIUM';

          return (
            <div key={item.id} className="relative group">
              {/* Timeline marker node */}
              <div
                className={`absolute -left-6 sm:-left-8 top-4 w-4 h-4 rounded-full border-2 border-white shadow-xs ${
                  isHigh
                    ? 'bg-rose-600 ring-4 ring-rose-100'
                    : isMed
                    ? 'bg-amber-500 ring-4 ring-amber-100'
                    : 'bg-emerald-600 ring-4 ring-emerald-100'
                }`}
              />

              {/* Card */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:shadow-md hover:border-teal-300 transition space-y-4">
                
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-base text-slate-900">{item.seniorName}</span>
                    <span
                      className={`text-xs font-black px-2.5 py-0.5 rounded-lg flex items-center gap-1 ${
                        isHigh
                          ? 'bg-rose-100 text-rose-700'
                          : isMed
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-emerald-100 text-emerald-700'
                      }`}
                    >
                      {item.attentionLevel}
                    </span>
                  </div>

                  <div className="text-xs text-slate-400 flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>{item.callDate} at {item.callTime}</span>
                  </div>
                </div>

                {/* 5 Wellbeing Parameter Badges */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs">
                  {/* Mood */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1">
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 font-semibold">
                      <Smile className="w-3.5 h-3.5 text-amber-500" />
                      <span>Mood</span>
                    </div>
                    <div className="font-bold text-slate-800">
                      {isHigh ? 'Anxious / Low' : isMed ? 'Restless' : 'Good / Cheerful'}
                    </div>
                  </div>

                  {/* Medication */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1">
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 font-semibold">
                      <Pill className="w-3.5 h-3.5 text-teal-600" />
                      <span>Medication</span>
                    </div>
                    <div className="font-bold text-slate-800">
                      {isHigh ? 'Delayed / Missed' : isMed ? 'Partial / Forgot 1' : 'Confirmed Taken'}
                    </div>
                  </div>

                  {/* Pain */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1">
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 font-semibold">
                      <Activity className="w-3.5 h-3.5 text-rose-500" />
                      <span>Pain / Comfort</span>
                    </div>
                    <div className="font-bold text-slate-800">
                      {isHigh ? 'Severe Reported' : isMed ? 'Mild Stiffness' : 'None Reported'}
                    </div>
                  </div>

                  {/* Sleep */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1">
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 font-semibold">
                      <Moon className="w-3.5 h-3.5 text-indigo-500" />
                      <span>Sleep</span>
                    </div>
                    <div className="font-bold text-slate-800">
                      {isHigh ? 'Poor / Insomnia' : isMed ? 'Interrupted' : '7h Restful'}
                    </div>
                  </div>

                  {/* Safety */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1">
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 font-semibold">
                      <ShieldAlert className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Safety / Balance</span>
                    </div>
                    <div className="font-bold text-slate-800">
                      {isHigh ? 'Dizziness Noted' : 'Stable / No Falls'}
                    </div>
                  </div>
                </div>

                {/* AI Summary note */}
                <div className="text-xs text-slate-700 bg-teal-50/50 p-3 rounded-xl border border-teal-100/60 leading-relaxed">
                  <strong>AI Observational Note:</strong> “{item.aiSummary}”
                </div>

              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
