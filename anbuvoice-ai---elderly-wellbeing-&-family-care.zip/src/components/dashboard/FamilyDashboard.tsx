import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Users,
  PhoneCall,
  MessageSquare,
  Clock,
  Sparkles,
  AlertTriangle,
  History,
  Bell,
  Settings,
  LogOut,
  Globe,
  Search,
  ChevronDown,
  ShieldCheck,
  Plus,
  Play,
  Menu,
  X,
  Server
} from 'lucide-react';
import { Language, DashboardStats, SeniorProfile, CallRecord, AlertItem, NotificationItem, User } from '../../types';
import { translations } from '../../i18n/translations';
import { api } from '../../services/api';
import { DashboardOverview } from './DashboardOverview';
import { SeniorManagement } from '../seniors/SeniorManagement';
import { FamilyCommunication } from '../communication/FamilyCommunication';
import { CallSchedule } from '../schedule/CallSchedule';
import { AIAnalysisDeepDive } from '../analysis/AIAnalysisDeepDive';
import { CallHistory } from '../history/CallHistory';
import { HealthTimeline } from '../history/HealthTimeline';
import { NotificationCenter } from '../notifications/NotificationCenter';
import { RiskAlerts } from '../alerts/RiskAlerts';
import { AdminDashboard } from '../admin/AdminDashboard';

interface FamilyDashboardProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  currentUser: User | null;
  onLogout: () => void;
  onOpenDemoCall: (seniorId?: string) => void;
}

export const FamilyDashboard: React.FC<FamilyDashboardProps> = ({
  language,
  setLanguage,
  currentUser,
  onLogout,
  onOpenDemoCall
}) => {
  const t = translations[language];

  // Active Tab state
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isNotifDropdownOpen, setIsNotifDropdownOpen] = useState(false);
  const [isAddSeniorModalOpen, setIsAddSeniorModalOpen] = useState(false);

  // App Data States
  const [stats, setStats] = useState<DashboardStats>({
    totalSeniors: 3,
    todaysCalls: 3,
    completedCalls: 2,
    missedCalls: 0,
    activeAlerts: 1,
    riskSummary: { low: 1, medium: 1, high: 1 }
  });
  const [seniors, setSeniors] = useState<SeniorProfile[]>([]);
  const [calls, setCalls] = useState<CallRecord[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  // Load data
  const loadData = async () => {
    try {
      const [sData, cData, aData, nData, dStats] = await Promise.all([
        api.getSeniors(),
        api.getCalls(),
        api.getAlerts(),
        api.getNotifications(),
        api.getDashboardStats()
      ]);
      setSeniors(sData);
      setCalls(cData);
      setAlerts(aData);
      setNotifications(nData);
      setStats(dStats);
    } catch {
      // Handled in client service
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const unreadNotifsCount = notifications.filter((n) => !n.read).length;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'seniors', label: 'Senior Profiles', icon: <Users className="w-4 h-4" />, badge: seniors.length },
    { id: 'voice-checkins', label: 'Voice Check-ins', icon: <PhoneCall className="w-4 h-4" /> },
    { id: 'communication', label: 'Family Communication', icon: <MessageSquare className="w-4 h-4" /> },
    { id: 'schedule', label: 'Call Schedule', icon: <Clock className="w-4 h-4" /> },
    { id: 'analysis', label: 'AI Analysis', icon: <Sparkles className="w-4 h-4 text-purple-400" /> },
    { id: 'alerts', label: 'Risk Alerts', icon: <AlertTriangle className="w-4 h-4 text-amber-400" />, badge: alerts.filter(a => a.status === 'Active').length },
    { id: 'timeline', label: 'Health History', icon: <History className="w-4 h-4" /> },
    { id: 'calls', label: 'Call History', icon: <PhoneCall className="w-4 h-4" /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell className="w-4 h-4" />, badge: unreadNotifsCount },
    { id: 'admin', label: 'System Admin', icon: <Server className="w-4 h-4 text-teal-400" /> }
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row">
      
      {/* Mobile Top Header */}
      <div className="lg:hidden bg-slate-900 text-white px-4 py-3 flex items-center justify-between border-b border-slate-800">
        <button
          onClick={() => setIsMobileSidebarOpen(true)}
          className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
        >
          <Menu className="w-5 h-5" />
        </button>

        <span className="font-extrabold text-sm tracking-tight flex items-center gap-1.5">
          ANBUVOICE <span className="text-teal-400">AI</span>
        </span>

        <button
          onClick={() => onOpenDemoCall()}
          className="text-xs bg-rose-600 font-bold px-2.5 py-1.5 rounded-lg text-white"
        >
          Call Demo
        </button>
      </div>

      {/* Sidebar (Desktop fixed & Mobile overlay drawer) */}
      <aside
        className={`fixed lg:sticky top-0 z-40 h-screen w-64 bg-slate-900 text-slate-300 flex flex-col justify-between border-r border-slate-800 transition-transform duration-200 ${
          isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-5 flex-1 overflow-y-auto">
          {/* Brand header */}
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-teal-500 text-slate-950 flex items-center justify-center font-bold">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="font-extrabold text-base tracking-tight text-white block">
                  ANBUVOICE <span className="text-teal-400">AI</span>
                </span>
                <span className="text-[10px] text-slate-400 font-medium">Family Care Portal</span>
              </div>
            </div>

            <button
              onClick={() => setIsMobileSidebarOpen(false)}
              className="lg:hidden p-1 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1 text-xs font-semibold">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  if (item.id === 'voice-checkins') {
                    onOpenDemoCall();
                  } else {
                    setActiveTab(item.id);
                  }
                  setIsMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition cursor-pointer ${
                  activeTab === item.id
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {item.icon}
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                      activeTab === item.id
                        ? 'bg-white text-teal-800'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* Sidebar Footer with Logout & User Profile */}
        <div className="p-4 border-t border-slate-800 space-y-3 bg-slate-950/40">
          <div className="flex items-center justify-between text-xs">
            <div>
              <div className="font-bold text-white text-xs truncate max-w-[130px]">
                {currentUser?.name || 'Karthik Sundaram'}
              </div>
              <div className="text-[10px] text-teal-400">Family Caregiver</div>
            </div>

            <button
              onClick={onLogout}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition cursor-pointer"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/60">
            <span>Language:</span>
            <button
              onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
              className="font-bold text-teal-400 hover:underline cursor-pointer"
            >
              {language === 'en' ? 'தமிழ் (Tamil)' : 'English'}
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Top Desktop Navigation Bar */}
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200 px-6 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider hidden sm:inline">
              ANBUVOICE AI FAMILY CARE
            </span>
            <span className="text-slate-300 hidden sm:inline">•</span>
            <span className="text-xs font-bold text-teal-700 bg-teal-50 border border-teal-200 px-2 py-0.5 rounded">
              {language === 'ta' ? 'தமிழ் மொழி' : 'English'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Start Demo Call Action */}
            <button
              onClick={() => onOpenDemoCall()}
              className="inline-flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>Voice Check-in Demo</span>
            </button>

            {/* Language Switch */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 hover:text-teal-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-3 py-1.5 rounded-lg transition cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-teal-600" />
              <span>{language === 'en' ? 'தமிழ்' : 'English'}</span>
            </button>

            {/* Notification Bell with Badge & Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsNotifDropdownOpen(!isNotifDropdownOpen)}
                className="p-2 rounded-xl text-slate-600 hover:text-teal-700 hover:bg-slate-100 transition relative cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifsCount > 0 && (
                  <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                )}
                {unreadNotifsCount > 0 && (
                  <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500"></span>
                )}
              </button>

              {/* Popover Dropdown */}
              {isNotifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 py-3 z-50 animate-in fade-in">
                  <div className="px-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-900">Recent Notifications</span>
                    <button
                      onClick={() => {
                        setActiveTab('notifications');
                        setIsNotifDropdownOpen(false);
                      }}
                      className="text-[11px] text-teal-600 font-bold hover:underline"
                    >
                      View All
                    </button>
                  </div>
                  <div className="max-h-64 overflow-y-auto divide-y divide-slate-100">
                    {notifications.slice(0, 4).map((n) => (
                      <div key={n.id} className="p-3 text-xs hover:bg-slate-50">
                        <div className="font-bold text-slate-900">{n.title}</div>
                        <div className="text-slate-500 text-[11px] line-clamp-1">{n.message}</div>
                        <div className="text-slate-400 text-[10px] mt-1">{n.timestamp}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Profile pill */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-teal-600 text-white font-bold text-xs flex items-center justify-center">
                {currentUser?.name?.charAt(0) || 'K'}
              </div>
              <div className="hidden md:block text-left text-xs">
                <div className="font-bold text-slate-900 leading-tight">
                  {currentUser?.name || 'Karthik S.'}
                </div>
                <div className="text-[10px] text-slate-400">Family Admin</div>
              </div>
            </div>
          </div>
        </header>

        {/* Tab Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardOverview
              language={language}
              stats={stats}
              recentCalls={calls}
              activeAlerts={alerts}
              seniors={seniors}
              onOpenDemoCall={onOpenDemoCall}
              onOpenAddSenior={() => setIsAddSeniorModalOpen(true)}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'seniors' && (
            <SeniorManagement
              language={language}
              seniors={seniors}
              onReloadSeniors={loadData}
              onOpenDemoCall={onOpenDemoCall}
              isAddModalOpenInitially={isAddSeniorModalOpen}
              onCloseAddModalInitially={() => setIsAddSeniorModalOpen(false)}
            />
          )}

          {activeTab === 'communication' && (
            <FamilyCommunication
              language={language}
              calls={calls}
              seniors={seniors}
              onOpenDemoCall={onOpenDemoCall}
            />
          )}

          {activeTab === 'schedule' && (
            <CallSchedule
              language={language}
              seniors={seniors}
              onReloadSeniors={loadData}
              onOpenDemoCall={onOpenDemoCall}
            />
          )}

          {activeTab === 'analysis' && (
            <AIAnalysisDeepDive
              language={language}
              calls={calls}
              seniors={seniors}
            />
          )}

          {activeTab === 'alerts' && (
            <RiskAlerts
              language={language}
              alerts={alerts}
              onReloadAlerts={loadData}
              onOpenDemoCall={onOpenDemoCall}
            />
          )}

          {activeTab === 'timeline' && (
            <HealthTimeline
              language={language}
              calls={calls}
              seniors={seniors}
            />
          )}

          {activeTab === 'calls' && (
            <CallHistory
              language={language}
              calls={calls}
              seniors={seniors}
              onOpenDemoCall={onOpenDemoCall}
            />
          )}

          {activeTab === 'notifications' && (
            <NotificationCenter
              language={language}
              notifications={notifications}
              onReloadNotifications={loadData}
              onOpenDemoCall={onOpenDemoCall}
            />
          )}

          {activeTab === 'admin' && (
            <AdminDashboard
              language={language}
              seniors={seniors}
              calls={calls}
              alerts={alerts}
            />
          )}
        </main>

      </div>
    </div>
  );
};
