import React from 'react';
import {
  Users,
  PhoneCall,
  CheckCircle2,
  PhoneOff,
  AlertTriangle,
  ShieldCheck,
  Activity,
  Plus,
  Play,
  TrendingUp,
  Clock,
  ArrowUpRight,
  Heart
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';
import { Language, DashboardStats, CallRecord, AlertItem, SeniorProfile } from '../../types';
import { translations } from '../../i18n/translations';

interface DashboardOverviewProps {
  language: Language;
  stats: DashboardStats;
  recentCalls: CallRecord[];
  activeAlerts: AlertItem[];
  seniors: SeniorProfile[];
  onOpenDemoCall: (seniorId?: string) => void;
  onOpenAddSenior: () => void;
  onNavigateTab: (tab: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  language,
  stats,
  recentCalls,
  activeAlerts,
  seniors,
  onOpenDemoCall,
  onOpenAddSenior,
  onNavigateTab
}) => {
  const t = translations[language];

  // 1. Risk Trend (7 Days)
  const riskTrendData = [
    { day: 'Mon', Low: 3, Medium: 0, High: 0 },
    { day: 'Tue', Low: 2, Medium: 1, High: 0 },
    { day: 'Wed', Low: 3, Medium: 0, High: 0 },
    { day: 'Thu', Low: 2, Medium: 1, High: 0 },
    { day: 'Fri', Low: 1, Medium: 2, High: 0 },
    { day: 'Sat', Low: 2, Medium: 1, High: 0 },
    { day: 'Today', Low: stats.riskSummary.low || 1, Medium: stats.riskSummary.medium || 1, High: stats.riskSummary.high || 1 }
  ];

  // 2. Call Completion Status
  const callCompletionData = [
    { name: 'Completed', count: stats.completedCalls || 2, fill: '#0d9488' },
    { name: 'Missed', count: stats.missedCalls || 0, fill: '#f43f5e' },
    { name: 'Retrying', count: 0, fill: '#f59e0b' }
  ];

  // 3. Mood & Energy Trend
  const moodTrendData = [
    { time: 'Day 1', score: 85 },
    { time: 'Day 2', score: 88 },
    { time: 'Day 3', score: 82 },
    { time: 'Day 4', score: 78 },
    { time: 'Day 5', score: 80 },
    { time: 'Day 6', score: 84 },
    { time: 'Today', score: stats.riskSummary.high > 0 ? 65 : 86 }
  ];

  // 4. Medication Confirmation Donut
  const medicationData = [
    { name: 'Confirmed Taken', value: 85, color: '#10b981' },
    { name: 'Delayed / Missed', value: 15, color: '#f59e0b' }
  ];

  // 5. Weekly Check-in Activity (Calls per day)
  const weeklyActivityData = [
    { day: 'Mon', calls: 3 },
    { day: 'Tue', calls: 3 },
    { day: 'Wed', calls: 3 },
    { day: 'Thu', calls: 3 },
    { day: 'Fri', calls: 3 },
    { day: 'Sat', calls: 3 },
    { day: 'Sun', calls: stats.todaysCalls || 3 }
  ];

  return (
    <div className="space-y-8 animate-in fade-in">
      
      {/* Top Banner with Quick Actions */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2 py-0.5 rounded">
            Live Monitoring
          </span>
          <h2 className="text-2xl font-black text-slate-900 mt-1">
            {t.dashboard.title}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Real-time daily wellness logs, automated voice dispatch, and early supportive insights.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => onOpenDemoCall()}
            className="inline-flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-md shadow-rose-600/20 transition active:scale-95 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>{t.dashboard.startDemoCall}</span>
          </button>

          <button
            onClick={onOpenAddSenior}
            className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-sm transition active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t.dashboard.addSenior}</span>
          </button>
        </div>
      </div>

      {/* 5 Main Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {/* Total Seniors */}
        <div
          onClick={() => onNavigateTab('seniors')}
          className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-teal-300 transition shadow-xs cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase text-slate-500">{t.dashboard.stats.totalSeniors}</span>
            <Users className="w-5 h-5 text-teal-600 group-hover:scale-110 transition" />
          </div>
          <div className="text-3xl font-black text-slate-900">{stats.totalSeniors}</div>
          <div className="text-[11px] text-teal-600 font-semibold mt-1">Active family profiles</div>
        </div>

        {/* Today's Calls */}
        <div
          onClick={() => onNavigateTab('calls')}
          className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-teal-300 transition shadow-xs cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase text-slate-500">{t.dashboard.stats.todaysCalls}</span>
            <PhoneCall className="w-5 h-5 text-indigo-600 group-hover:scale-110 transition" />
          </div>
          <div className="text-3xl font-black text-slate-900">{stats.todaysCalls}</div>
          <div className="text-[11px] text-indigo-600 font-semibold mt-1">Scheduled daily rounds</div>
        </div>

        {/* Completed Calls */}
        <div
          onClick={() => onNavigateTab('calls')}
          className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-teal-300 transition shadow-xs cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase text-slate-500">{t.dashboard.stats.completedCalls}</span>
            <CheckCircle2 className="w-5 h-5 text-emerald-600 group-hover:scale-110 transition" />
          </div>
          <div className="text-3xl font-black text-slate-900">{stats.completedCalls}</div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1">Confirmed check-ins</div>
        </div>

        {/* Missed Calls */}
        <div
          onClick={() => onNavigateTab('communication')}
          className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-teal-300 transition shadow-xs cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase text-slate-500">{t.dashboard.stats.missedCalls}</span>
            <PhoneOff className="w-5 h-5 text-rose-500 group-hover:scale-110 transition" />
          </div>
          <div className="text-3xl font-black text-slate-900">{stats.missedCalls}</div>
          <div className="text-[11px] text-rose-600 font-semibold mt-1">Auto-retry queued</div>
        </div>

        {/* Active Alerts */}
        <div
          onClick={() => onNavigateTab('alerts')}
          className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-teal-300 transition shadow-xs cursor-pointer group col-span-2 sm:col-span-1"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase text-slate-500">{t.dashboard.stats.activeAlerts}</span>
            <AlertTriangle className="w-5 h-5 text-amber-500 group-hover:scale-110 transition" />
          </div>
          <div className="text-3xl font-black text-slate-900">{stats.activeAlerts}</div>
          <div className="text-[11px] text-amber-600 font-semibold mt-1">Requires family review</div>
        </div>
      </div>

      {/* Risk Summary Tiers Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-teal-600" />
            <h3 className="font-bold text-slate-900 text-sm">{t.dashboard.riskSummary}</h3>
          </div>
          <span className="text-xs text-slate-400">Accessible Risk Categorization</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
          {/* LOW */}
          <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 p-4 rounded-xl">
            <div className="flex items-center gap-3">
              <span className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                LOW
              </span>
              <div>
                <div className="font-bold text-xs text-emerald-950">Normal Check-in</div>
                <div className="text-[11px] text-emerald-700">Meds confirmed, feels well</div>
              </div>
            </div>
            <span className="text-2xl font-black text-emerald-800">{stats.riskSummary.low}</span>
          </div>

          {/* MEDIUM */}
          <div className="flex items-center justify-between bg-amber-50 border border-amber-200 p-4 rounded-xl">
            <div className="flex items-center gap-3">
              <span className="w-9 h-9 rounded-lg bg-amber-500 text-white flex items-center justify-center font-bold text-xs">
                MED
              </span>
              <div>
                <div className="font-bold text-xs text-amber-950">Caregiver Review</div>
                <div className="text-[11px] text-amber-700">Mild pain or missed syrup</div>
              </div>
            </div>
            <span className="text-2xl font-black text-amber-800">{stats.riskSummary.medium}</span>
          </div>

          {/* HIGH */}
          <div className="flex items-center justify-between bg-rose-50 border border-rose-200 p-4 rounded-xl">
            <div className="flex items-center gap-3">
              <span className="w-9 h-9 rounded-lg bg-rose-600 text-white flex items-center justify-center font-bold text-xs">
                HIGH
              </span>
              <div>
                <div className="font-bold text-xs text-rose-950">Urgent Attention</div>
                <div className="text-[11px] text-rose-700">Dizziness, slip, acute pain</div>
              </div>
            </div>
            <span className="text-2xl font-black text-rose-800">{stats.riskSummary.high}</span>
          </div>
        </div>
      </div>

      {/* 5 Recharts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart 1: Risk Trend (Line Chart) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h4 className="font-bold text-slate-900 text-sm">{t.dashboard.charts.riskTrend}</h4>
              <p className="text-xs text-slate-500">Distribution of attention levels across past 7 days</p>
            </div>
            <span className="text-xs bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">Line Chart</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={riskTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Line type="monotone" dataKey="Low" stroke="#10b981" strokeWidth={2.5} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="Medium" stroke="#f59e0b" strokeWidth={2.5} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="High" stroke="#f43f5e" strokeWidth={2.5} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Call Completion (Bar Chart) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h4 className="font-bold text-slate-900 text-sm">{t.dashboard.charts.callCompletion}</h4>
              <p className="text-xs text-slate-500">Calls executed vs missed today</p>
            </div>
            <span className="text-xs bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">Bar Chart</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={callCompletionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {callCompletionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Mood & Energy Trend (Area Chart) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h4 className="font-bold text-slate-900 text-sm">{t.dashboard.charts.moodTrend}</h4>
              <p className="text-xs text-slate-500">Longitudinal emotional wellness score (0 - 100)</p>
            </div>
            <span className="text-xs bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">Area Chart</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={moodTrendData}>
                <defs>
                  <linearGradient id="colorMood" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0d9488" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#0d9488" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} />
                <YAxis domain={[50, 100]} stroke="#94a3b8" fontSize={11} />
                <Tooltip />
                <Area type="monotone" dataKey="score" stroke="#0d9488" strokeWidth={2.5} fillOpacity={1} fill="url(#colorMood)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Medication Confirmation (Donut Chart) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h4 className="font-bold text-slate-900 text-sm">{t.dashboard.charts.medicationConfirm}</h4>
              <p className="text-xs text-slate-500">Verbal medication compliance rate</p>
            </div>
            <span className="text-xs bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">Donut Chart</span>
          </div>
          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={medicationData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {medicationData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 5: Weekly Check-in Activity (Full width bar chart) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h4 className="font-bold text-slate-900 text-sm">{t.dashboard.charts.weeklyActivity}</h4>
              <p className="text-xs text-slate-500">Total automated voice check-ins conducted per day</p>
            </div>
            <span className="text-xs bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">Activity Monitor</span>
          </div>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyActivityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="calls" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Recent Calls Log Snippet */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-base">Recent Check-in Logs</h3>
          <button
            onClick={() => onNavigateTab('calls')}
            className="text-xs text-teal-600 hover:text-teal-700 font-bold hover:underline cursor-pointer flex items-center gap-1"
          >
            <span>View All Records</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {recentCalls.slice(0, 3).map((call) => (
            <div key={call.id} className="py-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
                    call.attentionLevel === 'HIGH'
                      ? 'bg-rose-100 text-rose-700'
                      : call.attentionLevel === 'MEDIUM'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}
                >
                  {call.attentionLevel}
                </div>
                <div>
                  <div className="font-bold text-slate-900 text-sm">{call.seniorName}</div>
                  <div className="text-xs text-slate-500">{call.callDate} at {call.callTime} • {call.durationSeconds}s</div>
                </div>
              </div>

              <div className="text-xs text-slate-600 max-w-md italic">
                “{call.aiSummary}”
              </div>

              <button
                onClick={() => onOpenDemoCall(call.seniorId)}
                className="text-xs font-semibold text-teal-600 hover:text-teal-700 bg-teal-50 px-3 py-1.5 rounded-lg border border-teal-200 transition cursor-pointer shrink-0"
              >
                Re-call Senior
              </button>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
