import React, { useState } from 'react';
import {
  MessageSquare,
  PhoneCall,
  PhoneOff,
  RotateCcw,
  BellRing,
  Send,
  Smartphone,
  Mail,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldAlert
} from 'lucide-react';
import { Language, CallRecord, SeniorProfile } from '../../types';
import { translations } from '../../i18n/translations';

interface FamilyCommunicationProps {
  language: Language;
  calls: CallRecord[];
  seniors: SeniorProfile[];
  onOpenDemoCall: (seniorId?: string) => void;
}

export const FamilyCommunication: React.FC<FamilyCommunicationProps> = ({
  language,
  calls,
  seniors,
  onOpenDemoCall
}) => {
  const t = translations[language];

  const [activeChannelTab, setActiveChannelTab] = useState<'SMS' | 'WhatsApp' | 'Email'>('WhatsApp');
  const [selectedCallId, setSelectedCallId] = useState<string>(calls[0]?.id || '');
  const [isSimulatingNoAnswer, setIsSimulatingNoAnswer] = useState(false);
  const [noAnswerStep, setNoAnswerStep] = useState(0);

  const selectedCall = calls.find((c) => c.id === selectedCallId) || calls[0];

  const completedCount = calls.filter((c) => c.status === 'Completed').length;
  const missedCount = calls.filter((c) => c.status === 'Missed').length;
  const retryingCount = calls.filter((c) => c.status === 'Retrying').length;
  const alertsSent = calls.filter((c) => c.attentionLevel === 'HIGH' || c.attentionLevel === 'MEDIUM').length;

  const handleRunNoAnswerSim = () => {
    setIsSimulatingNoAnswer(true);
    setNoAnswerStep(1);

    setTimeout(() => {
      setNoAnswerStep(2); // Attempt 1: No Answer
      setTimeout(() => {
        setNoAnswerStep(3); // Automatic Retry queued
        setTimeout(() => {
          setNoAnswerStep(4); // Attempt 2: No Answer
          setTimeout(() => {
            setNoAnswerStep(5); // Family Notification dispatched!
          }, 1500);
        }, 1500);
      }, 1500);
    }, 1200);
  };

  return (
    <div className="space-y-8 animate-in fade-in">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2 py-0.5 rounded">
            Outreach &amp; Dispatch Engine
          </span>
          <h2 className="text-2xl font-black text-slate-900 mt-1">
            {t.communication.title}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            {t.communication.subtitle}
          </p>
        </div>

        <button
          onClick={handleRunNoAnswerSim}
          className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-sm transition active:scale-95 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>{t.communication.simulateNoAnswer}</span>
        </button>
      </div>

      {/* Overview Stat Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-xs font-bold text-slate-500 uppercase">Today's Check-ins</div>
          <div className="text-3xl font-black text-slate-900 mt-1">{calls.length}</div>
          <div className="text-[11px] text-teal-600 font-semibold mt-1">Scheduled calls</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-xs font-bold text-slate-500 uppercase">Completed</div>
          <div className="text-3xl font-black text-emerald-600 mt-1">{completedCount}</div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1">Responses analyzed</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-xs font-bold text-slate-500 uppercase">Missed / Unanswered</div>
          <div className="text-3xl font-black text-rose-600 mt-1">{missedCount}</div>
          <div className="text-[11px] text-rose-600 font-semibold mt-1">Handled via retry</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-xs font-bold text-slate-500 uppercase">Alerts Sent</div>
          <div className="text-3xl font-black text-amber-600 mt-1">{alertsSent}</div>
          <div className="text-[11px] text-amber-600 font-semibold mt-1">SMS / WhatsApp / Email</div>
        </div>
      </div>

      {/* No Answer Automatic Retry Flow Visualizer */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-slate-900 text-base">
              {t.communication.noAnswerEngine}
            </h3>
          </div>
          <span className="text-xs text-slate-500">Autonomous Safety Escalation</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
          {t.communication.noAnswerSteps.map((step, idx) => {
            const stepNum = idx + 1;
            const isCurrent = isSimulatingNoAnswer && noAnswerStep === stepNum;
            const isPast = isSimulatingNoAnswer && noAnswerStep > stepNum;

            return (
              <div
                key={idx}
                className={`p-4 rounded-xl border transition-all ${
                  isCurrent
                    ? 'bg-amber-100 border-amber-400 ring-2 ring-amber-400/50 scale-102'
                    : isPast
                    ? 'bg-slate-50 border-slate-300'
                    : 'bg-white border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between text-xs font-bold mb-2">
                  <span
                    className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      isCurrent
                        ? 'bg-amber-600 text-white animate-pulse'
                        : isPast
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {isPast ? '✓' : stepNum}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">Attempt {idx < 2 ? '1' : '2'}</span>
                </div>
                <h4 className="font-bold text-xs text-slate-900 mb-1">{step.label}</h4>
                <p className="text-[11px] text-slate-500 leading-snug">{step.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Escalation result banner if simulation completed */}
        {isSimulatingNoAnswer && noAnswerStep === 5 && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-3">
              <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />
              <div className="text-xs text-rose-950 font-medium">
                <strong>Safety Notice:</strong> “Senior did not respond to today's scheduled check-in. Please check on them directly.”
              </div>
            </div>
            <button
              onClick={() => setIsSimulatingNoAnswer(false)}
              className="text-xs font-bold text-rose-700 hover:underline cursor-pointer"
            >
              Reset Simulation
            </button>
          </div>
        )}
      </div>

      {/* Multi-Channel Family Notification Live Previews */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Call Record Selector */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <h3 className="font-bold text-slate-900 text-sm">Select Call for Notification Preview</h3>
          <div className="space-y-2">
            {calls.map((call) => (
              <div
                key={call.id}
                onClick={() => setSelectedCallId(call.id)}
                className={`p-3.5 rounded-xl border text-xs cursor-pointer transition ${
                  selectedCall?.id === call.id
                    ? 'border-teal-500 bg-teal-50/70 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between font-bold mb-1">
                  <span className="text-slate-900 text-sm">{call.seniorName}</span>
                  <span
                    className={`px-2 py-0.5 rounded font-black text-[10px] ${
                      call.attentionLevel === 'HIGH'
                        ? 'bg-rose-100 text-rose-700'
                        : call.attentionLevel === 'MEDIUM'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {call.attentionLevel}
                  </span>
                </div>
                <div className="text-slate-500">{call.callDate} at {call.callTime}</div>
                <div className="text-slate-700 italic mt-1 line-clamp-1">“{call.aiSummary}”</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Mock Device Previews (SMS / WhatsApp / Email) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-900 text-sm">
              {t.communication.channelsTitle}
            </h3>

            {/* Tabs */}
            <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setActiveChannelTab('WhatsApp')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                  activeChannelTab === 'WhatsApp' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-600'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </button>
              <button
                onClick={() => setActiveChannelTab('SMS')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                  activeChannelTab === 'SMS' ? 'bg-white text-teal-700 shadow-xs' : 'text-slate-600'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>SMS</span>
              </button>
              <button
                onClick={() => setActiveChannelTab('Email')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                  activeChannelTab === 'Email' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Email</span>
              </button>
            </div>
          </div>

          {/* WhatsApp Preview */}
          {activeChannelTab === 'WhatsApp' && (
            <div className="bg-[#EFEAE2] p-4 sm:p-6 rounded-2xl border border-emerald-200 space-y-3 font-sans">
              <div className="bg-[#075E54] text-white p-3 rounded-xl flex items-center justify-between text-xs">
                <span className="font-bold flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4" />
                  <span>AnbuVoice AI Care Alert Bot</span>
                </span>
                <span className="text-[10px] text-emerald-200">WhatsApp Verified ✓</span>
              </div>

              <div className="bg-white rounded-xl p-4 shadow-sm max-w-md ml-auto text-xs space-y-2 text-slate-800">
                <div className="font-bold text-slate-900 border-b pb-1.5 flex items-center justify-between">
                  <span>🔔 Daily Wellbeing Update: {selectedCall?.seniorName}</span>
                  <span
                    className={`font-black text-[10px] px-1.5 py-0.5 rounded ${
                      selectedCall?.attentionLevel === 'HIGH'
                        ? 'bg-rose-100 text-rose-700'
                        : selectedCall?.attentionLevel === 'MEDIUM'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {selectedCall?.attentionLevel}
                  </span>
                </div>

                <p className="leading-relaxed">
                  {selectedCall?.attentionLevel === 'HIGH' && (
                    <strong className="text-rose-600 block mb-1">
                      🚨 Urgent: A potentially serious concern was reported. Please check on the senior directly and seek appropriate professional or emergency help when necessary.
                    </strong>
                  )}
                  {selectedCall?.attentionLevel === 'MEDIUM' && (
                    <strong className="text-amber-600 block mb-1">
                      ⚠ Attention: A possible wellbeing concern was reported. Caregiver check-in recommended.
                    </strong>
                  )}
                  {selectedCall?.attentionLevel === 'LOW' && (
                    <span className="text-emerald-700 block mb-1">
                      ✓ Today's check-in was completed successfully. No immediate concerns reported.
                    </span>
                  )}
                </p>

                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 space-y-1 text-[11px]">
                  <div><strong>AI Summary:</strong> {selectedCall?.aiSummary}</div>
                  <div><strong>Call Time:</strong> {selectedCall?.callDate} at {selectedCall?.callTime}</div>
                  <div><strong>Medications:</strong> Confirmed adherence</div>
                </div>

                <div className="text-[10px] text-slate-400 text-right">
                  Sent via AnbuVoice Automated Bridge • {selectedCall?.callTime}
                </div>
              </div>
            </div>
          )}

          {/* SMS Preview */}
          {activeChannelTab === 'SMS' && (
            <div className="bg-slate-100 p-6 rounded-2xl border border-slate-300 space-y-3">
              <div className="text-xs text-slate-500 font-bold text-center">SMS to +91 98401 55667</div>
              <div className="bg-white p-4 rounded-2xl shadow-sm text-xs space-y-2 border border-slate-200 max-w-sm mx-auto">
                <div className="font-bold text-teal-800">ANBUVOICE AI ALERT:</div>
                <p className="text-slate-800 leading-relaxed">
                  {selectedCall?.attentionLevel === 'HIGH'
                    ? `[HIGH ATTENTION] Urgent update for ${selectedCall.seniorName}: Senior reported severe pain or dizziness. Please check on them directly.`
                    : selectedCall?.attentionLevel === 'MEDIUM'
                    ? `[MEDIUM ATTENTION] Check-in update for ${selectedCall.seniorName}: Mild stiffness or delayed medication reported.`
                    : `[LOW ATTENTION] Check-in update for ${selectedCall.seniorName}: Check-in complete. All normal.`}
                </p>
                <div className="text-[10px] text-slate-400 border-t pt-1">
                  View dashboard: https://anbuvoice.ai/dash
                </div>
              </div>
            </div>
          )}

          {/* Email Preview */}
          {activeChannelTab === 'Email' && (
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-3">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3 text-xs">
                <div className="border-b pb-2 space-y-1">
                  <div className="text-slate-400"><strong>From:</strong> updates@anbuvoice.ai</div>
                  <div className="text-slate-400"><strong>To:</strong> family@example.com</div>
                  <div className="font-bold text-slate-900">
                    Subject: [{selectedCall?.attentionLevel} ATTENTION] Wellbeing Report for {selectedCall?.seniorName}
                  </div>
                </div>

                <p className="text-slate-700 leading-relaxed">
                  Dear Family Member,
                  <br />
                  Your scheduled morning voice check-in call with <strong>{selectedCall?.seniorName}</strong> has been logged and evaluated by our AI care engine.
                </p>

                <div className="bg-teal-50 p-3 rounded-lg border border-teal-100 space-y-1 text-slate-800">
                  <div><strong>Attention Tier:</strong> {selectedCall?.attentionLevel}</div>
                  <div><strong>Summary:</strong> {selectedCall?.aiSummary}</div>
                  <div><strong>Duration:</strong> {selectedCall?.durationSeconds} seconds</div>
                </div>

                <p className="text-[11px] text-slate-500 italic">
                  Note: AnbuVoice AI provides supportive monitoring and early insights. It does not provide medical diagnosis or replace professional medical care.
                </p>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
