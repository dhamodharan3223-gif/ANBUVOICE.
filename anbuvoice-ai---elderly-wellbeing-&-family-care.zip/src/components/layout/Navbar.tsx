import React from 'react';
import { Heart, Activity, Globe, PhoneCall, ShieldCheck, User, LogOut, LayoutDashboard } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface NavbarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  isLoggedIn: boolean;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onLogout: () => void;
  onOpenDemoCall: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  language,
  setLanguage,
  isLoggedIn,
  onOpenAuth,
  onLogout,
  onOpenDemoCall
}) => {
  const t = translations[language];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200">
      {/* Top micro-bar with trust reminder & demo badge */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-8 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 text-emerald-400 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            {t.brand.tagline}
          </span>
          <span className="hidden md:inline text-slate-500">|</span>
          <span className="hidden md:inline text-slate-400">{t.brand.trustStatement}</span>
        </div>

        <div className="flex items-center gap-3">
          <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded">
            {t.nav.demoMode}
          </span>
          <button
            onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
            className="flex items-center gap-1 text-slate-300 hover:text-white transition px-2 py-0.5 rounded border border-slate-700 hover:border-slate-500 cursor-pointer"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-teal-400" />
            <span className="font-medium">{t.nav.switchLang}</span>
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Brand Logo */}
        <div
          onClick={() => setCurrentView('landing')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          {/* Logo Icon: Wave + Heart + Care connection */}
          <div className="relative w-11 h-11 rounded-xl bg-gradient-to-tr from-teal-600 via-emerald-600 to-teal-500 flex items-center justify-center shadow-md shadow-teal-700/20 group-hover:scale-105 transition transform">
            <div className="absolute inset-0 flex items-center justify-center">
              {/* Wave ripples */}
              <span className="w-8 h-8 rounded-full border border-white/20 animate-ping opacity-30"></span>
            </div>
            <div className="relative flex items-center justify-center">
              <Activity className="w-5 h-5 text-white/90" />
              <Heart className="w-3.5 h-3.5 text-rose-300 absolute -bottom-1 -right-1 fill-rose-300 stroke-rose-400" />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xl tracking-tight text-slate-900 group-hover:text-teal-700 transition">
                ANBUVOICE
              </span>
              <span className="bg-teal-50 text-teal-700 text-[11px] font-bold px-1.5 py-0.5 rounded border border-teal-200">
                AI
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium tracking-tight">
              {t.brand.subname}
            </p>
          </div>
        </div>

        {/* Desktop Nav Items */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => setCurrentView('landing')}
            className={`transition hover:text-teal-600 ${currentView === 'landing' ? 'text-teal-600 font-semibold' : ''}`}
          >
            {t.nav.home}
          </button>
          <button
            onClick={() => {
              if (currentView !== 'landing') setCurrentView('landing');
              setTimeout(() => {
                document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
              }, 50);
            }}
            className="transition hover:text-teal-600"
          >
            {t.nav.howItWorks}
          </button>
          <button
            onClick={() => {
              if (currentView !== 'landing') setCurrentView('landing');
              setTimeout(() => {
                document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
              }, 50);
            }}
            className="transition hover:text-teal-600"
          >
            {t.nav.features}
          </button>
          <button
            onClick={() => {
              if (currentView !== 'landing') setCurrentView('landing');
              setTimeout(() => {
                document.getElementById('safety')?.scrollIntoView({ behavior: 'smooth' });
              }, 50);
            }}
            className="transition hover:text-teal-600 flex items-center gap-1"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            {t.nav.safety}
          </button>

          {isLoggedIn && (
            <button
              onClick={() => setCurrentView('dashboard')}
              className={`transition hover:text-teal-600 flex items-center gap-1.5 ${currentView === 'dashboard' ? 'text-teal-600 font-bold' : ''}`}
            >
              <LayoutDashboard className="w-4 h-4 text-teal-600" />
              {t.nav.dashboard}
            </button>
          )}
        </nav>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          {/* Quick Voice Demo CTA button */}
          <button
            onClick={onOpenDemoCall}
            className="hidden sm:inline-flex items-center gap-2 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 text-xs font-semibold px-3.5 py-2 rounded-lg transition active:scale-95 cursor-pointer shadow-xs"
          >
            <PhoneCall className="w-3.5 h-3.5 text-rose-600 animate-bounce" />
            <span>Voice Call Demo</span>
          </button>

          {!isLoggedIn ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onOpenAuth('login')}
                className="text-slate-700 hover:text-teal-700 text-sm font-semibold px-3 py-2 transition rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                {t.nav.login}
              </button>
              <button
                onClick={() => onOpenAuth('register')}
                className="bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold px-4 py-2 rounded-lg shadow-sm shadow-teal-700/20 transition active:scale-95 cursor-pointer"
              >
                {t.nav.register}
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              {currentView !== 'dashboard' && (
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold px-3.5 py-2 rounded-lg transition active:scale-95 cursor-pointer"
                >
                  {t.nav.dashboard}
                </button>
              )}
              <div className="relative group">
                <button
                  onClick={onLogout}
                  title="Logout"
                  className="p-2 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition border border-slate-200 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
