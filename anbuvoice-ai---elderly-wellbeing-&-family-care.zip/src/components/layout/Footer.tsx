import React from 'react';
import { Heart, Activity, ShieldAlert, PhoneCall, Globe, CheckCircle2 } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface FooterProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onOpenDemoCall: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  language,
  setLanguage,
  onOpenAuth,
  onOpenDemoCall
}) => {
  const t = translations[language];

  return (
    <footer className="bg-slate-900 text-slate-400 text-sm border-t border-slate-800">
      {/* Disclaimer Alert Box */}
      <div className="bg-slate-950/70 border-b border-slate-800 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center gap-4 bg-teal-950/40 border border-teal-800/40 p-4 rounded-xl">
          <div className="w-10 h-10 rounded-lg bg-teal-900/80 flex items-center justify-center shrink-0 text-teal-400">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div className="flex-1 text-xs sm:text-sm text-slate-300">
            <strong className="text-white block font-semibold mb-0.5">
              {t.brand.trustStatement}
            </strong>
            <p className="text-slate-400 leading-relaxed">
              {t.brand.disclaimer}
            </p>
          </div>
          <div className="shrink-0 bg-rose-950/60 border border-rose-800/40 text-rose-300 text-xs px-3 py-2 rounded-lg font-medium">
            Medical Emergency: Dial <span className="text-white font-bold">112 / 108 / 911</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Col */}
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-600 to-emerald-600 flex items-center justify-center shadow-md">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight text-white">
                ANBUVOICE <span className="text-teal-400">AI</span>
              </span>
              <p className="text-xs text-slate-400 font-medium">
                {t.brand.subname}
              </p>
            </div>
          </div>

          <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-md">
            {t.brand.meaning}
          </p>

          <div className="flex items-center gap-2 text-xs text-slate-300 font-medium bg-slate-800/60 p-2.5 rounded-lg border border-slate-700/60 w-fit">
            <Heart className="w-4 h-4 text-rose-400 fill-rose-400/20" />
            <span>“{t.brand.tagline}”</span>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-white font-semibold text-sm mb-3">Platform Navigation</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button
                onClick={() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="hover:text-teal-400 transition cursor-pointer"
              >
                {t.nav.home}
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="hover:text-teal-400 transition cursor-pointer"
              >
                {t.nav.howItWorks}
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="hover:text-teal-400 transition cursor-pointer"
              >
                {t.nav.features}
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  document.getElementById('safety')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="hover:text-teal-400 transition cursor-pointer"
              >
                {t.nav.safety}
              </button>
            </li>
            <li>
              <button
                onClick={onOpenDemoCall}
                className="text-teal-400 hover:text-teal-300 font-semibold transition cursor-pointer flex items-center gap-1"
              >
                <PhoneCall className="w-3 h-3" />
                Live Voice Call Demo
              </button>
            </li>
          </ul>
        </div>

        {/* Languages & Auth */}
        <div>
          <h4 className="text-white font-semibold text-sm mb-3">Accessibility &amp; Care</h4>
          <p className="text-xs text-slate-400 mb-3">
            Designed with high contrast, bilingual clarity, and unhurried pacing for elderly comfort.
          </p>

          <div className="space-y-2">
            <button
              onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
              className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3 py-1.5 rounded-lg border border-slate-700 transition cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-teal-400" />
              <span>Current: {language === 'en' ? 'English' : 'தமிழ் (Tamil)'}</span>
            </button>

            <button
              onClick={() => onOpenAuth('login')}
              className="text-xs text-teal-400 hover:underline block pt-1"
            >
              Family Login Demo Portal →
            </button>
          </div>
        </div>
      </div>

      {/* Copyright & Sub-bar */}
      <div className="border-t border-slate-800/80 py-4 px-4 text-center text-xs text-slate-500">
        © 2026 AnbuVoice AI. Built with care for elderly wellbeing and family peace of mind.
      </div>
    </footer>
  );
};
