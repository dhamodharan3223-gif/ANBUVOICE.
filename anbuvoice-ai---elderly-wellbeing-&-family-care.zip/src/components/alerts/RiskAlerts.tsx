import React, { useState } from 'react';
import {
  AlertTriangle,
  ShieldAlert,
  CheckCircle2,
  Clock,
  PhoneCall,
  UserCheck,
  Search,
  Check
} from 'lucide-react';
import { Language, AlertItem } from '../../types';
import { translations } from '../../i18n/translations';
import { api } from '../../services/api';

interface RiskAlertsProps {
  language: Language;
  alerts: AlertItem[];
  onReloadAlerts: () => void;
  onOpenDemoCall: (seniorId?: string) => void;
}

export const RiskAlerts: React.FC<RiskAlertsProps> = ({
  language,
  alerts,
  onReloadAlerts,
  onOpenDemoCall
}) => {
  const t = translations[language];

  const [acknowledgingId, setAcknowledgingId] = useState<string | null>(null);
  const [actionText, setActionText] = useState('Caregiver called senior directly and confirmed safety.');

  const handleAcknowledge = async (id: string) => {
    await api.acknowledgeAlert(id, actionText);
    setAcknowledgingId(null);
    onReloadAlerts();
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900">Active Wellbeing &amp; Risk Alerts</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Prioritized concerns flagged by daily telephone checks requiring family attention.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-rose-50 text-rose-800 text-xs font-bold px-3.5 py-2 rounded-xl border border-rose-200">
          <ShieldAlert className="w-4 h-4 text-rose-600" />
          <span>{alerts.filter((a) => a.status === 'Active').length} Active Alerts</span>
        </div>
      </div>

      {/* Strict Clinical Warning Callout */}
      <div className="bg-rose-50/90 border border-rose-200 rounded-2xl p-5 flex items-start gap-4">
        <ShieldAlert className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
        <div className="text-xs sm:text-sm text-rose-950 space-y-1">
          <strong className="block font-bold">
            Emergency Care Escalation Notice:
          </strong>
          <p className="leading-relaxed">
            For potentially serious reports (such as sudden falls, chest discomfort, or severe confusion):
            <strong className="block text-rose-900 mt-0.5">
              “Please check on the senior directly and seek appropriate professional or emergency help when necessary.”
            </strong>
          </p>
        </div>
      </div>

      {/* Alerts Grid */}
      <div className="space-y-4">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className={`p-6 rounded-2xl border shadow-xs transition space-y-4 ${
              alert.attentionLevel === 'HIGH'
                ? 'bg-white border-rose-300'
                : 'bg-white border-amber-300'
            }`}
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <span
                  className={`text-xs font-black px-3 py-1 rounded-xl flex items-center gap-1.5 ${
                    alert.attentionLevel === 'HIGH'
                      ? 'bg-rose-600 text-white'
                      : 'bg-amber-500 text-white'
                  }`}
                >
                  <AlertTriangle className="w-4 h-4" />
                  <span>{alert.attentionLevel} ATTENTION</span>
                </span>
                <h3 className="font-bold text-slate-900 text-base">{alert.seniorName}</h3>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span
                  className={`px-2 py-0.5 rounded font-bold ${
                    alert.status === 'Active'
                      ? 'bg-rose-100 text-rose-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}
                >
                  {alert.status}
                </span>
                <span className="text-slate-400">• {alert.timestamp}</span>
              </div>
            </div>

            {/* Concern text */}
            <div className="text-xs sm:text-sm text-slate-800 leading-relaxed font-medium bg-slate-50 p-4 rounded-xl border border-slate-100">
              {alert.concern}
            </div>

            {alert.actionTaken && (
              <div className="text-xs text-emerald-800 bg-emerald-50 p-3 rounded-lg border border-emerald-200">
                <strong>Action Taken:</strong> {alert.actionTaken}
              </div>
            )}

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <button
                onClick={() => onOpenDemoCall(alert.seniorId)}
                className="inline-flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Call Senior Now</span>
              </button>

              {alert.status === 'Active' && (
                <>
                  {acknowledgingId === alert.id ? (
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <input
                        type="text"
                        value={actionText}
                        onChange={(e) => setActionText(e.target.value)}
                        placeholder="Note action taken..."
                        className="text-xs px-3 py-1.5 border border-slate-300 rounded-lg w-64"
                      />
                      <button
                        onClick={() => handleAcknowledge(alert.id)}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg cursor-pointer"
                      >
                        Confirm
                      </button>
                      <button
                        onClick={() => setAcknowledgingId(null)}
                        className="text-xs text-slate-500 hover:underline"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setAcknowledgingId(alert.id)}
                      className="text-xs font-bold text-slate-700 hover:text-teal-700 bg-slate-100 hover:bg-slate-200 px-3.5 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Acknowledge &amp; Log Action</span>
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
