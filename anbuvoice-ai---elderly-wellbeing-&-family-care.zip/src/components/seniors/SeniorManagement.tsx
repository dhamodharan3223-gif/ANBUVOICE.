import React, { useState } from 'react';
import {
  Users,
  Plus,
  Phone,
  Edit,
  Trash2,
  Clock,
  Heart,
  Globe,
  Search,
  CheckCircle2,
  AlertTriangle,
  X,
  ShieldCheck,
  Calendar,
  Pill
} from 'lucide-react';
import { SeniorProfile, Language } from '../../types';
import { translations } from '../../i18n/translations';
import { api } from '../../services/api';

interface SeniorManagementProps {
  language: Language;
  seniors: SeniorProfile[];
  onReloadSeniors: () => void;
  onOpenDemoCall: (seniorId: string) => void;
  isAddModalOpenInitially?: boolean;
  onCloseAddModalInitially?: () => void;
}

export const SeniorManagement: React.FC<SeniorManagementProps> = ({
  language,
  seniors,
  onReloadSeniors,
  onOpenDemoCall,
  isAddModalOpenInitially = false,
  onCloseAddModalInitially
}) => {
  const t = translations[language];

  const [searchQuery, setSearchQuery] = useState('');
  const [filterRisk, setFilterRisk] = useState<string>('ALL');
  const [isModalOpen, setIsModalOpen] = useState(isAddModalOpenInitially);
  const [editingSenior, setEditingSenior] = useState<SeniorProfile | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [age, setAge] = useState(72);
  const [gender, setGender] = useState<'Female' | 'Male' | 'Other'>('Female');
  const [phone, setPhone] = useState('+91 ');
  const [relationship, setRelationship] = useState('Mother');
  const [seniorLang, setSeniorLang] = useState<Language>(language || 'ta');
  const [medicalInformation, setMedicalInformation] = useState('');
  const [medications, setMedications] = useState('');
  const [emergencyName, setEmergencyName] = useState('');
  const [emergencyRel, setEmergencyRel] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [dailyCallTime, setDailyCallTime] = useState('09:00 AM');

  // Trigger modal open if prop changes
  React.useEffect(() => {
    if (isAddModalOpenInitially) {
      setIsModalOpen(true);
      resetForm();
    }
  }, [isAddModalOpenInitially]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const resetForm = () => {
    setEditingSenior(null);
    setName('');
    setAge(72);
    setGender('Female');
    setPhone('+91 98401 00000');
    setRelationship('Mother');
    setSeniorLang(language || 'ta');
    setMedicalInformation('');
    setMedications('');
    setEmergencyName('Karthik Sundaram');
    setEmergencyRel('Son');
    setEmergencyPhone('+91 98401 55667');
    setDailyCallTime('09:00 AM');
  };

  const handleOpenAdd = () => {
    resetForm();
    setIsModalOpen(true);
  };

  const handleOpenEdit = (senior: SeniorProfile) => {
    setEditingSenior(senior);
    setName(senior.name);
    setAge(senior.age);
    setGender(senior.gender);
    setPhone(senior.phone);
    setRelationship(senior.relationship);
    setSeniorLang(senior.language);
    setMedicalInformation(senior.medicalInformation);
    setMedications(senior.medications.join(', '));
    setEmergencyName(senior.emergencyContact.name);
    setEmergencyRel(senior.emergencyContact.relationship);
    setEmergencyPhone(senior.emergencyContact.phone);
    setDailyCallTime(senior.dailyCallTime);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string, sName: string) => {
    if (confirm(`Are you sure you want to remove the profile for ${sName}?`)) {
      await api.deleteSenior(id);
      showToast(t.senior.deletedSuccess);
      onReloadSeniors();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const medArray = medications
      .split(',')
      .map((m) => m.trim())
      .filter(Boolean);

    const payload = {
      name,
      age: Number(age),
      gender,
      phone,
      relationship,
      language: seniorLang,
      medicalInformation: medicalInformation || 'None noted',
      medications: medArray,
      emergencyContact: {
        name: emergencyName || 'Family Contact',
        relationship: emergencyRel || 'Caregiver',
        phone: emergencyPhone || '+91 98401 00000'
      },
      dailyCallTime,
      timeZone: 'Asia/Kolkata (IST)',
      callFrequency: 'Daily' as const,
      isCallEnabled: true,
      status: 'Active' as const
    };

    if (editingSenior) {
      await api.updateSenior(editingSenior.id, payload);
      showToast(t.senior.updatedSuccess);
    } else {
      await api.addSenior(payload);
      showToast(t.senior.addedSuccess);
    }

    setIsModalOpen(false);
    if (onCloseAddModalInitially) onCloseAddModalInitially();
    onReloadSeniors();
  };

  const filteredSeniors = seniors.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.phone.includes(searchQuery) ||
      s.relationship.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRisk = filterRisk === 'ALL' || s.lastAttentionLevel === filterRisk;
    return matchesSearch && matchesRisk;
  });

  return (
    <div className="space-y-6 animate-in fade-in">
      
      {/* Toast popup */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-xl shadow-xl flex items-center gap-2 border border-slate-700 animate-in slide-in-from-right">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-sm font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Header bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-2xl font-black text-slate-900">{t.senior.title}</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">{t.senior.subtitle}</p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-sm transition active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{t.senior.addBtn}</span>
        </button>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search senior by name, phone or relation..."
            className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs font-semibold text-slate-500">Filter Risk:</span>
          <select
            value={filterRisk}
            onChange={(e) => setFilterRisk(e.target.value)}
            className="text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-teal-500"
          >
            <option value="ALL">All Levels</option>
            <option value="LOW">LOW</option>
            <option value="MEDIUM">MEDIUM</option>
            <option value="HIGH">HIGH</option>
          </select>
        </div>
      </div>

      {/* Seniors Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSeniors.map((senior) => (
          <div
            key={senior.id}
            className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs hover:shadow-md hover:border-teal-300 transition space-y-4 flex flex-col justify-between"
          >
            {/* Card Top */}
            <div>
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-teal-500 to-emerald-600 text-white font-black text-lg flex items-center justify-center shadow-xs">
                    {senior.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-slate-900">{senior.name}</h3>
                    <p className="text-xs text-slate-500">
                      {senior.relationship} • {senior.age} years old • {senior.gender}
                    </p>
                  </div>
                </div>

                {/* Risk Level Badge */}
                <span
                  className={`text-xs font-black px-2.5 py-1 rounded-lg flex items-center gap-1 ${
                    senior.lastAttentionLevel === 'HIGH'
                      ? 'bg-rose-100 text-rose-700 border border-rose-200'
                      : senior.lastAttentionLevel === 'MEDIUM'
                      ? 'bg-amber-100 text-amber-700 border border-amber-200'
                      : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                  }`}
                >
                  {senior.lastAttentionLevel || 'LOW'}
                </span>
              </div>

              {/* Attributes list */}
              <div className="space-y-1.5 text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="flex justify-between">
                  <span className="text-slate-400">Phone:</span>
                  <span className="font-semibold text-slate-800">{senior.phone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Language:</span>
                  <span className="font-bold text-teal-700">
                    {senior.language === 'ta' ? 'தமிழ் (Tamil)' : 'English'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Daily Call Time:</span>
                  <span className="font-semibold text-slate-800">{senior.dailyCallTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Last Check-in:</span>
                  <span className="text-slate-700">{senior.lastCheckIn || 'Not called yet'}</span>
                </div>
              </div>

              {/* Medical Information */}
              <div className="mt-3 text-xs space-y-1">
                <div className="font-semibold text-slate-700 flex items-center gap-1">
                  <Heart className="w-3 h-3 text-rose-500" />
                  <span>Clinical &amp; Health Context:</span>
                </div>
                <p className="text-slate-500 line-clamp-2 leading-relaxed">
                  {senior.medicalInformation || 'No chronic health issues recorded.'}
                </p>
              </div>

              {/* Medications Pill Tag */}
              {senior.medications && senior.medications.length > 0 && (
                <div className="mt-2 text-xs">
                  <div className="font-semibold text-slate-700 flex items-center gap-1 mb-1">
                    <Pill className="w-3 h-3 text-teal-600" />
                    <span>Active Medications:</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {senior.medications.map((m, idx) => (
                      <span
                        key={idx}
                        className="bg-white border border-slate-200 text-slate-600 text-[10px] font-medium px-2 py-0.5 rounded"
                      >
                        {m}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
              <button
                onClick={() => onOpenDemoCall(senior.id)}
                className="flex-1 inline-flex items-center justify-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs py-2 px-3 rounded-lg shadow-xs transition active:scale-95 cursor-pointer"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{t.senior.callNow}</span>
              </button>

              <button
                onClick={() => handleOpenEdit(senior)}
                className="p-2 text-slate-500 hover:text-teal-700 hover:bg-teal-50 rounded-lg border border-slate-200 transition cursor-pointer"
                title="Edit Profile"
              >
                <Edit className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => handleDelete(senior.id, senior.name)}
                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg border border-slate-200 transition cursor-pointer"
                title="Remove Profile"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Senior Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/60 backdrop-blur-xs animate-in fade-in overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[90vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-teal-700 to-emerald-700 p-6 text-white flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold">
                  {editingSenior ? 'Edit Senior Profile' : 'Add New Senior Profile'}
                </h3>
                <p className="text-xs text-teal-100 mt-1">
                  Configure daily voice check-in schedule, language, and clinical contacts.
                </p>
              </div>
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  if (onCloseAddModalInitially) onCloseAddModalInitially();
                }}
                className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Senior Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Lakshmi Devi"
                    className="w-full text-sm px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Age *
                  </label>
                  <input
                    type="number"
                    required
                    min={50}
                    max={110}
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="w-full text-sm px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Gender *
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className="w-full text-sm px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Senior Phone Number (To Receive AI Calls) *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98401 23456"
                    className="w-full text-sm px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Relationship to Family *
                  </label>
                  <input
                    type="text"
                    required
                    value={relationship}
                    onChange={(e) => setRelationship(e.target.value)}
                    placeholder="e.g. Mother, Father, Aunt"
                    className="w-full text-sm px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Preferred Spoken Language *
                  </label>
                  <select
                    value={seniorLang}
                    onChange={(e) => setSeniorLang(e.target.value as any)}
                    className="w-full text-sm font-bold text-teal-800 bg-teal-50/50 px-3.5 py-2 border border-teal-200 rounded-lg focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="ta">தமிழ் (Tamil)</option>
                    <option value="en">English</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Daily Scheduled Call Time *
                  </label>
                  <input
                    type="text"
                    required
                    value={dailyCallTime}
                    onChange={(e) => setDailyCallTime(e.target.value)}
                    placeholder="09:00 AM"
                    className="w-full text-sm px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Medical Information &amp; Chronic Notes
                </label>
                <textarea
                  rows={2}
                  value={medicalInformation}
                  onChange={(e) => setMedicalInformation(e.target.value)}
                  placeholder="e.g. Mild hypertension, osteoarthritis in knees, occasional postural vertigo"
                  className="w-full text-sm px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Current Medications (comma separated)
                </label>
                <input
                  type="text"
                  value={medications}
                  onChange={(e) => setMedications(e.target.value)}
                  placeholder="e.g. Amlodipine 5mg (Morning), Metformin 500mg, Calcium D3"
                  className="w-full text-sm px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                />
              </div>

              {/* Emergency Contact Sub-section */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <span className="text-xs font-bold uppercase text-slate-600 block">
                  Emergency Contact Details
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Name</label>
                    <input
                      type="text"
                      value={emergencyName}
                      onChange={(e) => setEmergencyName(e.target.value)}
                      placeholder="Contact Name"
                      className="w-full text-xs px-3 py-1.5 bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Relationship</label>
                    <input
                      type="text"
                      value={emergencyRel}
                      onChange={(e) => setEmergencyRel(e.target.value)}
                      placeholder="e.g. Son / Daughter"
                      className="w-full text-xs px-3 py-1.5 bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Phone</label>
                    <input
                      type="tel"
                      value={emergencyPhone}
                      onChange={(e) => setEmergencyPhone(e.target.value)}
                      placeholder="+91 98401 55667"
                      className="w-full text-xs px-3 py-1.5 bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-sm transition active:scale-95 cursor-pointer"
                >
                  {editingSenior ? 'Save Changes' : 'Save Senior Profile'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
