import React from 'react';
import {
  Clock,
  Calendar,
  ToggleLeft,
  ToggleRight,
  Globe,
  PhoneCall,
  Bell,
  Cpu,
  ArrowRight
} from 'lucide-react';
import { Language, SeniorProfile } from '../../types';
import { translations } from '../../i18n/translations';
import { api } from '../../services/api';

interface CallScheduleProps {
  language: Language;
  seniors: SeniorProfile[];
  onReloadSeniors: () => void;
  onOpenDemoCall: (seniorId?: string) => void;
}

export const CallSchedule: React.FC<CallScheduleProps> = ({
  language,
  seniors,
  onReloadSeniors,
  onOpenDemoCall
}) => {
  const t = translations[language];

  const handleToggleCall = async (senior: SeniorProfile) => {
    await api.updateSenior(senior.id, { isCallEnabled: !senior.isCallEnabled });
    onReloadSeniors();
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900">Automatic Call Scheduler</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Configured node-cron time windows for daily morning check-ins and language preferences.
          </p>
        </div>

        <button
          onClick={() => onOpenDemoCall()}
          className="inline-flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
        >
          <PhoneCall className="w-4 h-4" />
          <span>Trigger Live Check-in Now</span>
        </button>
      </div>

      {/* Scheduler Architecture Flow */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-teal-400 font-bold text-xs uppercase tracking-wider">
            <Cpu className="w-4 h-4" />
            <span>Autonomous Daily Scheduler Pipeline</span>
          </div>
          <span className="text-[11px] bg-teal-500/20 text-teal-300 font-mono px-2 py-0.5 rounded">
            Node-cron Active (IST Timezone)
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-center text-xs">
          {[
            { label: 'Scheduled Time', sub: 'e.g. 09:00 AM' },
            { label: 'Node-cron', sub: 'Automated trigger' },
            { label: 'Voice API', sub: 'Twilio / Exotel' },
            { label: 'Senior Phone', sub: 'Basic mobile rings' },
            { label: 'AI Voice Assistant', sub: '6 Daily questions' },
            { label: 'Speech-to-Text', sub: 'Tamil / English' },
            { label: 'Family Notification', sub: 'SMS & WhatsApp' }
          ].map((item, idx) => (
            <div key={idx} className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60">
              <div className="w-6 h-6 mx-auto rounded-full bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold text-[10px] mb-1.5">
                {idx + 1}
              </div>
              <div className="font-bold text-slate-200">{item.label}</div>
              <div className="text-[10px] text-slate-400 mt-0.5">{item.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Senior Schedule Configurations */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs divide-y divide-slate-100 overflow-hidden">
        {seniors.map((senior) => (
          <div
            key={senior.id}
            className="p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-slate-900">{senior.name}</h3>
                <span className="text-xs text-slate-500">({senior.phone})</span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                    senior.isCallEnabled
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {senior.isCallEnabled ? 'Auto-calling Enabled' : 'Paused'}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 pt-1">
                <span className="flex items-center gap-1 font-semibold text-teal-700">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Call Window: {senior.dailyCallTime}</span>
                </span>
                <span className="flex items-center gap-1">
                  <Globe className="w-3.5 h-3.5 text-slate-400" />
                  <span>Language: {senior.language === 'ta' ? 'தமிழ் (Tamil)' : 'English'}</span>
                </span>
                <span className="text-slate-400">Timezone: {senior.timeZone}</span>
                <span className="text-slate-400">Frequency: {senior.callFrequency}</span>
              </div>
            </div>

            <div className="flex items-center gap-4 self-end md:self-center shrink-0">
              <button
                onClick={() => handleToggleCall(senior)}
                className={`flex items-center gap-2 text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer ${
                  senior.isCallEnabled
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                    : 'bg-slate-100 text-slate-600 border border-slate-200 hover:bg-slate-200'
                }`}
              >
                {senior.isCallEnabled ? (
                  <>
                    <ToggleRight className="w-5 h-5 text-emerald-600" />
                    <span>Enabled</span>
                  </>
                ) : (
                  <>
                    <ToggleLeft className="w-5 h-5 text-slate-400" />
                    <span>Disabled</span>
                  </>
                )}
              </button>

              <button
                onClick={() => onOpenDemoCall(senior.id)}
                className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
              >
                Test Call
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
