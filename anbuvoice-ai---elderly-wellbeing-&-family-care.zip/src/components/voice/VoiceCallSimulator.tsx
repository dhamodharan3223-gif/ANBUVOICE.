import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Phone,
  PhoneOff,
  Mic,
  Volume2,
  VolumeX,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ShieldAlert,
  Send,
  RotateCcw,
  ArrowRight,
  Layers,
  MessageSquare,
  Activity,
  HeartPulse,
  Share2
} from 'lucide-react';
import { Language, SeniorProfile, QuestionResponse, AttentionLevel, AIAnalysisResult, CallRecord } from '../../types';
import { DAILY_QUESTIONS, translations } from '../../i18n/translations';
import { voiceAudio } from '../../services/voiceAudio';
import { api } from '../../services/api';

interface VoiceCallSimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  seniors: SeniorProfile[];
  onCallSaved: (savedCall: CallRecord) => void;
  defaultSeniorId?: string;
}

type CallStage =
  | 'idle'
  | 'calling'
  | 'connected'
  | 'ai_speaking'
  | 'senior_listening'
  | 'transcribing'
  | 'ai_analyzing'
  | 'notifying'
  | 'completed';

export const VoiceCallSimulator: React.FC<VoiceCallSimulatorProps> = ({
  isOpen,
  onClose,
  language,
  seniors,
  onCallSaved,
  defaultSeniorId
}) => {
  const t = translations[language];

  // Selected Senior
  const [selectedSeniorId, setSelectedSeniorId] = useState<string>(
    defaultSeniorId || (seniors[0]?.id || 'sen-1')
  );
  const currentSenior = seniors.find((s) => s.id === selectedSeniorId) || seniors[0];

  // Simulation Scenario
  const [scenario, setScenario] = useState<'healthy' | 'mildConcern' | 'highConcern' | 'interactive'>('healthy');

  // Call Stage State
  const [stage, setStage] = useState<CallStage>('idle');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [audioMuted, setAudioMuted] = useState(false);
  const [isMicRecording, setIsMicRecording] = useState(false);
  const [customUserInput, setCustomUserInput] = useState('');
  const [transcriptLog, setTranscriptLog] = useState<QuestionResponse[]>([]);
  const [callDuration, setCallDuration] = useState(0);
  const [analysisResult, setAnalysisResult] = useState<AIAnalysisResult | null>(null);
  const [activeNotificationToast, setActiveNotificationToast] = useState<string | null>(null);

  // Timer Ref
  const callTimerRef = useRef<NodeJS.Timeout | null>(null);
  const recognitionRef = useRef<any>(null);

  const activeLang = currentSenior?.language || language || 'en';
  const currentQuestion = DAILY_QUESTIONS[currentQuestionIndex];

  // Realistic answers based on scenario & language
  const getPredefinedAnswer = (qIndex: number, scen: string, lang: 'en' | 'ta'): string => {
    if (scen === 'healthy') {
      if (lang === 'ta') {
        const answers = [
          "ஆம், நான் இன்று மிகவும் நன்றாக இருக்கிறேன். காலையில் வாக்கிங் சென்று வந்தேன்.",
          "ஆமாம், காலை உணவுக்குப் பிறகு இரத்த அழுத்த மாத்திரை எடுத்துக்கொண்டேன்.",
          "இல்லை, பெரிய வலி எதுவும் இல்லை. உடம்பு நன்றாக இருக்கிறது.",
          "இல்லை, எந்த மயக்கமும் அல்லது தலைச்சுற்றலும் வரவில்லை.",
          "நேற்று இரவு அமைதியாக 7 மணி நேரம் தூங்கினேன்.",
          "மனசுக்கு நிம்மதியாகவும் மகிழ்ச்சியாகவும் இருக்கிறது."
        ];
        return answers[qIndex] || "நன்றாக இருக்கிறேன்.";
      } else {
        const answers = [
          "Yes, I am feeling very well today! Went for a walk in the morning.",
          "Yes, I took my blood pressure tablet right after breakfast.",
          "No pain at all today, feeling comfortable.",
          "No falls, my balance is very steady.",
          "Slept peacefully for 7 hours last night.",
          "Feeling happy and relaxed today."
        ];
        return answers[qIndex] || "Feeling good.";
      }
    } else if (scen === 'mildConcern') {
      if (lang === 'ta') {
        const answers = [
          "இன்று உடல் லேசாக அசதியாக இருக்கிறது.",
          "காலை மாத்திரை எடுத்தேன், ஆனால் இருமல் மருந்தை மறந்துவிட்டேன்.",
          "காலையில் தோள்பட்டையிலும் முழங்காலிலும் லேசான பிடிப்பு வலி உள்ளது.",
          "இல்லை கீழே விழவில்லை, தலைச்சுற்றல் எதுவும் இல்லை.",
          "நேற்று இரவு இரண்டு முறை முழிப்பு வந்தது, தூக்கம் கொஞ்சம் குறைவு.",
          "கொஞ்சம் சோம்பலாக இருக்கிறது, மற்றபடி பரவாயில்லை."
        ];
        return answers[qIndex] || "பரவாயில்லை.";
      } else {
        const answers = [
          "I am feeling a little tired and slow this morning.",
          "I took my blood pressure tablet, but forgot the cough syrup.",
          "Mild stiffness and ache in my left knee from the cold weather.",
          "No falls, balance is normal.",
          "Woke up twice during the night, feeling somewhat restless.",
          "A bit low on energy today, but managing fine."
        ];
        return answers[qIndex] || "Managing fine.";
      }
    } else {
      // highConcern
      if (lang === 'ta') {
        const answers = [
          "இன்று உடல் மிகவும் சோர்வாகவும் நடுக்கமாகவும் இருக்கிறது.",
          "இன்னும் மருந்து எடுக்கவில்லை, பசி இல்லாததால் தள்ளிப் போட்டேன்.",
          "முதுகிலும் வலது காலிலும் கடுமையான வலி இருக்கிறது, நடக்க முடியவில்லை.",
          "காலையில் படுக்கையை விட்டு எழுந்ததும் பலமாக தலை சுற்றியது, சுவரைப் பிடித்துக் கொண்டேன்.",
          "வலி காரணமாக இரவு முழுதும் தூங்கவே முடியவில்லை.",
          "ரொம்ப பயமாகவும் உதவியற்றதாகவும் உணர்கிறேன்."
        ];
        return answers[qIndex] || "உடம்பு சரியில்லை.";
      } else {
        const answers = [
          "Not feeling well today, I feel very weak.",
          "I haven't taken my pills yet, didn't have any appetite for breakfast.",
          "I have sharp pain in my back and down my right leg.",
          "Yes, when I got out of bed I had a bad dizzy spell and had to grab the wall to avoid falling.",
          "Couldn't sleep at all because of the discomfort.",
          "Feeling scared and anxious being alone."
        ];
        return answers[qIndex] || "Feeling unwell.";
      }
    }
  };

  useEffect(() => {
    if (defaultSeniorId) {
      setSelectedSeniorId(defaultSeniorId);
    }
  }, [defaultSeniorId]);

  // Clean up audio & timers on unmount
  useEffect(() => {
    return () => {
      voiceAudio.stopSpeaking();
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    };
  }, []);

  if (!isOpen) return null;

  // Start call simulation
  const handleStartCall = () => {
    setStage('calling');
    setCallDuration(0);
    setCurrentQuestionIndex(0);
    setTranscriptLog([]);
    setAnalysisResult(null);
    setActiveNotificationToast(null);

    // Play ringing tone
    if (!audioMuted) {
      voiceAudio.playRingTone(2200);
    }

    setTimeout(() => {
      setStage('connected');
      if (!audioMuted) {
        voiceAudio.playConnectChime();
      }

      // Start call timer
      callTimerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);

      // Begin question 1
      setTimeout(() => {
        askQuestion(0);
      }, 800);
    }, 2400);
  };

  const askQuestion = (qIdx: number) => {
    const q = DAILY_QUESTIONS[qIdx];
    if (!q) return;

    setStage('ai_speaking');
    const questionText = activeLang === 'ta' ? q.ta : q.en;

    if (!audioMuted) {
      voiceAudio.speak(questionText, activeLang, () => {
        handleSeniorTurn(qIdx);
      });
    } else {
      setTimeout(() => {
        handleSeniorTurn(qIdx);
      }, 1400);
    }
  };

  const handleSeniorTurn = (qIdx: number) => {
    setStage('senior_listening');

    if (scenario === 'interactive') {
      // Wait for user input or mic
      return;
    }

    // Auto-progress simulated senior response
    setTimeout(() => {
      const simulatedAnswer = getPredefinedAnswer(qIdx, scenario, activeLang);
      recordAnswer(qIdx, simulatedAnswer);
    }, 1800);
  };

  const recordAnswer = (qIdx: number, answerText: string) => {
    const q = DAILY_QUESTIONS[qIdx];
    const isConcern =
      scenario === 'highConcern' ||
      (scenario === 'mildConcern' && (q.category === 'medication' || q.category === 'pain' || q.category === 'sleep'));

    const newResponse: QuestionResponse = {
      questionId: q.id,
      questionEn: q.en,
      questionTa: q.ta,
      category: q.category,
      answerText,
      flaggedConcern: isConcern
    };

    setTranscriptLog((prev) => [...prev, newResponse]);
    setStage('transcribing');

    setTimeout(() => {
      if (qIdx + 1 < DAILY_QUESTIONS.length) {
        setCurrentQuestionIndex(qIdx + 1);
        askQuestion(qIdx + 1);
      } else {
        // All 6 questions completed!
        finishCall([...transcriptLog, newResponse]);
      }
    }, 1200);
  };

  const handleCustomSubmit = () => {
    if (!customUserInput.trim()) return;
    const text = customUserInput;
    setCustomUserInput('');
    recordAnswer(currentQuestionIndex, text);
  };

  // Toggle Web Speech Recognition for interactive scenario
  const toggleMic = () => {
    const SpeechRecognition =
      (window as unknown as { SpeechRecognition: any; webkitSpeechRecognition: any }).SpeechRecognition ||
      (window as unknown as { SpeechRecognition: any; webkitSpeechRecognition: any }).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser. Please type your response.');
      return;
    }

    if (isMicRecording) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsMicRecording(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = activeLang === 'ta' ? 'ta-IN' : 'en-US';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsMicRecording(true);
      };

      recognition.onresult = (event: any) => {
        const speechResult = event.results[0][0].transcript;
        setCustomUserInput(speechResult);
        setIsMicRecording(false);
      };

      recognition.onerror = () => {
        setIsMicRecording(false);
      };

      recognition.onend = () => {
        setIsMicRecording(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch {
      setIsMicRecording(false);
    }
  };

  const finishCall = async (completedTranscript: QuestionResponse[]) => {
    if (callTimerRef.current) clearInterval(callTimerRef.current);
    voiceAudio.stopSpeaking();
    if (!audioMuted) {
      voiceAudio.playEndChime();
    }

    setStage('ai_analyzing');

    try {
      // Run AI analysis
      const analysis = await api.analyzeTranscript(
        completedTranscript,
        currentSenior?.name || 'Senior',
        activeLang
      );

      setAnalysisResult(analysis);
      setStage('notifying');

      // Save call to backend database
      const newCall = await api.saveCallRecord({
        seniorId: currentSenior.id,
        seniorName: currentSenior.name,
        callDate: new Date().toISOString().split('T')[0],
        callTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        durationSeconds: callDuration || 135,
        status: 'Completed',
        language: activeLang,
        transcript: completedTranscript,
        attentionLevel: analysis.attentionLevel,
        aiSummary: analysis.summary,
        aiAnalysis: analysis,
        familyNotificationSent: true,
        notificationChannels:
          analysis.attentionLevel === 'HIGH' ? ['SMS', 'WhatsApp', 'Email'] : ['SMS', 'WhatsApp']
      });

      onCallSaved(newCall);

      // Show notification toast
      const channels = analysis.attentionLevel === 'HIGH' ? 'SMS, WhatsApp & Email' : 'SMS & WhatsApp';
      setActiveNotificationToast(
        `Family alert dispatched via ${channels}: [${analysis.attentionLevel}] ${analysis.summary}`
      );

      setTimeout(() => {
        setStage('completed');
      }, 1500);
    } catch {
      setStage('completed');
    }
  };

  const handleEndCallPrematurely = () => {
    if (callTimerRef.current) clearInterval(callTimerRef.current);
    voiceAudio.stopSpeaking();
    if (transcriptLog.length > 0) {
      finishCall(transcriptLog);
    } else {
      setStage('idle');
    }
  };

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[95vh] flex flex-col">
        
        {/* Top Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center">
              <Phone className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base tracking-tight">{t.voiceSimulator.title}</h3>
                <span className="text-[10px] bg-rose-500/20 text-rose-300 font-bold px-2 py-0.5 rounded border border-rose-500/30">
                  LIVE INTERACTIVE
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {t.voiceSimulator.subtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setAudioMuted(!audioMuted)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
              title={audioMuted ? "Unmute audio" : "Mute audio"}
            >
              {audioMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Call Config Bar (when idle) */}
        {stage === 'idle' && (
          <div className="bg-teal-50/80 border-b border-teal-100 p-4 sm:p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {t.voiceSimulator.selectSenior}
              </label>
              <select
                value={selectedSeniorId}
                onChange={(e) => setSelectedSeniorId(e.target.value)}
                className="w-full text-sm font-semibold bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 shadow-xs focus:ring-2 focus:ring-teal-500"
              >
                {seniors.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.relationship}, {s.age}y, {s.language === 'ta' ? 'தமிழ்' : 'English'}) - {s.phone}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-500 mt-1">
                Medical: {currentSenior?.medicalInformation}
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {t.voiceSimulator.scenario}
              </label>
              <select
                value={scenario}
                onChange={(e) => setScenario(e.target.value as any)}
                className="w-full text-sm font-semibold bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 shadow-xs focus:ring-2 focus:ring-teal-500"
              >
                <option value="healthy">{t.voiceSimulator.scenarios.healthy}</option>
                <option value="mildConcern">{t.voiceSimulator.scenarios.mildConcern}</option>
                <option value="highConcern">{t.voiceSimulator.scenarios.highConcern}</option>
                <option value="interactive">{t.voiceSimulator.scenarios.interactive}</option>
              </select>
              <p className="text-[11px] text-slate-500 mt-1">
                Language: <span className="font-bold text-teal-700">{activeLang === 'ta' ? 'தமிழ் (Tamil)' : 'English'}</span>
              </p>
            </div>
          </div>
        )}

        {/* Active Call Status Bar */}
        {stage !== 'idle' && (
          <div className="bg-slate-900 text-white px-6 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping"></span>
              <div>
                <span className="font-bold text-sm text-slate-100">{currentSenior?.name}</span>
                <span className="text-xs text-slate-400 ml-2">({currentSenior?.phone})</span>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-xs font-mono font-bold bg-slate-800 text-emerald-300 px-2.5 py-1 rounded">
                ⏱ {formatSeconds(callDuration)}
              </div>
              <div className="text-xs text-slate-300 font-medium">
                Q {currentQuestionIndex + 1} of {DAILY_QUESTIONS.length}
              </div>
              <button
                onClick={handleEndCallPrematurely}
                className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer"
              >
                <PhoneOff className="w-3.5 h-3.5" />
                <span>{t.voiceSimulator.endCall}</span>
              </button>
            </div>
          </div>
        )}

        {/* Main Body */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6">
          
          {/* Stage: Idle Screen */}
          {stage === 'idle' && (
            <div className="text-center py-10 space-y-6 max-w-lg mx-auto">
              <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-teal-500 to-emerald-500 text-white flex items-center justify-center shadow-xl shadow-teal-600/30">
                <Phone className="w-10 h-10 animate-bounce" />
              </div>

              <div>
                <h3 className="text-2xl font-black text-slate-900">
                  Ready to Check-in with {currentSenior?.name}
                </h3>
                <p className="text-sm text-slate-600 mt-2">
                  The AI voice engine will dial the senior’s telephone, ask our 6 calibrated wellbeing questions in {activeLang === 'ta' ? 'தமிழ்' : 'English'}, and process health signals in real time.
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left text-xs space-y-2 text-slate-600">
                <div className="font-bold text-slate-800">What happens during this check-in:</div>
                <div className="flex items-center gap-2">✓ AI speaks with natural pacing for seniors</div>
                <div className="flex items-center gap-2">✓ Verifies daily medication adherence</div>
                <div className="flex items-center gap-2">✓ Screens for balance issues, dizziness, or slips</div>
                <div className="flex items-center gap-2">✓ Assigns LOW, MEDIUM, or HIGH attention level</div>
                <div className="flex items-center gap-2">✓ Dispatches family WhatsApp, SMS &amp; Email updates</div>
              </div>

              <button
                onClick={handleStartCall}
                className="w-full py-4 bg-teal-600 hover:bg-teal-700 text-white text-base font-bold rounded-2xl shadow-lg shadow-teal-600/30 transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <Phone className="w-5 h-5" />
                <span>{t.voiceSimulator.startCall}</span>
              </button>
            </div>
          )}

          {/* Stage: Active Calling / Progress */}
          {stage !== 'idle' && stage !== 'completed' && (
            <div className="space-y-6">
              
              {/* Call Stage Status Banner */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 text-center space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-teal-700">
                  {stage === 'calling' && t.voiceSimulator.status.calling}
                  {stage === 'connected' && t.voiceSimulator.status.connected}
                  {stage === 'ai_speaking' && t.voiceSimulator.status.asking}
                  {stage === 'senior_listening' && t.voiceSimulator.status.listening}
                  {stage === 'transcribing' && t.voiceSimulator.status.processing}
                  {stage === 'ai_analyzing' && t.voiceSimulator.status.analyzing}
                  {stage === 'notifying' && t.voiceSimulator.status.notifying}
                </div>

                {/* Animated Voice Waveform Visualizer */}
                <div className="h-16 flex items-center justify-center gap-1.5">
                  {[16, 32, 48, 24, 56, 36, 44, 28, 52, 20, 40, 16].map((h, i) => (
                    <span
                      key={i}
                      style={{
                        height:
                          stage === 'ai_speaking' || stage === 'senior_listening'
                            ? `${Math.max(12, Math.sin(Date.now() / 200 + i) * 28 + h)}px`
                            : '8px',
                        transition: 'height 0.15s ease'
                      }}
                      className={`w-1.5 rounded-full transition-all ${
                        stage === 'ai_speaking'
                          ? 'bg-teal-500'
                          : stage === 'senior_listening'
                          ? 'bg-rose-500 animate-pulse'
                          : 'bg-slate-300'
                      }`}
                    />
                  ))}
                </div>

                {/* Active Question Display */}
                {currentQuestion && (
                  <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs text-left">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 mb-1">
                      <span>QUESTION {currentQuestion.id} of {DAILY_QUESTIONS.length}</span>
                      <span className="capitalize text-teal-600 bg-teal-50 px-2 py-0.5 rounded">
                        Category: {currentQuestion.category}
                      </span>
                    </div>
                    <div className="text-base font-bold text-slate-900">
                      “{activeLang === 'ta' ? currentQuestion.ta : currentQuestion.en}”
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {activeLang === 'ta' ? currentQuestion.en : currentQuestion.ta}
                    </div>
                  </div>
                )}
              </div>

              {/* Interactive mic / typing bar if custom scenario */}
              {scenario === 'interactive' && stage === 'senior_listening' && (
                <div className="bg-rose-50 border border-rose-200 p-4 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-rose-900 flex items-center gap-1.5">
                      <Mic className="w-4 h-4 text-rose-600" />
                      Speak as {currentSenior?.name} or type response:
                    </span>
                    <button
                      onClick={toggleMic}
                      className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                        isMicRecording
                          ? 'bg-rose-600 text-white animate-pulse'
                          : 'bg-white text-rose-700 border border-rose-300 hover:bg-rose-100'
                      }`}
                    >
                      <Mic className="w-3.5 h-3.5" />
                      <span>{isMicRecording ? 'Recording (Click to stop)' : 'Use Microphone'}</span>
                    </button>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customUserInput}
                      onChange={(e) => setCustomUserInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleCustomSubmit();
                      }}
                      placeholder="Type response (e.g., 'I took my medicine and feel good' or 'I have pain')..."
                      className="flex-1 bg-white border border-slate-300 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                    <button
                      onClick={handleCustomSubmit}
                      disabled={!customUserInput.trim()}
                      className="bg-teal-600 hover:bg-teal-700 disabled:opacity-40 text-white font-bold px-4 py-2.5 rounded-xl text-sm transition cursor-pointer flex items-center gap-1"
                    >
                      <Send className="w-4 h-4" />
                      <span>Send</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Live Transcript Stream */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4 text-teal-600" />
                  <span>Real-time Speech-to-Text Transcript</span>
                </h4>

                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {transcriptLog.map((item, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-xl border text-xs leading-relaxed ${
                        item.flaggedConcern
                          ? 'bg-rose-50/80 border-rose-200 text-rose-950'
                          : 'bg-white border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold mb-1">
                        <span className="text-slate-600">Q{item.questionId}: {activeLang === 'ta' ? item.questionTa : item.questionEn}</span>
                        {item.flaggedConcern && (
                          <span className="text-[10px] bg-rose-200 text-rose-800 px-1.5 py-0.5 rounded font-bold">
                            Reported concern
                          </span>
                        )}
                      </div>
                      <div className="text-slate-900 font-medium pl-3 border-l-2 border-teal-500">
                        “{item.answerText}”
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* Stage: Completed Assessment & Dispatch Card */}
          {stage === 'completed' && analysisResult && (
            <div className="space-y-6 animate-in fade-in">
              {/* Notification Toast Alert */}
              {activeNotificationToast && (
                <div className="bg-slate-900 text-white p-4 rounded-2xl flex items-center gap-3 shadow-lg border border-slate-700">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 text-slate-900 flex items-center justify-center shrink-0 font-bold">
                    ✓
                  </div>
                  <div className="flex-1 text-xs">
                    <div className="font-bold text-emerald-400">Automated Family Notification Dispatched</div>
                    <div className="text-slate-300">{activeNotificationToast}</div>
                  </div>
                </div>
              )}

              {/* Assessment Card */}
              <div
                className={`p-6 rounded-2xl border ${
                  analysisResult.attentionLevel === 'HIGH'
                    ? 'bg-rose-50 border-rose-300'
                    : analysisResult.attentionLevel === 'MEDIUM'
                    ? 'bg-amber-50 border-amber-300'
                    : 'bg-emerald-50 border-emerald-300'
                }`}
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b pb-4 mb-4 border-black/10">
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      {t.analysis.attentionTier}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span
                        className={`text-2xl font-black px-3 py-1 rounded-xl flex items-center gap-2 ${
                          analysisResult.attentionLevel === 'HIGH'
                            ? 'bg-rose-600 text-white'
                            : analysisResult.attentionLevel === 'MEDIUM'
                            ? 'bg-amber-600 text-white'
                            : 'bg-emerald-600 text-white'
                        }`}
                      >
                        {analysisResult.attentionLevel === 'HIGH' && <AlertTriangle className="w-6 h-6" />}
                        {analysisResult.attentionLevel === 'MEDIUM' && <Activity className="w-6 h-6" />}
                        {analysisResult.attentionLevel === 'LOW' && <CheckCircle2 className="w-6 h-6" />}
                        <span>{analysisResult.attentionLevel}</span>
                      </span>
                      <span className="text-xs text-slate-600 font-medium">
                        {analysisResult.attentionLevel === 'HIGH' && t.analysis.highDesc}
                        {analysisResult.attentionLevel === 'MEDIUM' && t.analysis.mediumDesc}
                        {analysisResult.attentionLevel === 'LOW' && t.analysis.lowDesc}
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-right text-slate-500">
                    <div>Duration: <strong>{formatSeconds(callDuration)}</strong></div>
                    <div>Completed at: <strong>{new Date().toLocaleTimeString()}</strong></div>
                  </div>
                </div>

                {/* AI Summary */}
                <div className="space-y-3">
                  <div>
                    <h5 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                      AI Wellbeing Summary
                    </h5>
                    <p className="text-sm font-semibold text-slate-900 mt-1">
                      {analysisResult.summary}
                    </p>
                  </div>

                  {/* Observations */}
                  <div>
                    <h5 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                      {t.analysis.observations}
                    </h5>
                    <ul className="mt-1 space-y-1 text-xs text-slate-700">
                      {analysisResult.observations.map((obs, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-teal-600 font-bold">•</span>
                          <span>{obs}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Recommended Action */}
                  <div className="bg-white/80 p-3.5 rounded-xl border border-black/10">
                    <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      {t.analysis.recommendations}
                    </h5>
                    <p className="text-xs font-medium text-slate-800 mt-1">
                      {analysisResult.recommendedAction}
                    </p>
                  </div>

                  {/* Disclaimer banner */}
                  <div className="text-[11px] text-slate-500 italic pt-2">
                    {analysisResult.disclaimer}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <button
                  onClick={handleStartCall}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Run Another Check-in Demo</span>
                </button>

                <button
                  onClick={onClose}
                  className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer flex items-center gap-1.5"
                >
                  <span>View Updated Dashboard &amp; History</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-emerald-600" />
            <span>Strict Healthcare Safety Guardrails: Observations only, never diagnostic.</span>
          </span>
          <span className="font-mono text-[11px] text-slate-400">
            Engine: Gemini 3.8 Flash + Web Speech
          </span>
        </div>

      </div>
    </div>
  );
};
