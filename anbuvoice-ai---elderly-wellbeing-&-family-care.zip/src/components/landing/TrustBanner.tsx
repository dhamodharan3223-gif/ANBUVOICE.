import React from 'react';
import { ShieldCheck, AlertCircle, HeartHandshake, Stethoscope } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface TrustBannerProps {
  language: Language;
}

export const TrustBanner: React.FC<TrustBannerProps> = ({ language }) => {
  const t = translations[language];

  return (
    <section className="bg-white border-y border-slate-200 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-2xl bg-gradient-to-r from-teal-50 via-slate-50 to-emerald-50 border border-teal-200/80 p-6 sm:p-8">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6 justify-between">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-teal-700/20">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-100 px-2 py-0.5 rounded">
                    Clinical Safety Guarantee
                  </span>
                  <span className="text-xs font-semibold text-slate-500">Ethical AI Principles</span>
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-slate-900">
                  “{t.brand.trustStatement}”
                </h3>
                <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
                  {t.brand.disclaimer}
                </p>
              </div>
            </div>

            <div className="shrink-0 flex items-center gap-3 bg-white px-4 py-3 rounded-xl border border-slate-200 shadow-xs">
              <Stethoscope className="w-5 h-5 text-teal-600" />
              <div className="text-xs">
                <div className="font-bold text-slate-900">Supportive Monitoring</div>
                <div className="text-slate-500">Early conversational cues</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
