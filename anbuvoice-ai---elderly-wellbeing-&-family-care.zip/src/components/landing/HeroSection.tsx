import React from 'react';
import { PhoneCall, Heart, ArrowRight, ShieldCheck, CheckCircle2, Activity, Sparkles, MessageSquare, Volume2, UserCheck, BellRing } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface HeroSectionProps {
  language: Language;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onOpenDemoCall: () => void;
  onScrollToHowItWorks: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  language,
  onOpenAuth,
  onOpenDemoCall,
  onScrollToHowItWorks
}) => {
  const t = translations[language];

  return (
    <section className="relative overflow-hidden pt-10 pb-20 lg:pt-16 lg:pb-28 bg-gradient-to-b from-teal-50/60 via-white to-slate-50">
      {/* Background soft glow rings */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-teal-200/30 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-rose-100/30 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Copy & CTAs */}
          <div className="lg:col-span-7 space-y-6">
            {/* Pill Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-100/80 border border-teal-200 text-teal-800 text-xs font-semibold tracking-wide shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-teal-600 animate-spin" />
              <span>{t.brand.subname}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.12]">
              <span className="block">{t.hero.headline}</span>
              <span className="bg-gradient-to-r from-teal-700 via-emerald-600 to-teal-500 bg-clip-text text-transparent">
                {t.brand.tagline.split('.')[0]}.
              </span>
            </h1>

            {/* Subheading & Description */}
            <p className="text-lg sm:text-xl text-slate-700 font-medium leading-relaxed max-w-2xl">
              {t.hero.subheading}
            </p>

            <p className="text-sm sm:text-base text-slate-500 leading-relaxed max-w-2xl">
              {t.hero.description}
            </p>

            {/* CTAs */}
            <div className="pt-2 flex flex-wrap items-center gap-3.5">
              <button
                onClick={() => onOpenAuth('register')}
                className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-base px-6 py-3.5 rounded-xl shadow-lg shadow-teal-700/25 transition active:scale-95 cursor-pointer"
              >
                <span>{t.hero.ctaPrimary}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenDemoCall}
                className="inline-flex items-center gap-2.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-base px-6 py-3.5 rounded-xl shadow-lg shadow-rose-600/20 transition active:scale-95 cursor-pointer ring-4 ring-rose-100"
              >
                <PhoneCall className="w-4 h-4 animate-bounce" />
                <span>{t.hero.ctaDemoCall}</span>
              </button>

              <button
                onClick={onScrollToHowItWorks}
                className="inline-flex items-center gap-2 text-slate-700 hover:text-teal-700 font-semibold text-sm px-4 py-3 rounded-xl border border-slate-200 hover:bg-slate-50 transition cursor-pointer"
              >
                <span>{t.hero.ctaSecondary}</span>
              </button>
            </div>

            {/* Reassurance Checklist */}
            <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-600 font-medium border-t border-slate-200">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Works on any basic mobile/landline</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>English &amp; தமிழ் (Tamil) bilingual</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Zero apps needed for senior</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Pipeline Interactive Card */}
          <div className="lg:col-span-5">
            <div className="relative bg-white rounded-2xl shadow-xl shadow-slate-200/80 border border-slate-200 p-6 space-y-5">
              
              {/* Card Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center font-bold">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{t.hero.pipelineTitle}</h3>
                    <p className="text-[11px] text-slate-500">Live Voice to Family Notification Flow</p>
                  </div>
                </div>

                <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                  Active Loop
                </span>
              </div>

              {/* 7-Step Visual Flow Requested in Brief */}
              <div className="space-y-2 relative">
                {/* Connecting track line */}
                <div className="absolute left-4 top-3 bottom-3 w-0.5 bg-gradient-to-b from-teal-400 via-emerald-400 to-rose-400 -z-0" />

                {t.hero.steps.map((step, idx) => (
                  <div
                    key={idx}
                    className="relative z-10 flex items-center gap-3 bg-slate-50/90 hover:bg-teal-50/50 p-2.5 rounded-xl border border-slate-200/80 transition group"
                  >
                    <div className="w-8 h-8 rounded-full bg-white border-2 border-teal-500 text-teal-700 font-bold text-xs flex items-center justify-center shrink-0 shadow-xs group-hover:scale-110 transition">
                      {idx + 1}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900 group-hover:text-teal-700 transition">
                          {step.label}
                        </span>
                        {idx === 5 && (
                          <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                            LOW • MED • HIGH
                          </span>
                        )}
                        {idx === 6 && (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                            SMS • WhatsApp
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 truncate">
                        {step.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick Trigger Banner inside Card */}
              <div className="bg-gradient-to-r from-teal-600 to-emerald-600 text-white p-3.5 rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold">Experience the Voice AI</div>
                  <div className="text-[11px] text-teal-100">Try a 1-minute simulated senior call</div>
                </div>
                <button
                  onClick={onOpenDemoCall}
                  className="bg-white text-teal-800 hover:bg-teal-50 text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm transition active:scale-95 cursor-pointer shrink-0"
                >
                  Start Demo
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
