import React from 'react';
import { UserPlus, Clock, PhoneOutgoing, Mic, Cpu, BellRing, ArrowRight, Play } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface HowItWorksProps {
  language: Language;
  onOpenDemoCall: () => void;
}

export const HowItWorksSection: React.FC<HowItWorksProps> = ({
  language,
  onOpenDemoCall
}) => {
  const t = translations[language];

  const stepIcons = [
    <UserPlus key="1" className="w-5 h-5 text-teal-600" />,
    <Clock key="2" className="w-5 h-5 text-emerald-600" />,
    <PhoneOutgoing key="3" className="w-5 h-5 text-indigo-600" />,
    <Mic key="4" className="w-5 h-5 text-amber-600" />,
    <Cpu key="5" className="w-5 h-5 text-purple-600" />,
    <BellRing key="6" className="w-5 h-5 text-rose-600" />
  ];

  return (
    <section id="how-it-works" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-50 border border-teal-200 px-3 py-1 rounded-full">
            {t.howItWorks.badge}
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.howItWorks.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.howItWorks.subtitle}
          </p>
        </div>

        {/* 6 Animated Timeline Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative">
          {t.howItWorks.steps.map((step, idx) => (
            <div
              key={step.number}
              className="relative bg-slate-50 hover:bg-white rounded-2xl p-7 border border-slate-200 shadow-xs hover:shadow-lg hover:border-teal-300 transition group"
            >
              {/* Step Number Top Badge */}
              <div className="flex items-center justify-between mb-6">
                <span className="text-3xl font-black text-slate-300 group-hover:text-teal-600 transition font-mono">
                  {step.number}
                </span>
                <div className="w-10 h-10 rounded-xl bg-white group-hover:bg-teal-50 border border-slate-200 group-hover:border-teal-200 flex items-center justify-center shadow-xs">
                  {stepIcons[idx]}
                </div>
              </div>

              {/* Title & Desc */}
              <h3 className="text-lg font-bold text-slate-900 mb-2.5 group-hover:text-teal-700 transition">
                {step.title}
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                {step.desc}
              </p>

              {/* Indicator connector badge */}
              <div className="mt-6 pt-4 border-t border-slate-200/70 flex items-center justify-between text-xs text-slate-400">
                <span className="font-semibold text-slate-500">Step {idx + 1} of 6</span>
                <span className="text-teal-600 font-bold group-hover:translate-x-1 transition flex items-center gap-1">
                  Next <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Callout with Simulator Trigger */}
        <div className="mt-14 p-6 rounded-2xl bg-gradient-to-r from-teal-900 via-slate-900 to-teal-950 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="text-lg font-bold">Want to hear how the conversation sounds?</h4>
            <p className="text-xs sm:text-sm text-slate-300">
              Test both Tamil and English spoken voice dialogues in our interactive simulator.
            </p>
          </div>
          <button
            onClick={onOpenDemoCall}
            className="inline-flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm px-5 py-3 rounded-xl transition active:scale-95 cursor-pointer shrink-0 shadow-lg shadow-rose-900/40"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Launch Live Voice Call Simulator</span>
          </button>
        </div>

      </div>
    </section>
  );
};
