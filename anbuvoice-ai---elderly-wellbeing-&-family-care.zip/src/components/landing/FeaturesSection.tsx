import React from 'react';
import { PhoneCall, Pill, Smile, ShieldAlert, Sparkles, BellRing, Languages, RotateCcw } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface FeaturesSectionProps {
  language: Language;
}

export const FeaturesSection: React.FC<FeaturesSectionProps> = ({ language }) => {
  const t = translations[language];

  const icons = [
    <PhoneCall key="1" className="w-6 h-6 text-teal-600" />,
    <Pill key="2" className="w-6 h-6 text-emerald-600" />,
    <Smile key="3" className="w-6 h-6 text-amber-600" />,
    <ShieldAlert key="4" className="w-6 h-6 text-rose-600" />,
    <Sparkles key="5" className="w-6 h-6 text-indigo-600" />,
    <BellRing key="6" className="w-6 h-6 text-blue-600" />,
    <Languages key="7" className="w-6 h-6 text-purple-600" />,
    <RotateCcw key="8" className="w-6 h-6 text-teal-600" />
  ];

  return (
    <section id="features" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-100/70 border border-teal-200 px-3 py-1 rounded-full">
            Core Capabilities
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.features.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.features.subtitle}
          </p>
        </div>

        {/* 8 Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {t.features.items.map((item, index) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm hover:shadow-md hover:border-teal-300 transition group flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-slate-50 group-hover:bg-teal-50 border border-slate-100 group-hover:border-teal-100 flex items-center justify-center mb-5 transition transform group-hover:-translate-y-1">
                  {icons[index % icons.length]}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-teal-700 transition">
                  {item.title}
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400 font-medium">
                <span>Feature 0{item.id}</span>
                <span className="text-teal-600 group-hover:translate-x-1 transition font-semibold">Active in system →</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
