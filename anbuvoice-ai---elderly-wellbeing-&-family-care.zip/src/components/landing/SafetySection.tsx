import React from 'react';
import { ShieldCheck, AlertTriangle, HeartPulse, FileText, CheckCircle2 } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface SafetySectionProps {
  language: Language;
}

export const SafetySection: React.FC<SafetySectionProps> = ({ language }) => {
  const t = translations[language];

  return (
    <section id="safety" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-rose-700 bg-rose-50 border border-rose-200 px-3 py-1 rounded-full">
            Clinical Guardrails &amp; Ethics
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.safety.headline}
          </h2>
          <p className="text-base text-slate-600">
            {t.safety.disclaimerFull}
          </p>
        </div>

        {/* Comparison Box: What We Do vs What We NEVER Do */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          
          {/* Strict Boundaries */}
          <div className="bg-rose-50/70 border border-rose-200 rounded-2xl p-7 space-y-4">
            <div className="flex items-center gap-3 text-rose-900 font-bold text-lg">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>What AnbuVoice AI NEVER Claims Or Does</span>
            </div>
            <ul className="space-y-3 text-sm text-slate-700">
              <li className="flex items-start gap-2.5">
                <span className="text-rose-600 font-bold">✕</span>
                <span><strong>Never diagnoses medical conditions:</strong> We never output terms like “Disease detected” or “Patient suffers from Parkinson's”.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-600 font-bold">✕</span>
                <span><strong>Never replaces a doctor:</strong> The platform is designed solely for family reassurance and early behavioral observation.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-600 font-bold">✕</span>
                <span><strong>Never prescribes or changes medication dosages:</strong> We only log verbal adherence confirmation against the caregiver's schedule.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-600 font-bold">✕</span>
                <span><strong>Never acts as an autonomous emergency first responder:</strong> We alert the family caregiver immediately to initiate emergency services if needed.</span>
              </li>
            </ul>
          </div>

          {/* Supportive Guardrails */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-7 space-y-4">
            <div className="flex items-center gap-3 text-emerald-900 font-bold text-lg">
              <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>How We Safely Support Senior Wellbeing</span>
            </div>
            <ul className="space-y-3 text-sm text-slate-700">
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>“Reported concern” terminology:</strong> We use safe observational language like “Senior noted mild stiffness” or “Sleep interrupted”.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Actionable Escalation Guidance:</strong> For any HIGH attention score, family is advised: “Please check on the senior directly and seek appropriate professional or emergency help when necessary.”</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Respectful pacing:</strong> Gentle conversational flow with pauses designed specifically for seniors living independently.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Family-centered transparency:</strong> Complete access to original audio recordings, transcripts, and AI timestamps.</span>
              </li>
            </ul>
          </div>

        </div>

        {/* 4 Rules Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {t.safety.rules.map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-2"
            >
              <div className="text-teal-600 font-bold text-xs uppercase tracking-wider">
                Safety Protocol 0{index + 1}
              </div>
              <h4 className="font-bold text-slate-900 text-sm">{item.rule}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
