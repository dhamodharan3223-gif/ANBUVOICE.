import React, { useState } from 'react';
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  ShieldAlert,
  PhoneOff,
  Pill,
  CheckCheck,
  Filter
} from 'lucide-react';
import { Language, NotificationItem } from '../../types';
import { translations } from '../../i18n/translations';
import { api } from '../../services/api';

interface NotificationCenterProps {
  language: Language;
  notifications: NotificationItem[];
  onReloadNotifications: () => void;
  onOpenDemoCall: (seniorId?: string) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  language,
  notifications,
  onReloadNotifications,
  onOpenDemoCall
}) => {
  const t = translations[language];

  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const filtered = notifications.filter((n) => {
    if (filter === 'unread') return !n.read;
    return true;
  });

  const handleMarkAsRead = async (id: string) => {
    await api.markNotificationRead(id);
    onReloadNotifications();
  };

  const handleMarkAllRead = async () => {
    await api.markAllNotificationsRead();
    onReloadNotifications();
  };

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'high_attention':
        return <ShieldAlert className="w-5 h-5 text-rose-600" />;
      case 'medium_attention':
        return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      case 'missed':
        return <PhoneOff className="w-5 h-5 text-rose-500" />;
      case 'medication_confirmed':
        return <Pill className="w-5 h-5 text-emerald-600" />;
      case 'completed':
      default:
        return <CheckCircle2 className="w-5 h-5 text-teal-600" />;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900">{t.notifications.title}</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time family dispatch logs across SMS, WhatsApp, and email alerts.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                filter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              {t.notifications.all} ({notifications.length})
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                filter === 'unread' ? 'bg-white text-teal-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              {t.notifications.unread} ({notifications.filter((n) => !n.read).length})
            </button>
          </div>

          <button
            onClick={handleMarkAllRead}
            className="text-xs font-bold text-teal-600 hover:text-teal-700 bg-teal-50 px-3.5 py-2 rounded-xl border border-teal-200 transition cursor-pointer flex items-center gap-1.5"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>{t.notifications.markAllRead}</span>
          </button>
        </div>
      </div>

      {/* List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs divide-y divide-slate-100 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            {t.notifications.empty}
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              className={`p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition ${
                !item.read ? 'bg-teal-50/40' : 'hover:bg-slate-50'
              }`}
            >
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center shrink-0">
                  {getIcon(item.type)}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-900">{item.title}</span>
                    {!item.read && (
                      <span className="w-2 h-2 rounded-full bg-teal-500 shrink-0"></span>
                    )}
                    {item.attentionLevel && (
                      <span
                        className={`text-[10px] font-black px-1.5 py-0.5 rounded ${
                          item.attentionLevel === 'HIGH'
                            ? 'bg-rose-100 text-rose-700'
                            : item.attentionLevel === 'MEDIUM'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {item.attentionLevel}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed max-w-xl">
                    {item.message}
                  </p>

                  <div className="text-[11px] text-slate-400">
                    Senior: <strong className="text-slate-600">{item.seniorName}</strong> • {item.timestamp}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                <button
                  onClick={() => onOpenDemoCall(item.seniorId)}
                  className="text-xs font-semibold text-teal-700 bg-white border border-teal-200 hover:bg-teal-50 px-3 py-1.5 rounded-lg transition cursor-pointer"
                >
                  Call Senior
                </button>

                {!item.read && (
                  <button
                    onClick={() => handleMarkAsRead(item.id)}
                    className="text-xs font-medium text-slate-500 hover:text-slate-800 p-1.5 transition cursor-pointer"
                    title="Mark as Read"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

    </div>
  );
};
