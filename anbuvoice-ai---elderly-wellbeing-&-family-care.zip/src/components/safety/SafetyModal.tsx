import React from 'react';
import { X, ShieldCheck, AlertTriangle, Stethoscope, PhoneCall, HeartHandshake } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface SafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const SafetyModal: React.FC<SafetyModalProps> = ({
  isOpen,
  onClose,
  language
}) => {
  const t = translations[language];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[10px] bg-rose-500/20 text-rose-300 font-bold px-2 py-0.5 rounded uppercase tracking-wider">
              Clinical Guardrails
            </span>
          </div>
          <h3 className="text-xl font-bold">{t.safety.headline}</h3>
          <p className="text-xs text-slate-400 mt-1">
            Understanding the supportive nature and safety protocols of AnbuVoice AI.
          </p>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-xs sm:text-sm text-slate-700">
          <div className="bg-teal-50 border border-teal-200 p-4 rounded-2xl space-y-2">
            <strong className="text-teal-900 font-bold block text-sm">
              Primary Purpose: Early Supportive Reassurance
            </strong>
            <p className="text-slate-700 leading-relaxed text-xs">
              {t.brand.disclaimer}
            </p>
          </div>

          <div className="space-y-3">
            <div className="font-bold text-slate-900 text-xs uppercase tracking-wider">
              Ethical &amp; Clinical Safety Principles:
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <span className="font-bold text-slate-900 block">1. Non-Diagnostic Language</span>
              <p className="text-slate-600 text-xs leading-relaxed">
                The platform only notes “Reported concerns” (such as pain, sleep disturbances, or feeling unassisted). It never outputs medical disease diagnoses.
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <span className="font-bold text-slate-900 block">2. Urgent Escalation Protocol</span>
              <p className="text-slate-600 text-xs leading-relaxed">
                Whenever severe discomfort, falls, or disorientation are reported, the system immediately urges the caregiver:
                <strong className="block text-rose-700 mt-0.5">
                  “Please check on the senior directly and seek appropriate professional or emergency help when necessary.”
                </strong>
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <span className="font-bold text-slate-900 block">3. Emergency Helpline Contacts</span>
              <p className="text-slate-600 text-xs leading-relaxed">
                In case of immediate medical urgency or sudden collapse, immediately contact local emergency services:
                <span className="block font-bold text-slate-900 mt-0.5">
                  India: 112 / 108 • USA/Canada: 911 • UK: 999
                </span>
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
          >
            I Understand
          </button>
        </div>

      </div>
    </div>
  );
};
