import React, { useState } from 'react';
import {
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Activity,
  CheckCircle2,
  FileText,
  Clock,
  MessageSquare,
  Heart,
  ChevronRight,
  Info
} from 'lucide-react';
import { Language, CallRecord, SeniorProfile } from '../../types';
import { translations } from '../../i18n/translations';

interface AIAnalysisDeepDiveProps {
  language: Language;
  calls: CallRecord[];
  seniors: SeniorProfile[];
}

export const AIAnalysisDeepDive: React.FC<AIAnalysisDeepDiveProps> = ({
  language,
  calls,
  seniors
}) => {
  const t = translations[language];

  const [selectedCallId, setSelectedCallId] = useState<string>(calls[0]?.id || '');
  const activeCall = calls.find((c) => c.id === selectedCallId) || calls[0];

  return (
    <div className="space-y-6 animate-in fade-in">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2 py-0.5 rounded">
            Linguistic Inspection &amp; Safety
          </span>
          <h2 className="text-2xl font-black text-slate-900 mt-1">{t.analysis.title}</h2>
          <p className="text-xs sm:text-sm text-slate-500">{t.analysis.subtitle}</p>
        </div>

        {/* Clinical boundary badge */}
        <div className="flex items-center gap-2 bg-teal-50 border border-teal-200 text-teal-800 text-xs px-3.5 py-2 rounded-xl">
          <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
          <span>Strict non-diagnostic safety protocols active</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Call Selector List */}
        <div className="lg:col-span-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <h3 className="font-bold text-slate-900 text-sm">Select Session to Inspect</h3>
          <div className="space-y-2">
            {calls.map((call) => (
              <div
                key={call.id}
                onClick={() => setSelectedCallId(call.id)}
                className={`p-3.5 rounded-xl border text-xs cursor-pointer transition ${
                  activeCall?.id === call.id
                    ? 'border-purple-500 bg-purple-50/60 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between font-bold mb-1">
                  <span className="text-slate-900 text-sm">{call.seniorName}</span>
                  <span
                    className={`px-2 py-0.5 rounded font-black text-[10px] ${
                      call.attentionLevel === 'HIGH'
                        ? 'bg-rose-100 text-rose-700'
                        : call.attentionLevel === 'MEDIUM'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {call.attentionLevel}
                  </span>
                </div>
                <div className="text-slate-400">{call.callDate} at {call.callTime}</div>
                <div className="text-slate-600 line-clamp-1 italic mt-1">“{call.aiSummary}”</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Call Deep Dive View */}
        <div className="lg:col-span-8 space-y-6">
          {activeCall ? (
            <>
              {/* Summary and Attention Level Banner */}
              <div
                className={`p-6 rounded-2xl border ${
                  activeCall.attentionLevel === 'HIGH'
                    ? 'bg-rose-50 border-rose-300'
                    : activeCall.attentionLevel === 'MEDIUM'
                    ? 'bg-amber-50 border-amber-300'
                    : 'bg-emerald-50 border-emerald-300'
                }`}
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-black/10 pb-4 mb-4">
                  <div>
                    <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                      {t.analysis.attentionTier}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span
                        className={`text-2xl font-black px-3.5 py-1 rounded-xl flex items-center gap-2 ${
                          activeCall.attentionLevel === 'HIGH'
                            ? 'bg-rose-600 text-white'
                            : activeCall.attentionLevel === 'MEDIUM'
                            ? 'bg-amber-600 text-white'
                            : 'bg-emerald-600 text-white'
                        }`}
                      >
                        {activeCall.attentionLevel === 'HIGH' && <AlertTriangle className="w-6 h-6" />}
                        {activeCall.attentionLevel === 'MEDIUM' && <Activity className="w-6 h-6" />}
                        {activeCall.attentionLevel === 'LOW' && <CheckCircle2 className="w-6 h-6" />}
                        <span>{activeCall.attentionLevel}</span>
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-slate-600 text-right">
                    <div>Senior: <strong>{activeCall.seniorName}</strong></div>
                    <div>Call Timestamp: <strong>{activeCall.callDate} at {activeCall.callTime}</strong></div>
                    <div>Duration: <strong>{activeCall.durationSeconds} seconds</strong></div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Overall Assessment
                    </h4>
                    <p className="text-sm font-semibold text-slate-900 mt-1">
                      {activeCall.aiSummary}
                    </p>
                  </div>

                  {/* AI Observations Box */}
                  <div className="bg-white/80 p-4 rounded-xl border border-black/10 space-y-2">
                    <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                      <span>{t.analysis.observations}</span>
                    </h5>
                    <ul className="space-y-1 text-xs text-slate-700">
                      {activeCall.aiAnalysis?.observations ? (
                        activeCall.aiAnalysis.observations.map((obs, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-purple-600 font-bold">•</span>
                            <span>{obs}</span>
                          </li>
                        ))
                      ) : (
                        <>
                          <li className="flex items-start gap-2">
                            <span className="text-purple-600 font-bold">•</span>
                            <span>Reported concern: Senior responses analyzed for physiological comfort.</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-purple-600 font-bold">•</span>
                            <span>Caregiver notification dispatched through automated SMS &amp; WhatsApp bridge.</span>
                          </li>
                        </>
                      )}
                    </ul>
                  </div>

                  {/* Disclaimer Reminder */}
                  <div className="flex items-center gap-2 text-xs text-slate-600 italic pt-1">
                    <Info className="w-4 h-4 text-slate-400 shrink-0" />
                    <span>{t.analysis.disclaimerNotice}</span>
                  </div>
                </div>
              </div>

              {/* Verbatim Conversation Transcript */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-teal-600" />
                    <span>{t.analysis.transcriptHeading}</span>
                  </h4>
                  <span className="text-xs text-slate-400">
                    Language: {activeCall.language === 'ta' ? 'தமிழ்' : 'English'}
                  </span>
                </div>

                <div className="space-y-3">
                  {activeCall.transcript && activeCall.transcript.length > 0 ? (
                    activeCall.transcript.map((item, idx) => (
                      <div
                        key={idx}
                        className={`p-4 rounded-xl border text-xs space-y-2 ${
                          item.flaggedConcern
                            ? 'bg-rose-50/70 border-rose-200 text-rose-950'
                            : 'bg-slate-50 border-slate-200 text-slate-800'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-700">
                            Q{item.questionId}: {activeCall.language === 'ta' ? item.questionTa : item.questionEn}
                          </span>
                          <span className="capitalize text-[10px] font-semibold text-slate-400">
                            {item.category}
                          </span>
                        </div>
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80 font-medium text-slate-900">
                          “{item.answerText}”
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-6 text-xs text-slate-400">
                      No verbatim transcript records stored for this sample.
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-400 text-sm">
              Please select a call record from the left to inspect.
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
