import React, { useState, useEffect } from 'react';
import { Language, User, SeniorProfile, CallRecord } from './types';
import { api } from './services/api';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { HeroSection } from './components/landing/HeroSection';
import { TrustBanner } from './components/landing/TrustBanner';
import { FeaturesSection } from './components/landing/FeaturesSection';
import { HowItWorksSection } from './components/landing/HowItWorksSection';
import { SafetySection } from './components/landing/SafetySection';
import { AuthModal } from './components/auth/AuthModal';
import { VoiceCallSimulator } from './components/voice/VoiceCallSimulator';
import { SafetyModal } from './components/safety/SafetyModal';
import { FamilyDashboard } from './components/dashboard/FamilyDashboard';

export default function App() {
  // Language State with persistence
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('anbuvoice_lang');
    return (saved === 'ta' || saved === 'en') ? saved : 'en';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('anbuvoice_lang', lang);
  };

  // View state: 'landing' or 'dashboard'
  const [currentView, setCurrentView] = useState<'landing' | 'dashboard'>('landing');

  // User state
  const [currentUser, setCurrentUser] = useState<User | null>(() => api.getCurrentUser());

  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [voiceModalOpen, setVoiceModalOpen] = useState(false);
  const [voiceCallSeniorId, setVoiceCallSeniorId] = useState<string | undefined>(undefined);
  const [safetyModalOpen, setSafetyModalOpen] = useState(false);

  // Seniors list for simulator
  const [seniors, setSeniors] = useState<SeniorProfile[]>([]);

  useEffect(() => {
    api.getSeniors().then(setSeniors);
  }, []);

  const handleOpenAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  const handleAuthSuccess = () => {
    const user = api.getCurrentUser();
    setCurrentUser(user);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    api.logout();
    setCurrentUser(null);
    setCurrentView('landing');
  };

  const handleOpenDemoCall = (seniorId?: string) => {
    setVoiceCallSeniorId(seniorId);
    setVoiceModalOpen(true);
  };

  const handleCallSaved = (_newCall: CallRecord) => {
    // Reload seniors to reflect latest check-in
    api.getSeniors().then(setSeniors);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans text-slate-900 selection:bg-teal-500 selection:text-white">
      
      {currentView === 'landing' ? (
        <>
          {/* Landing Navbar */}
          <Navbar
            currentView={currentView}
            setCurrentView={setCurrentView as any}
            language={language}
            setLanguage={setLanguage}
            isLoggedIn={!!currentUser}
            onOpenAuth={handleOpenAuth}
            onLogout={handleLogout}
            onOpenDemoCall={() => handleOpenDemoCall()}
          />

          <main className="flex-1">
            {/* Hero Section with 7-step pipeline visual */}
            <HeroSection
              language={language}
              onOpenAuth={handleOpenAuth}
              onOpenDemoCall={() => handleOpenDemoCall()}
              onScrollToHowItWorks={() => {
                document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            {/* Trust and Medical Disclaimer Banner */}
            <TrustBanner language={language} />

            {/* 8 Feature Cards */}
            <FeaturesSection language={language} />

            {/* 6-step How It Works Visual Process */}
            <HowItWorksSection
              language={language}
              onOpenDemoCall={() => handleOpenDemoCall()}
            />

            {/* Clinical Safety & Guardrails */}
            <SafetySection language={language} />
          </main>

          {/* Footer */}
          <Footer
            language={language}
            setLanguage={setLanguage}
            onOpenAuth={handleOpenAuth}
            onOpenDemoCall={() => handleOpenDemoCall()}
          />
        </>
      ) : (
        /* Family Dashboard View */
        <FamilyDashboard
          language={language}
          setLanguage={setLanguage}
          currentUser={currentUser}
          onLogout={handleLogout}
          onOpenDemoCall={handleOpenDemoCall}
        />
      )}

      {/* Auth Modal (Login / Register / Demo auto-fill) */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
        language={language}
        onAuthSuccess={handleAuthSuccess}
      />

      {/* Voice Call Demo Simulator */}
      <VoiceCallSimulator
        isOpen={voiceModalOpen}
        onClose={() => setVoiceModalOpen(false)}
        language={language}
        seniors={seniors}
        onCallSaved={handleCallSaved}
        defaultSeniorId={voiceCallSeniorId}
      />

      {/* Safety & Clinical Guardrails Modal */}
      <SafetyModal
        isOpen={safetyModalOpen}
        onClose={() => setSafetyModalOpen(false)}
        language={language}
      />

    </div>
  );
}
