import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

app.use(express.json());

// In-Memory Database Store
interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'family' | 'admin';
}

interface SeniorProfile {
  id: string;
  name: string;
  age: number;
  gender: 'Female' | 'Male' | 'Other';
  phone: string;
  relationship: string;
  language: 'en' | 'ta';
  medicalInformation: string;
  medications: string[];
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  dailyCallTime: string;
  timeZone: string;
  callFrequency: 'Daily' | 'Twice Daily' | 'Weekdays Only';
  isCallEnabled: boolean;
  status: 'Active' | 'Inactive';
  lastCheckIn?: string;
  lastAttentionLevel?: 'LOW' | 'MEDIUM' | 'HIGH';
  nextCall?: string;
}

interface CallRecord {
  id: string;
  seniorId: string;
  seniorName: string;
  callDate: string;
  callTime: string;
  durationSeconds: number;
  status: 'Scheduled' | 'Calling' | 'Connected' | 'Completed' | 'Missed' | 'Retrying' | 'Failed';
  retryAttempt?: number;
  language: 'en' | 'ta';
  transcript: Array<{
    questionId: number;
    questionEn: string;
    questionTa: string;
    category: string;
    answerText: string;
    flaggedConcern?: boolean;
  }>;
  attentionLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  aiSummary: string;
  aiAnalysis?: any;
  familyNotificationSent: boolean;
  notificationChannels: ('SMS' | 'WhatsApp' | 'Email')[];
}

interface Alert {
  id: string;
  seniorId: string;
  seniorName: string;
  attentionLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  concern: string;
  timestamp: string;
  status: 'Active' | 'Acknowledged' | 'Resolved';
  actionTaken?: string;
}

interface Notification {
  id: string;
  seniorId: string;
  seniorName: string;
  type: 'completed' | 'medium_attention' | 'high_attention' | 'missed' | 'medication_confirmed';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  attentionLevel?: 'LOW' | 'MEDIUM' | 'HIGH';
}

// Initial Seeds
const users: User[] = [
  {
    id: 'u-1',
    name: 'Karthik Sundaram',
    email: 'family@example.com',
    phone: '+91 98401 55667',
    role: 'family'
  }
];

let seniors: SeniorProfile[] = [
  {
    id: 'sen-1',
    name: 'Lakshmi Devi',
    age: 74,
    gender: 'Female',
    phone: '+91 98401 23456',
    relationship: 'Mother',
    language: 'ta',
    medicalInformation: 'Mild hypertension, early osteoarthritis in knees.',
    medications: ['Amlodipine 5mg (Morning)', 'Calcium D3 supplement'],
    emergencyContact: {
      name: 'Karthik Sundaram',
      relationship: 'Son',
      phone: '+91 98401 55667'
    },
    dailyCallTime: '09:00 AM',
    timeZone: 'Asia/Kolkata (IST)',
    callFrequency: 'Daily',
    isCallEnabled: true,
    status: 'Active',
    lastCheckIn: 'Today, 09:02 AM',
    lastAttentionLevel: 'LOW',
    nextCall: 'Tomorrow, 09:00 AM'
  },
  {
    id: 'sen-2',
    name: 'Ramanathan Iyer',
    age: 81,
    gender: 'Male',
    phone: '+91 94440 87654',
    relationship: 'Father',
    language: 'ta',
    medicalInformation: 'Type 2 Diabetes, history of mild postural vertigo.',
    medications: ['Metformin 500mg (Post-breakfast)', 'Atorvastatin 10mg'],
    emergencyContact: {
      name: 'Karthik Sundaram',
      relationship: 'Son',
      phone: '+91 98401 55667'
    },
    dailyCallTime: '09:30 AM',
    timeZone: 'Asia/Kolkata (IST)',
    callFrequency: 'Daily',
    isCallEnabled: true,
    status: 'Active',
    lastCheckIn: 'Today, 09:32 AM',
    lastAttentionLevel: 'HIGH',
    nextCall: 'Tomorrow, 09:30 AM'
  },
  {
    id: 'sen-3',
    name: 'Mary Joseph',
    age: 76,
    gender: 'Female',
    phone: '+91 98840 54321',
    relationship: 'Aunt',
    language: 'en',
    medicalInformation: 'Mild asthma, mild insomnia.',
    medications: ['Salbutamol Inhaler (PRN)', 'Melatonin 3mg'],
    emergencyContact: {
      name: 'Karthik Sundaram',
      relationship: 'Nephew',
      phone: '+91 98401 55667'
    },
    dailyCallTime: '10:00 AM',
    timeZone: 'Asia/Kolkata (IST)',
    callFrequency: 'Daily',
    isCallEnabled: true,
    status: 'Active',
    lastCheckIn: 'Yesterday, 10:01 AM',
    lastAttentionLevel: 'MEDIUM',
    nextCall: 'Today, 10:00 AM'
  }
];

let calls: CallRecord[] = [
  {
    id: 'call-101',
    seniorId: 'sen-1',
    seniorName: 'Lakshmi Devi',
    callDate: new Date().toISOString().split('T')[0],
    callTime: '09:02 AM',
    durationSeconds: 142,
    status: 'Completed',
    language: 'ta',
    transcript: [
      {
        questionId: 1,
        questionEn: "Are you feeling well today?",
        questionTa: "இன்று நீங்கள் நலமாக இருக்கிறீர்களா?",
        category: "general",
        answerText: "ஆம், நான் இன்று மிகவும் நன்றாக இருக்கிறேன். காலையில் வாக்கிங் சென்றேன்."
      },
      {
        questionId: 2,
        questionEn: "Did you take your medicine?",
        questionTa: "இன்று உங்கள் மருந்தை எடுத்துக்கொண்டீர்களா?",
        category: "medication",
        answerText: "ஆமாம், காலை உணவுக்குப் பிறகு இரத்த அழுத்த மாத்திரை எடுத்துக்கொண்டேன்."
      },
      {
        questionId: 3,
        questionEn: "Are you experiencing any pain?",
        questionTa: "உங்களுக்கு ஏதேனும் வலி இருக்கிறதா?",
        category: "pain",
        answerText: "இல்லை, பெரிய வலி எதுவும் இல்லை."
      },
      {
        questionId: 4,
        questionEn: "Did you fall or feel dizzy?",
        questionTa: "நீங்கள் கீழே விழுந்தீர்களா அல்லது தலைச்சுற்றல் ஏற்பட்டதா?",
        category: "safety",
        answerText: "இல்லை, எந்த மயக்கமும் வரவில்லை."
      },
      {
        questionId: 5,
        questionEn: "How was your sleep?",
        questionTa: "நேற்று இரவு உங்கள் தூக்கம் எப்படி இருந்தது?",
        category: "sleep",
        answerText: "நேற்று இரவு அமைதியாக 7 மணி நேரம் தூங்கினேன்."
      },
      {
        questionId: 6,
        questionEn: "How are you feeling emotionally today?",
        questionTa: "இன்று உங்கள் மனநிலை எப்படி இருக்கிறது?",
        category: "mood",
        answerText: "மனசுக்கு நிம்மதியாகவும் மகிழ்ச்சியாகவும் இருக்கிறது."
      }
    ],
    attentionLevel: 'LOW',
    aiSummary: "Senior reported feeling well and confirmed morning hypertension medication. No pain, dizziness, or sleep issues reported.",
    familyNotificationSent: true,
    notificationChannels: ['SMS', 'WhatsApp']
  },
  {
    id: 'call-102',
    seniorId: 'sen-2',
    seniorName: 'Ramanathan Iyer',
    callDate: new Date().toISOString().split('T')[0],
    callTime: '09:32 AM',
    durationSeconds: 165,
    status: 'Completed',
    language: 'ta',
    transcript: [
      {
        questionId: 1,
        questionEn: "Are you feeling well today?",
        questionTa: "இன்று நீங்கள் நலமாக இருக்கிறீர்களா?",
        category: "general",
        answerText: "இன்று உடல் கொஞ்சம் சோர்வாக இருக்கிறது."
      },
      {
        questionId: 2,
        questionEn: "Did you take your medicine?",
        questionTa: "இன்று உங்கள் மருந்தை எடுத்துக்கொண்டீர்களா?",
        category: "medication",
        answerText: "இன்னும் எடுக்கவில்லை, பசி எடுக்கவில்லை என்று தள்ளிப் போட்டேன்."
      },
      {
        questionId: 3,
        questionEn: "Are you experiencing any pain?",
        questionTa: "உங்களுக்கு ஏதேனும் வலி இருக்கிறதா?",
        category: "pain",
        answerText: "முதுகிலும் வலது காலிலும் கடுமையான வலி இருக்கிறது.",
        flaggedConcern: true
      },
      {
        questionId: 4,
        questionEn: "Did you fall or feel dizzy?",
        questionTa: "நீங்கள் கீழே விழுந்தீர்களா அல்லது தலைச்சுற்றல் ஏற்பட்டதா?",
        category: "safety",
        answerText: "காலையில் எழுந்திருக்கும்போது லேசாக தலை சுற்றியது, சுவரைப் பிடித்துக் கொண்டேன்.",
        flaggedConcern: true
      },
      {
        questionId: 5,
        questionEn: "How was your sleep?",
        questionTa: "நேற்று இரவு உங்கள் தூக்கம் எப்படி இருந்தது?",
        category: "sleep",
        answerText: "வலி காரணமாக சரியாக தூங்க முடியவில்லை."
      },
      {
        questionId: 6,
        questionEn: "How are you feeling emotionally today?",
        questionTa: "இன்று உங்கள் மனநிலை எப்படி இருக்கிறது?",
        category: "mood",
        answerText: "கொஞ்சம் பயமாகவும் தனிமையாகவும் இருக்கிறது."
      }
    ],
    attentionLevel: 'HIGH',
    aiSummary: "Reported concern: Senior described morning dizziness with postural unsteadiness and severe leg/back discomfort. Medication delayed and sleep disturbed. Urgent family check recommended.",
    familyNotificationSent: true,
    notificationChannels: ['SMS', 'WhatsApp', 'Email']
  },
  {
    id: 'call-103',
    seniorId: 'sen-3',
    seniorName: 'Mary Joseph',
    callDate: new Date(Date.now() - 86400000).toISOString().split('T')[0],
    callTime: '10:01 AM',
    durationSeconds: 130,
    status: 'Completed',
    language: 'en',
    transcript: [
      {
        questionId: 1,
        questionEn: "Are you feeling well today?",
        questionTa: "இன்று நீங்கள் நலமாக இருக்கிறீர்களா?",
        category: "general",
        answerText: "I am feeling okay, just a little tired today."
      },
      {
        questionId: 2,
        questionEn: "Did you take your medicine?",
        questionTa: "இன்று உங்கள் மருந்தை எடுத்துக்கொண்டீர்களா?",
        category: "medication",
        answerText: "I took my vitamin, but forgot the morning syrup."
      },
      {
        questionId: 3,
        questionEn: "Are you experiencing any pain?",
        questionTa: "உங்களுக்கு ஏதேனும் வலி இருக்கிறதா?",
        category: "pain",
        answerText: "Mild stiffness in my shoulders from the cold weather."
      },
      {
        questionId: 4,
        questionEn: "Did you fall or feel dizzy?",
        questionTa: "நீங்கள் கீழே விழுந்தீர்களா அல்லது தலைச்சுற்றல் ஏற்பட்டதா?",
        category: "safety",
        answerText: "No falls, balance is fine."
      },
      {
        questionId: 5,
        questionEn: "How was your sleep?",
        questionTa: "நேற்று இரவு உங்கள் தூக்கம் எப்படி இருந்தது?",
        category: "sleep",
        answerText: "Woke up twice during the night, feeling somewhat restless."
      },
      {
        questionId: 6,
        questionEn: "How are you feeling emotionally today?",
        questionTa: "இன்று உங்கள் மனநிலை எப்படி இருக்கிறது?",
        category: "mood",
        answerText: "Doing alright, spoke with my sister yesterday."
      }
    ],
    attentionLevel: 'MEDIUM',
    aiSummary: "Reported concern: Mild joint stiffness and restless sleep reported; one morning medication was delayed. Caregiver follow-up advised.",
    familyNotificationSent: true,
    notificationChannels: ['SMS', 'WhatsApp']
  }
];

let alerts: Alert[] = [
  {
    id: 'alt-1',
    seniorId: 'sen-2',
    seniorName: 'Ramanathan Iyer',
    attentionLevel: 'HIGH',
    concern: 'Reported morning dizziness upon standing and delayed medication. Advised urgent check on senior.',
    timestamp: 'Today, 09:34 AM',
    status: 'Active'
  },
  {
    id: 'alt-2',
    seniorId: 'sen-3',
    seniorName: 'Mary Joseph',
    attentionLevel: 'MEDIUM',
    concern: 'Missed morning medication and reported interrupted sleep.',
    timestamp: 'Yesterday, 10:04 AM',
    status: 'Acknowledged',
    actionTaken: 'Caregiver called to confirm medication taken.'
  }
];

let notifications: Notification[] = [
  {
    id: 'notif-1',
    seniorId: 'sen-2',
    seniorName: 'Ramanathan Iyer',
    type: 'high_attention',
    title: 'Urgent: High Attention Alert',
    message: 'Ramanathan reported dizziness and missed medication today. Please check on senior directly.',
    timestamp: 'Today, 09:34 AM',
    read: false,
    attentionLevel: 'HIGH'
  },
  {
    id: 'notif-2',
    seniorId: 'sen-1',
    seniorName: 'Lakshmi Devi',
    type: 'completed',
    title: 'Check-in Completed: All Normal',
    message: 'Lakshmi Devi completed her daily voice check-in. All responses normal, medications confirmed.',
    timestamp: 'Today, 09:03 AM',
    read: true,
    attentionLevel: 'LOW'
  },
  {
    id: 'notif-3',
    seniorId: 'sen-3',
    seniorName: 'Mary Joseph',
    type: 'medium_attention',
    title: 'Medium Attention: Caregiver Review',
    message: 'Mary reported mild stiffness and missed morning syrup.',
    timestamp: 'Yesterday, 10:05 AM',
    read: true,
    attentionLevel: 'MEDIUM'
  }
];

// Helper: Setup Gemini client safely if API key is present
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  try {
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  } catch (err) {
    console.warn('Failed to initialize Gemini client:', err);
    return null;
  }
};

// Heuristic fallback analyzer compliant with strict healthcare safety
function analyzeTranscriptHeuristic(transcript: Array<{ category: string; answerText: string }>) {
  let hasFallOrDizzy = false;
  let hasSeverePain = false;
  let hasMissedMeds = false;
  let hasPoorSleep = false;
  let lowMood = false;
  const observations: string[] = [];

  for (const item of transcript) {
    const text = (item.answerText || '').toLowerCase();

    if (item.category === 'safety') {
      if (text.includes('dizzy') || text.includes('fall') || text.includes('fell') || text.includes('slip') ||
          text.includes('மயக்கம்') || text.includes('தலைச்சுற்றல்') || text.includes('விழுந்தேன்') || text.includes('தடுமாற்றம்')) {
        hasFallOrDizzy = true;
        observations.push("Reported concern: Senior noted dizziness or balance instability.");
      }
    }

    if (item.category === 'pain') {
      if (text.includes('severe') || text.includes('chest') || text.includes('unbearable') ||
          text.includes('கடுமையான') || text.includes('தாங்க முடியாத') || text.includes('மார்பு')) {
        hasSeverePain = true;
        observations.push("Reported concern: Significant pain was reported.");
      } else if (text.includes('pain') || text.includes('hurt') || text.includes('stiff') || text.includes('வலி') || text.includes('பிடிப்பு')) {
        observations.push("Reported concern: Mild discomfort or stiffness was noted.");
      }
    }

    if (item.category === 'medication') {
      if (text.includes('no') || text.includes('forgot') || text.includes('missed') || text.includes('later') ||
          text.includes('இல்லை') || text.includes('மறந்து') || text.includes('எடுக்கவில்லை') || text.includes('தள்ளி')) {
        hasMissedMeds = true;
        observations.push("Reported concern: Scheduled medication was not yet confirmed.");
      } else {
        observations.push("Medication adherence: Routine medication was verbally confirmed.");
      }
    }

    if (item.category === 'sleep') {
      if (text.includes('poor') || text.includes('bad') || text.includes('could not sleep') || text.includes('restless') ||
          text.includes('சரியாக தூங்கவில்லை') || text.includes('தூக்கமின்மை')) {
        hasPoorSleep = true;
        observations.push("Sleep assessment: Interrupted or restless sleep pattern reported.");
      }
    }

    if (item.category === 'mood') {
      if (text.includes('sad') || text.includes('lonely') || text.includes('scared') || text.includes('afraid') ||
          text.includes('பயம்') || text.includes('தனிமை') || text.includes('கவலை')) {
        lowMood = true;
        observations.push("Emotional wellbeing: Senior expressed feeling lonely, worried, or down.");
      }
    }
  }

  let attentionLevel: 'LOW' | 'MEDIUM' | 'HIGH' = 'LOW';
  let recommendedAction = "Routine family dashboard update dispatched. Continue regular monitoring.";
  let summary = "Senior reported feeling well and confirmed medication. No immediate concerns identified.";

  if (hasFallOrDizzy || hasSeverePain) {
    attentionLevel = 'HIGH';
    summary = "Reported concern: Senior reported safety-related concerns (such as dizziness or acute pain). Family check recommended.";
    recommendedAction = "Urgent: Please check on the senior directly and seek appropriate professional or emergency help when necessary.";
  } else if (hasMissedMeds || hasPoorSleep || lowMood || observations.some(o => o.includes('Mild discomfort'))) {
    attentionLevel = 'MEDIUM';
    summary = "Reported concern: Mild discomfort, disturbed sleep, or delayed medication was noted.";
    recommendedAction = "Family notification sent. Caregiver check-in recommended within a few hours.";
  }

  if (observations.length === 0) {
    observations.push("Senior communicated comfortably during the check-in call.");
    observations.push("No acute wellbeing concerns were raised.");
  }

  return {
    attentionLevel,
    summary,
    observations,
    recommendedAction,
    metrics: {
      moodScore: lowMood ? 'Low' : (hasPoorSleep ? 'Fair' : 'Good'),
      medicationConfirmed: !hasMissedMeds,
      painReported: hasSeverePain || observations.some(o => o.includes('Mild discomfort')),
      fallOrDizzinessReported: hasFallOrDizzy,
      sleepQuality: hasPoorSleep ? 'Restless' : 'Good'
    },
    disclaimer: "AnbuVoice AI provides supportive monitoring and early insights. It does not provide medical diagnosis or replace professional medical care."
  };
}

// REST API ROUTES

// 1. Auth
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  // Demo login credentials support
  if (email === 'family@example.com' && password === 'SeniorCare123') {
    return res.json({
      success: true,
      token: 'jwt-demo-token-anbuvoice-2026',
      user: users[0]
    });
  }
  // Generic user fallback
  const user = users.find(u => u.email === email);
  if (user) {
    return res.json({
      success: true,
      token: 'jwt-demo-token-anbuvoice-2026',
      user
    });
  }
  // Allow any email for presentation convenience
  const newUser: User = {
    id: `u-${Date.now()}`,
    name: email.split('@')[0] || 'Family Member',
    email,
    phone: '+91 98401 00000',
    role: 'family'
  };
  users.push(newUser);
  return res.json({
    success: true,
    token: 'jwt-demo-token-anbuvoice-2026',
    user: newUser
  });
});

app.post('/api/auth/register', (req: Request, res: Response) => {
  const { name, email, phone } = req.body;
  const newUser: User = {
    id: `u-${Date.now()}`,
    name: name || 'Family Caregiver',
    email: email || 'family@example.com',
    phone: phone || '+91 98401 00000',
    role: 'family'
  };
  users.push(newUser);
  return res.json({
    success: true,
    token: 'jwt-demo-token-anbuvoice-2026',
    user: newUser
  });
});

// 2. Seniors CRUD
app.get('/api/seniors', (_req: Request, res: Response) => {
  res.json({ success: true, seniors });
});

app.post('/api/seniors', (req: Request, res: Response) => {
  const data = req.body;
  const newSenior: SeniorProfile = {
    id: `sen-${Date.now()}`,
    name: data.name || 'Unnamed Senior',
    age: parseInt(data.age, 10) || 70,
    gender: data.gender || 'Female',
    phone: data.phone || '+91 98400 00000',
    relationship: data.relationship || 'Relative',
    language: data.language || 'en',
    medicalInformation: data.medicalInformation || 'None noted',
    medications: Array.isArray(data.medications) ? data.medications : (data.medications ? [data.medications] : []),
    emergencyContact: data.emergencyContact || {
      name: 'Family Contact',
      relationship: 'Relative',
      phone: '+91 98400 00000'
    },
    dailyCallTime: data.dailyCallTime || '09:00 AM',
    timeZone: data.timeZone || 'Asia/Kolkata (IST)',
    callFrequency: data.callFrequency || 'Daily',
    isCallEnabled: data.isCallEnabled !== false,
    status: 'Active',
    lastCheckIn: 'Not called yet',
    lastAttentionLevel: 'LOW',
    nextCall: `Tomorrow, ${data.dailyCallTime || '09:00 AM'}`
  };
  seniors.unshift(newSenior);
  res.status(201).json({ success: true, senior: newSenior });
});

app.put('/api/seniors/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const index = seniors.findIndex(s => s.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Senior not found' });
  }
  seniors[index] = { ...seniors[index], ...req.body };
  res.json({ success: true, senior: seniors[index] });
});

app.delete('/api/seniors/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  seniors = seniors.filter(s => s.id !== id);
  res.json({ success: true, message: 'Senior deleted' });
});

// 3. Calls & Check-in Records
app.get('/api/calls', (_req: Request, res: Response) => {
  res.json({ success: true, calls });
});

app.get('/api/calls/:id', (req: Request, res: Response) => {
  const call = calls.find(c => c.id === req.params.id);
  if (!call) return res.status(404).json({ success: false, message: 'Call record not found' });
  res.json({ success: true, call });
});

app.post('/api/calls/save', (req: Request, res: Response) => {
  const data = req.body;
  const newCall: CallRecord = {
    id: `call-${Date.now()}`,
    seniorId: data.seniorId,
    seniorName: data.seniorName,
    callDate: data.callDate || new Date().toISOString().split('T')[0],
    callTime: data.callTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    durationSeconds: data.durationSeconds || 120,
    status: data.status || 'Completed',
    retryAttempt: data.retryAttempt || 1,
    language: data.language || 'en',
    transcript: data.transcript || [],
    attentionLevel: data.attentionLevel || 'LOW',
    aiSummary: data.aiSummary || 'Voice check-in completed.',
    aiAnalysis: data.aiAnalysis,
    familyNotificationSent: true,
    notificationChannels: data.notificationChannels || ['SMS', 'WhatsApp']
  };

  calls.unshift(newCall);

  // Update senior's last check-in state
  const seniorIndex = seniors.findIndex(s => s.id === data.seniorId);
  if (seniorIndex !== -1) {
    seniors[seniorIndex].lastCheckIn = `Today, ${newCall.callTime}`;
    seniors[seniorIndex].lastAttentionLevel = newCall.attentionLevel;
  }

  // Create corresponding alert if MEDIUM or HIGH
  if (newCall.attentionLevel === 'HIGH' || newCall.attentionLevel === 'MEDIUM') {
    const newAlert: Alert = {
      id: `alt-${Date.now()}`,
      seniorId: newCall.seniorId,
      seniorName: newCall.seniorName,
      attentionLevel: newCall.attentionLevel,
      concern: newCall.aiSummary,
      timestamp: `Today, ${newCall.callTime}`,
      status: 'Active'
    };
    alerts.unshift(newAlert);
  }

  // Create notifications
  const notifType = newCall.attentionLevel === 'HIGH' ? 'high_attention' :
                   (newCall.attentionLevel === 'MEDIUM' ? 'medium_attention' : 'completed');
  const notifTitle = newCall.attentionLevel === 'HIGH' ? '🚨 Urgent: High Attention Alert' :
                    (newCall.attentionLevel === 'MEDIUM' ? '⚠ Attention: Wellbeing Concern' : '✓ Check-in Completed');
  
  notifications.unshift({
    id: `notif-${Date.now()}`,
    seniorId: newCall.seniorId,
    seniorName: newCall.seniorName,
    type: notifType,
    title: notifTitle,
    message: newCall.aiSummary,
    timestamp: `Today, ${newCall.callTime}`,
    read: false,
    attentionLevel: newCall.attentionLevel
  });

  res.status(201).json({ success: true, call: newCall });
});

// 4. AI Analysis endpoint
app.post('/api/ai/analyze', async (req: Request, res: Response) => {
  const { transcript, seniorName, language } = req.body;

  if (!transcript || !Array.isArray(transcript)) {
    return res.status(400).json({ success: false, message: 'Transcript array is required' });
  }

  const gemini = getGeminiClient();

  if (gemini) {
    try {
      const prompt = `You are the clinical safety AI evaluator for AnbuVoice AI, an elderly wellbeing monitoring system.
The following is a conversation transcript from a daily check-in with senior citizen "${seniorName || 'Senior'}".
Language: ${language === 'ta' ? 'Tamil' : 'English'}.

CRITICAL MEDICAL SAFETY RULES:
1. NEVER diagnose clinical diseases or conditions.
2. Use phrases like "Reported concern", "Senior noted...", "Discomfort reported". NEVER say "Disease detected" or "Patient has X condition".
3. Assign attention level strictly as:
   - "LOW": Senior feels well, confirmed medication, no pain, no falls or dizziness.
   - "MEDIUM": Mild discomfort, sleep disturbance, missed or delayed medication, mild emotional distress.
   - "HIGH": Fall reported, dizziness or vertigo, severe pain, disorientation, emergency response.
4. If HIGH, always output recommendedAction stating: "Please check on the senior directly and seek appropriate professional or emergency help when necessary."

Transcript items:
${JSON.stringify(transcript, null, 2)}

Respond with STRICT JSON format matching:
{
  "attentionLevel": "LOW" | "MEDIUM" | "HIGH",
  "summary": "1-2 sentence supportive summary highlighting reported concerns",
  "observations": ["bullet observation 1", "bullet observation 2"],
  "recommendedAction": "Action steps for caregiver",
  "metrics": {
    "moodScore": "Good" | "Fair" | "Low",
    "medicationConfirmed": boolean,
    "painReported": boolean,
    "fallOrDizzinessReported": boolean,
    "sleepQuality": "Good" | "Restless" | "Poor"
  },
  "disclaimer": "AnbuVoice AI provides supportive monitoring and early insights. It does not provide medical diagnosis or replace professional medical care."
}`;

      const aiResponse = await gemini.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const responseText = aiResponse.text;
      if (responseText) {
        const parsed = JSON.parse(responseText.trim());
        return res.json({ success: true, analysis: parsed });
      }
    } catch (err) {
      console.warn('Gemini analysis failed, falling back to heuristic safety analyzer:', err);
    }
  }

  // Robust Heuristic Fallback
  const analysis = analyzeTranscriptHeuristic(transcript);
  return res.json({ success: true, analysis });
});

// 5. Dashboard aggregate stats
app.get('/api/dashboard', (_req: Request, res: Response) => {
  const completedCalls = calls.filter(c => c.status === 'Completed').length;
  const missedCalls = calls.filter(c => c.status === 'Missed').length;
  const activeAlerts = alerts.filter(a => a.status === 'Active').length;

  const lowCount = calls.filter(c => c.attentionLevel === 'LOW').length;
  const medCount = calls.filter(c => c.attentionLevel === 'MEDIUM').length;
  const highCount = calls.filter(c => c.attentionLevel === 'HIGH').length;

  res.json({
    success: true,
    stats: {
      totalSeniors: seniors.length,
      todaysCalls: calls.length,
      completedCalls,
      missedCalls,
      activeAlerts,
      riskSummary: {
        low: lowCount,
        medium: medCount,
        high: highCount
      }
    },
    recentCalls: calls.slice(0, 5),
    activeAlertsList: alerts.filter(a => a.status === 'Active').slice(0, 5)
  });
});

// 6. Alerts & Notifications
app.get('/api/alerts', (_req: Request, res: Response) => {
  res.json({ success: true, alerts });
});

app.post('/api/alerts', (req: Request, res: Response) => {
  const newAlert: Alert = {
    id: `alt-${Date.now()}`,
    seniorId: req.body.seniorId || 'sen-1',
    seniorName: req.body.seniorName || 'Senior',
    attentionLevel: req.body.attentionLevel || 'MEDIUM',
    concern: req.body.concern || 'Reported wellbeing concern',
    timestamp: 'Just now',
    status: 'Active'
  };
  alerts.unshift(newAlert);
  res.status(201).json({ success: true, alert: newAlert });
});

app.put('/api/alerts/:id/acknowledge', (req: Request, res: Response) => {
  const { id } = req.params;
  const alert = alerts.find(a => a.id === id);
  if (alert) {
    alert.status = 'Acknowledged';
    alert.actionTaken = req.body.actionTaken || 'Caregiver acknowledged and contacted senior.';
    return res.json({ success: true, alert });
  }
  res.status(404).json({ success: false, message: 'Alert not found' });
});

app.get('/api/notifications', (_req: Request, res: Response) => {
  res.json({ success: true, notifications });
});

app.put('/api/notifications/:id/read', (req: Request, res: Response) => {
  const { id } = req.params;
  const notif = notifications.find(n => n.id === id);
  if (notif) {
    notif.read = true;
    return res.json({ success: true, notification: notif });
  }
  res.status(404).json({ success: false, message: 'Notification not found' });
});

app.put('/api/notifications/read-all', (_req: Request, res: Response) => {
  notifications.forEach(n => { n.read = true; });
  res.json({ success: true, message: 'All notifications marked as read' });
});

// 7. Twilio / Exotel Webhook simulator
app.post('/api/voice/webhook', (req: Request, res: Response) => {
  const { CallSid, From, CallStatus } = req.body;
  res.json({
    success: true,
    twiml: `<Response><Say>Welcome to AnbuVoice AI daily check in.</Say></Response>`,
    metadata: { CallSid, From, CallStatus, receivedAt: new Date().toISOString() }
  });
});

// 8. Communication summary
app.get('/api/communication', (_req: Request, res: Response) => {
  res.json({
    success: true,
    metrics: {
      todaysTotal: calls.length,
      completed: calls.filter(c => c.status === 'Completed').length,
      missed: calls.filter(c => c.status === 'Missed').length,
      retrying: calls.filter(c => c.status === 'Retrying').length,
      alertsDispatched: alerts.length
    },
    calls
  });
});

// Server Initialization with Vite dev integration
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AnbuVoice AI] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
